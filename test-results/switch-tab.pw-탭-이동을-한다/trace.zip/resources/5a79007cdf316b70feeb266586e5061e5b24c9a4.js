(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_acffabbe._.js",
  "static/chunks/a2029_micromark_dev_lib_33943764._.js",
  "static/chunks/42800_micromark-core-commonmark_dev_lib_f3ec2821._.js",
  "static/chunks/node_modules__pnpm_7024ff54._.js"
],
    source: "dynamic"
});
