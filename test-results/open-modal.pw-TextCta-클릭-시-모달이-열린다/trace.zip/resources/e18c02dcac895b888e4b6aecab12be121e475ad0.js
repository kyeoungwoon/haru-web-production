(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b5acc3f7._.js",
  "static/chunks/1c600_date-fns_907d0eaf._.js"
],
    source: "dynamic"
});
