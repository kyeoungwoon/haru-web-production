(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_5489c1c9._.css",
  "static/chunks/965bc_@tanstack_query-devtools_build_4eb39056._.js",
  "static/chunks/node_modules__pnpm_6e3fb0c9._.js",
  "static/chunks/src_b6c104f5._.js"
],
    source: "dynamic"
});
