(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_290fc5e2._.js",
  "static/chunks/node_modules__pnpm_e8f2fbce._.js"
],
    source: "dynamic"
});
