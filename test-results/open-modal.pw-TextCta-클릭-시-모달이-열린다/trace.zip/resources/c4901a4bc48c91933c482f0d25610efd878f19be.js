(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/12bbe_next_a13e69d9._.js",
  "static/chunks/src_cdee03fe._.js"
],
    source: "dynamic"
});
