(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/router.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
module.exports = __turbopack_context__.r("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/client/router.js [app-client] (ecmascript)");
}}),
}]);

//# sourceMappingURL=12bbe_next_router_28ab2b69.js.map