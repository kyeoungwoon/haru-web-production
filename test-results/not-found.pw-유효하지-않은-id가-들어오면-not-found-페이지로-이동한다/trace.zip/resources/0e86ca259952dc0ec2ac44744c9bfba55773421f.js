(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8bffa5bd._.js",
  "static/chunks/12bbe_next_dist_compiled_react-dom_141121d6._.js",
  "static/chunks/12bbe_next_dist_compiled_b4d4fc10._.js",
  "static/chunks/12bbe_next_dist_client_49fb2cf1._.js",
  "static/chunks/12bbe_next_dist_shared_lib_63a84eac._.js",
  "static/chunks/12bbe_next_dist_77931709._.js",
  "static/chunks/12bbe_next_router_28ab2b69.js",
  "static/chunks/c4a87_@sentry_core_build_esm_2d7697fb._.js",
  "static/chunks/78891_@sentry_browser_build_npm_esm_3eb48e9b._.js",
  "static/chunks/8ef8e_@sentry-internal_browser-utils_build_esm_fc0e9bea._.js",
  "static/chunks/0b099_@sentry-internal_replay_build_npm_esm_index_12cd3512.js",
  "static/chunks/node_modules__pnpm_68c8c7e4._.js",
  "static/chunks/src_instrumentation-client_ts_4aba9a11._.js"
],
    source: "entry"
});
