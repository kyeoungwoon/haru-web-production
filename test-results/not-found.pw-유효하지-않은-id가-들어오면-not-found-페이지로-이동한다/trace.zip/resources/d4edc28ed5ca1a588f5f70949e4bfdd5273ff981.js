(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_5aca63ca._.js",
  "static/chunks/node_modules__pnpm_a2cd74ef._.js"
],
    source: "dynamic"
});
