(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/common/stores/toast-store.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)");
;
;
;
const toastStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devtools"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["immer"])((set, get)=>({
        toastList: [],
        actions: {
            addToast: (toast)=>{
                const { type, text } = toast;
                // 중복 방지용 키
                const key = `${type}-${text}`;
                const state = get();
                // 이미 존재하는 동일한 토스트는 무시
                if (state.toastList.some((t)=>t.key === key)) return;
                const newToast = {
                    ...toast,
                    key
                };
                set((s)=>{
                    s.toastList.push(newToast);
                });
            },
            removeToast: (key)=>{
                set((s)=>{
                    s.toastList = s.toastList.filter((t)=>t.key !== key);
                });
            },
            clearToasts: ()=>set((s)=>{
                    s.toastList = [];
                })
        }
    })), {
    name: 'ToastStore'
}));
const __TURBOPACK__default__export__ = toastStore;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/hooks/stores/useToastStore.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useToastActions": (()=>useToastActions),
    "useToastInfo": (()=>useToastInfo)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/react/shallow.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$stores$2f$toast$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/stores/toast-store.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const useToastInfo = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$stores$2f$toast$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallow"])({
        "useToastInfo.useShallow": (state)=>({
                toastList: state.toastList
            })
    }["useToastInfo.useShallow"]));
};
_s(useToastInfo, "cfplsmNliQkD/fzzQKqhzRiWrSg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallow"]
    ];
});
const useToastActions = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$stores$2f$toast$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((state)=>state.actions);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/toast/types/toast.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ToastType": (()=>ToastType)
});
var ToastType = /*#__PURE__*/ function(ToastType) {
    ToastType["SUCCESS"] = "SUCCESS";
    ToastType["ERROR"] = "ERROR";
    ToastType["INFO"] = "INFO";
    return ToastType;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/toast/Toast/Toast.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useToastStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/hooks/stores/useToastStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$toast$2f$types$2f$toast$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/toast/types/toast.types.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const Toast = ({ toast })=>{
    _s();
    const { key, type, text, duration } = toast;
    const [isEntering, setIsEntering] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true); // 등장
    const [isRemoving, setIsRemoving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // 사라짐
    const { removeToast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useToastStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToastActions"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Toast.useEffect": ()=>{
            const enterTimer = setTimeout({
                "Toast.useEffect.enterTimer": ()=>setIsEntering(false)
            }["Toast.useEffect.enterTimer"], 10);
            const removeTimer = setTimeout({
                "Toast.useEffect.removeTimer": ()=>setIsRemoving(true)
            }["Toast.useEffect.removeTimer"], duration ?? 2000);
            return ({
                "Toast.useEffect": ()=>{
                    clearTimeout(enterTimer);
                    clearTimeout(removeTimer);
                }
            })["Toast.useEffect"];
        }
    }["Toast.useEffect"], [
        key
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Toast.useEffect": ()=>{
            if (isRemoving) {
                const timeout = setTimeout({
                    "Toast.useEffect.timeout": ()=>removeToast(key)
                }["Toast.useEffect.timeout"], 500); // transition 시간과 맞춤
                return ({
                    "Toast.useEffect": ()=>clearTimeout(timeout)
                })["Toast.useEffect"];
            }
        }
    }["Toast.useEffect"], [
        isRemoving
    ]);
    const handleClick = ()=>{
        setIsRemoving(true);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "alert",
        "aria-live": "assertive",
        onClick: handleClick,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('gap-6pxr border-stroke-200 px-24pxr py-12pxr shadow-audio-bar h-50pxr w-300pxr flex cursor-pointer items-center justify-center overflow-hidden rounded border-solid bg-gray-700 text-center text-ellipsis whitespace-nowrap transition-all duration-500 ease-in-out', {
            'translate-y-4 opacity-0': isEntering,
            'translate-y-0 scale-y-100 opacity-100': !isEntering && !isRemoving,
            '-translate-y-4 scale-y-0 opacity-0': isRemoving,
            // 색상
            'text-secondary-green': type === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$toast$2f$types$2f$toast$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastType"].SUCCESS,
            'text-system-red': type === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$toast$2f$types$2f$toast$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastType"].ERROR,
            'text-black': type === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$toast$2f$types$2f$toast$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastType"].INFO
        }),
        children: text
    }, void 0, false, {
        fileName: "[project]/src/common/components/toast/Toast/Toast.client.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
};
_s(Toast, "oyocBZf3pTgUAKMccPCzK9Jd5UI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useToastStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToastActions"]
    ];
});
_c = Toast;
const __TURBOPACK__default__export__ = Toast;
var _c;
__turbopack_context__.k.register(_c, "Toast");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/toast/Toaster/Toaster.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useToastStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/hooks/stores/useToastStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$toast$2f$Toast$2f$Toast$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/toast/Toast/Toast.client.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const Toaster = ()=>{
    _s();
    const { toastList } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useToastStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToastInfo"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bottom-20pxr right-20pxr w-300pxr gap-30pxr fixed z-1 flex flex-col items-end",
        children: toastList.map((toast)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$toast$2f$Toast$2f$Toast$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                toast: toast
            }, toast.key, false, {
                fileName: "[project]/src/common/components/toast/Toaster/Toaster.client.tsx",
                lineNumber: 13,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/common/components/toast/Toaster/Toaster.client.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
};
_s(Toaster, "d0J1ZomJ/5Zwvc74Bejevt72L1s=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useToastStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToastInfo"]
    ];
});
_c = Toaster;
const __TURBOPACK__default__export__ = Toaster;
var _c;
__turbopack_context__.k.register(_c, "Toaster");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/errors/api-error.utils.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "extractApiError": (()=>extractApiError),
    "logApiError": (()=>logApiError)
});
const extractApiError = (err)=>{
    const e = err;
    return {
        status: e?.status ?? 0,
        code: e?.code ?? e?.body?.code ?? 'UNKNOWN',
        message: e?.message ?? e?.body?.message ?? 'Unknown error',
        body: e?.body,
        url: e?.url,
        method: e?.method
    };
};
const logApiError = (err, meta)=>{
    const data = extractApiError(err);
    console.error('[API ERROR]', {
        ...data,
        ...meta
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/utils/get-query-client.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * 서버, 클라이언트에 따라
 * QueryClient를 생성/관리하는 유틸
 */ __turbopack_context__.s({
    "getQueryClient": (()=>getQueryClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$mutationCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.85.1/node_modules/@tanstack/query-core/build/modern/mutationCache.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.85.1/node_modules/@tanstack/query-core/build/modern/queryCache.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.85.1/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$hydration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.85.1/node_modules/@tanstack/query-core/build/modern/hydration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+query-core@5.85.1/node_modules/@tanstack/query-core/build/modern/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$errors$2f$api$2d$error$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/errors/api-error.utils.ts [app-client] (ecmascript)");
;
;
function makeQueryClient() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
        queryCache: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCache"]({
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$errors$2f$api$2d$error$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logApiError"])(error, {
                    scope: 'react-query: query'
                });
            }
        }),
        mutationCache: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$mutationCache$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MutationCache"]({
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$errors$2f$api$2d$error$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logApiError"])(error, {
                    scope: 'react-query: mutation'
                });
            }
        }),
        defaultOptions: {
            queries: {
                staleTime: 60 * 1000,
                gcTime: 5 * 60 * 1000,
                retry: false
            },
            dehydrate: {
                // 쿼리를 직렬화할 때 포함할지 여부 결정하는 로직 - 요청 중인 쿼리도 포함
                shouldDehydrateQuery: (query)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$hydration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultShouldDehydrateQuery"])(query) || query.state.status === 'pending',
                // Next.js 서버 에러는 건들지 않음 - Next가 자체적으로 가공함
                shouldRedactErrors: (error)=>{
                    return false;
                }
            }
        }
    });
}
let browserQueryClient = undefined;
function getQueryClient() {
    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isServer"]) {
        // 서버 환경:
        // 매 요청마다 새로운 QueryClient 생성
        // 이유: 요청 간에 캐시가 공유되면 다른 사용자의 데이터가 섞이는 문제가 생김
        return makeQueryClient();
    } else {
        // 브라우저 환경:
        // 최초 렌더링 시에만 새 QueryClient 생성
        // 이후에는 기존 QueryClient를 재사용
        // 이유: 리렌더링 또는 React Suspense 발생 시마다
        // 새로 생성하면 캐시가 날아가므로 전역 유지 필요
        if (!browserQueryClient) browserQueryClient = makeQueryClient();
        return browserQueryClient;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/query-client-providers.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.85.1_react@19.1.1/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$2d$devtools$40$5$2e$85$2e$1_$40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2d$devtools$2f$build$2f$modern$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query-devtools@5.85.1_@tanstack+react-query@5.85.1_react@19.1.1__react@19.1.1/node_modules/@tanstack/react-query-devtools/build/modern/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$utils$2f$get$2d$query$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/utils/get-query-client.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
const QueryClientProviders = ({ children })=>{
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$utils$2f$get$2d$query$2d$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getQueryClient"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: queryClient,
        children: [
            children,
            ("TURBOPACK compile-time value", "development") === 'development' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$2d$devtools$40$5$2e$85$2e$1_$40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1_$5f$react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2d$devtools$2f$build$2f$modern$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReactQueryDevtools"], {
                initialIsOpen: false
            }, void 0, false, {
                fileName: "[project]/src/app/query-client-providers.tsx",
                lineNumber: 18,
                columnNumber: 50
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/query-client-providers.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
};
_c = QueryClientProviders;
const __TURBOPACK__default__export__ = QueryClientProviders;
var _c;
__turbopack_context__.k.register(_c, "QueryClientProviders");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_b6c104f5._.js.map