(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/12bbe_next_a6f18280._.js",
  "static/chunks/src_355e62b3._.js"
],
    source: "dynamic"
});
