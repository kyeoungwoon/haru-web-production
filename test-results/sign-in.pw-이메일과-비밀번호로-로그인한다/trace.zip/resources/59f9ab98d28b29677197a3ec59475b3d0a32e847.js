(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/assets/svgs/cta/CreateAiManagerIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2, _ellipse, _path3, _path4, _circle, _path5, _path6, _path7, _path8, _path9, _path0, _path1;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgCreateAiManagerIcon = function SvgCreateAiManagerIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 94 98"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M6.06 78.687c.933-2.637.539-4.976 0-8.172-.675-3.994-1.799-12.962 3.895-18.69 4.554-4.583 9.738-6.934 11.76-7.537M17.54 78.576c.326-1.14 3.528-6.102 3.121-9.448-.146-.953-.044-3.143 1.978-4.285"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M15.717 56.163c1.538-2.527 5.713-5.823 9.01-6.372 3.295-.55 3.587 1.691 3.162 2.642-.637 1.427-2.025 3.004-4.8 6.009-2.749 2.976-4.25 8.486-4.425 11.115M70.188 47.27c-2.136-1.833-7.448-5.078-11.61-3.39-.377.15-1.16.859-1.282 2.486M81.044 73.639c-.2-.804-.618-3.376-.377-5.425.302-2.561.029-12.23-4.193-15.017M80.32 53.417l-8.684-.57"
    })), _ellipse || (_ellipse = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("ellipse", {
        cx: 80.275,
        cy: 50.77,
        fill: "#111",
        rx: 2.307,
        ry: 3.186
    })), _path3 || (_path3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M77.002 52.326c-.867-1.643-.23-2.986.492-3.745.3-.316.742-.427 1.177-.406l.533.025a2 2 0 0 1 1.905 2.086l-.045 1.007a2 2 0 0 1-2.209 1.9l-.534-.057c-.545-.058-1.064-.326-1.319-.81M52.057 48.255a.79.79 0 1 1-1.571-.177.79.79 0 0 1 1.571.177"
    })), _path4 || (_path4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "m22.548 50.231-1.052-29.019c0-4.283.797-11.54 9.695-11.42s13.729.05 15.032 0M56.444 9.791H71.4c4.134.075 7.666 1.878 7.666 8.791s-.204 21.363-.505 28.902M66.036 83.301c-6.163.451-22.644 1.652-32.59 2.078-4.209 0-9.786-.541-10.447-8.115l-.451-18.108"
    })), _circle || (_circle = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("circle", {
        cx: 51.27,
        cy: 6.383,
        r: 2.656,
        stroke: "#111",
        strokeWidth: 1.5
    })), _path5 || (_path5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M46.61 8.243c.54 1.56-.224 2.7-1.947 3.075-.824.179-1.977.194-4.193.974-2.771.975-3.295 3.75-3.37 6.15-.06 1.919 1.048 2.549 2.995 2.624 5.666-.025 17.803.15 21.043.15 3.37 0 3.86-1.275 3.969-2.1.54-4.08-.899-5.714-2.172-6.299-.599-.275-2.351-.96-4.568-1.5s-2.616-1.274-2.396-2.324c.54-2.58.225-4.674 0-5.399-.25-1-1.707-2.91-5.542-2.55-4.792.45-4.493 5.25-3.819 7.2ZM72.848 46.934l.286-27.796c0-.6-.34-1.65-1.726-1.65-1.425 0-4.626.05-6.077 0"
    })), _path6 || (_path6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M36.748 17.488h-6.902c-.75-.075-2.191.36-1.951 2.7s1.4 38.63 1.95 56.482c-.024.9.376 2.67 2.176 2.55 1.37-.091 22.686-1.291 35.444-1.852M74.936 47.264l.395-27.61c0-.827-.36-2.03-2.4-1.729"
    })), _path7 || (_path7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M28.514 17.7c-.75 0-2.476 0-2.401 1.954.072 1.878.75 21.109.975 30.028M27.088 54.001l.675 23.45c.075.826.375 2.028 3.977 1.728"
    })), _path8 || (_path8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#E65787",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M35.779 30.444h14.063M35.873 35.434l30.361-.15M35.948 40.469l23.823-.226M36.177 48.29l11.72-.531"
    })), _path9 || (_path9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M75.815 47.814c-.55 1.025-1.758 2.417-.44 5.053M58.346 60.03c-.733.872-1.143 3.363 3.076 6.351 2.088 1.355 6.416 5.472 7.032 11.097M57.247 51.219c-.393.736-.565 2.152.66 3.51.602.668 1.544 1.322 2.966 1.873M57.906 54.729c-.785 1.136-1.501 3.465.44 5.3.502.476 2.172 1.357 3.076 1.737M73.163 96.707c-2.343-5.457-5.625-17.272 0-20.875 7.032-4.505 16.15 5.713 19.337 14.502"
    })), _path0 || (_path0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M80.43 48.142 54.688 46.29a1.8 1.8 0 0 0-.662.069c-3.31 1.016-2.22 2.87-.968 4.033.285.265.659.407 1.047.442l5.448.495M1.5 92.42c.55-5.127 4.373-15.591 10.877-14.273 6.504 1.319 8.277 13.074 8.35 18.787"
    })), _path1 || (_path1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M65.707 63.085c-4.175-4.724-6.592-8.46-6.043-13.184.306-2.633 1.823-3.72 3.211-2.405 1.843 1.746 3.271 3.943 5.278 4.822.393.183 1.641.55 3.487.55"
    })));
};
_c = SvgCreateAiManagerIcon;
const __TURBOPACK__default__export__ = SvgCreateAiManagerIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgCreateAiManagerIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/cta/CreateSnsEventAssistantIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2, _path3, _path4, _path5, _path6, _path7, _path8, _path9, _path0, _path1, _path10, _path11, _path12, _path13, _path14, _path15, _path16, _path17, _path18, _path19, _path20, _path21;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgCreateSnsEventAssistantIcon = function SvgCreateSnsEventAssistantIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 134 98"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M102.292 90.804c-4.032-3.285 1.431-3.671 4.667-3.454v2.147l7.746 1.96c-2.457 1.151-8.381 2.632-12.413-.653M123.479 88.844c-2.613.299-3.391-.871-3.453-1.493h5.6c.373.373.466 1.194-2.147 1.493"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#27998D",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M117.599 79.79c-2.893 0-4.48-.186-6.813-.373M119.839 80.91v8.96M113.119 81.377l-6.16-.467M116.012 82.31v9.054M115.919 91.55l3.92-1.586M110.692 79.417l-3.733 1.493M106.866 81.004v8.587M106.773 89.497l9.146 2.053M117.599 79.978v-2.614M125.719 87.257v-9.053M130.105 75.217v10.08M125.719 87.444l4.386-2.147M130.106 75.124l-9.894-.373M117.599 77.364l2.613-2.613M125.719 78.11l4.293-2.8M125.719 87.257h-5.507M117.692 77.364l5.32.187"
    })), _path3 || (_path3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M43.114 94.732c.093-2.613 10.546-1.773 11.2-1.68v1.68l3.173 2.24c-4.822.125-14.448-.149-14.373-2.24"
    })), _path4 || (_path4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#27998D",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M69.06 94.453v-9.52M60.94 96.879V86.426M54.22 94.452V84M54.22 84l7.374-1.867M69.06 84.839l-8.12 1.493M60.94 96.973l8.12-2.427M69.06 84.84l-7.467-2.707M54.22 84.092l6.813 2.24"
    })), _path5 || (_path5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M78.159 94.266c-1.718-2.987 3.764-3.423 6.72-3.267v2.147l9.613 1.12c-4.729 1.244-14.616 2.986-16.333 0"
    })), _path6 || (_path6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#27998D",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "m99.252 90.252-3.64 3.733M94.772 82.599l-9.427-.654M89.172 79.519l10.08.466M85.159 81.945l-.467 10.827M99.252 80.172v9.893M95.612 86.053v7.933M85.159 81.945l4.013-2.426M95.612 93.985l-11.013-1.12"
    })), _path7 || (_path7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M76.213 24.316c.404-.125 1.474-.243 2.52.28"
    })), _path8 || (_path8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M72.48 29.17c.721 0 1.306-.628 1.306-1.4 0-.774-.585-1.4-1.307-1.4-.721 0-1.306.626-1.306 1.4 0 .772.585 1.4 1.306 1.4M83.12 31.035c.72 0 1.306-.626 1.306-1.4s-.585-1.4-1.307-1.4c-.721 0-1.306.627-1.306 1.4s.585 1.4 1.306 1.4"
    })), _path9 || (_path9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M69.306 25.53c.093-.592.672-1.718 2.24-1.494M81.252 25.342c.747-.653 2.614-1.568 4.107 0M77.24 26.929c.87 1.43 2.09 4.498 0 5.32l-1.027.373M73.693 35.516c.217.59 1.045 1.568 2.613.746"
    })), _path0 || (_path0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M43.64 21.796c-3.062 10.08 5.444 17.39 10.08 19.786 4.18-2.538 10.142-3.827 12.693-4.2-3.174-2.613-4.138-7.404-4.387-9.613-1.68.56-6.16-1.587-4.107-5.973 1.643-3.51 3.423-1.712 4.107-.374l4.573 2.054c0-4.256 2.925-5.694 4.387-5.88.896-.598 1.867-2.551 2.24-3.454.448 3.51 5.04 6.067 7.28 6.907 2.912-2.315 5.257-.965 6.066 0l2.054-.28c4.013-1.369 11.218-6.048 7.933-13.813S86.479.609 83.492 2.289c-10.229-6.794-20.502 3.142-24.36 8.96-3.888-.684-12.431.467-15.492 10.547"
    })), _path1 || (_path1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "m66.506 23.569-4.48-2.334"
    })), _path10 || (_path10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeWidth: 1.5,
        d: "M76.119 23.383c0 3.219-2.2 5.693-4.76 5.693s-4.76-2.474-4.76-5.693c0-3.22 2.2-5.693 4.76-5.693s4.76 2.473 4.76 5.693ZM88.44 25.436c0 3.218-2.201 5.693-4.76 5.693-2.56 0-4.76-2.475-4.76-5.693 0-3.22 2.2-5.694 4.76-5.694s4.76 2.474 4.76 5.694Z"
    })), _path11 || (_path11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M88.626 43.427c7.168-5.75 3.08-13.502.093-16.706-1.642 7.765-5.444 11.106-7.093 11.853l2.613 1.4z"
    })), _path12 || (_path12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M62.586 23.383c-.155-1.712-2.146-5.787-4.293-1.96-.934 1.742-1.605 5.469 3.173 6.44"
    })), _path13 || (_path13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M61 22.73c-.436.373-1.084 1.343-.187 2.24M88.066 27.582c-.523 2.987-1.68 5.692-2.894 7.373-.758 1.052-1.987 2.379-3.555 3.535M61.933 27.862c-.062 3.796 1.419 9.427 8.213 12.414 1.045.459 2.073.722 3.071.829"
    })), _path14 || (_path14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M80.972 44.85c-1.493-.374-2.924.84-3.453 1.492-.28.592-.41 1.755 1.307 1.68 2.146-.093 2.8-3.173 5.32 1.774 2.016 3.957 2.146 11.729 1.96 15.12"
    })), _path15 || (_path15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M76.087 43.822c-.487 1.058-.883 3.043 1.432 2.52"
    })), _path16 || (_path16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M76.988 40.183c-1.307.56-3.202 2.576-2.456 3.92.094.155.374.448.747.373.164-.033.43-.317.808-.653.7-.624 1.783-1.424 3.299-1.12"
    })), _path17 || (_path17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M103.105 72.23c.934-4.573.024-15.304-11.4-25.608l-7.56-6.626-4.76-2.52-.932-.187-3.547.84-.374.373-1.213 2.24c-.187.467.616 1.008 1.96.56M66.133 37.756c-6.067.809-21.816 4.286-31.36 18.386-8.995 13.289 1.178 18.889 8.738 19.169M1 77.177l42.093-2.053"
    })), _path18 || (_path18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M54.573 74.657 133 71.24M47.581 75.454c.116.358.03.615-.419.654-1.33.114-2.91-1.948-3.533-2.994"
    })), _path19 || (_path19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M47.578 71.403c.664 1.061 1.822 2.696 2.837 3.623-.093.713-.789 1.796-2.834.428-.31-.966-2.082-2.664-2.082-2.768"
    })), _path20 || (_path20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M49.38 70.406c1.27 1.402 3.575 4.405 2.633 5.203-.168.142-.38.155-.624.072-.29-.098-.624-.334-.974-.654-1.015-.928-2.173-2.562-2.837-3.623"
    })), _path21 || (_path21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M38.938 74.058c2.125-2.66 8.917-8.428 12.797-4.936 1.548 1.545 3.477 4.336 2.368 5.476-.555.428-1.754-.142-2.528-1.283M46.508 58.884c-1.338 1.058-3.435 3.808-1.12 6.346"
    })));
};
_c = SvgCreateSnsEventAssistantIcon;
const __TURBOPACK__default__export__ = SvgCreateSnsEventAssistantIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgCreateSnsEventAssistantIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/cta/CreateTeamMoodTrackerIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2, _path3, _path4, _path5, _path6, _path7, _path8, _path9, _path0, _path1, _path10, _path11, _path12, _path13, _path14, _path15, _path16, _path17, _path18, _path19;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgCreateTeamMoodTrackerIcon = function SvgCreateTeamMoodTrackerIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 116 108"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M49.398 84.2c-1.325-6.841 3.59-22.466 6.212-29.424.874.414 8.19-1.011 10.537-4.413 1.878-2.722 5.066-3.791 6.626-4.276 2.07-.644 5.522-.552 6.166 1.011l.69 1.61c2.255 6.482.292 16.336-1.104 20.734l-5.154.92c-3.901-6.326-1.901-14.038-.414-17.103-1.582 2.133-6.027 4.383-8.052 5.241-.092 5.655-8.743 25.148-10.63 26.39-1.508.992-3.88-.046-4.877-.69"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "m52.704 85.327-.645 1.17m-2.025-1.912-1.229 3.246-.105.278c-.117.281-.198.753 0 1.154.14.283.418.532.92.655 1.215.296 5.784.618 7.916.742.368.046 1.068-.13.92-1.206-.147-1.076-.92-2.06-1.794-2.458-.71-.322-2.539-.822-4.603-.498zm1.381 2.04q.326-.078.644-.127zM74.107 70.112c-.046 1.365.078 4.05.415 4.46.415.507.922.553 4.013-.413 2.473-.773 3.46-.782 4.06-.874.415-.063.922-.12.922-1.15 0-1.287-.507-2.16-2.075-2.345-1.255-.147-3.045.614-3.783 1.012V69.56M68.202 23.827c-4.739.479-14.05 2.497-13.388 6.74.101.36.393.935.937 1.475.524.521 1.282 1.01 2.33 1.245"
    })), _path3 || (_path3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M55.751 32.042c1.482 2.306 5.826 7.313 11.346 8.9"
    })), _path4 || (_path4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M67.063 40.943c.337-.454 1.224-1.273 2.265-1.312M69.328 39.63c-.031-1.294-1.123-4.633-5.247-7.631"
    })), _path5 || (_path5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M62.889 33.072c.428-.693 1.742-2.163 3.577-2.504M73.144 31.76c.198.236.596.875.596 1.55M73.096 41.659c.94-.046 2.903-.184 3.235-.368.416-.23.509-.23.509-.69s-3.744.323-3.744-1.148c.34-.337.888-1.093.37-1.424-.517-.331-1.602.628-2.08 1.149-.492.52-1.599 1.341-2.08.459"
    })), _path6 || (_path6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M67.181 40.924c.416 1.21 1.914 3.382 4.576 2.39 2.661-.993 2.772-1.517 2.495-1.655M90.107 41.439c.647-.177 2.06-1 2.541-2.875s-.17-1.885-.554-1.655M87.704 40.081c.2-1.042.906-3.052 2.126-2.758"
    })), _path7 || (_path7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M88.212 38.38c-.85-.7-1.37.904-1.525 1.792-.96.295-1.324 1.686-1.386 2.345 2.224.228 3.805-.37 4.806-1.079.612-.434 1.008-.91 1.2-1.266.478-1.271 1.174-3.925.14-4.367-1.035-.441-1.325.552-1.34 1.103.11 1.251-.54 2.636-.878 3.173"
    })), _path8 || (_path8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M74.813 41.644c2.002 1.869 6.903 4.66 10.489.873M74.455 41.897c0 .867-.214 2.846-1.073 3.815M55.734 43.924c-1.89 2.55-4.535 8.315 0 10.97"
    })), _path9 || (_path9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#6664E3",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "m112.255 32.953 1.073-1.789M112.779 33.888l1.98-.092M112.374 34.98l1.192 1.55"
    })), _path0 || (_path0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M73.396 91.144h-32.21v15.739"
    })), _path1 || (_path1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M95.79 75.451H69.434v19.19"
    })), _path10 || (_path10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M113.208 53.453h-21.38v25.634M109.43 36.709v20.333M109.43 29.614v1.73M67.663 42.08l-26.397 3.036c-3.053-2.447-2.314-6.099-1.563-7.619l18.349-2.2M76.723 41.346l9.06-.87M92.404 39.514l5.933-.413 7.955-3.606c-.956-1.015-.431-1.92-.033-2.243l-7.922-1.849-31.364 2.612"
    })), _path11 || (_path11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#6664E3",
        d: "m36.86 37.536 2.69-.29c-1.866 4.178.272 7.02 1.637 8.126l-3.139.46c-2.623-3.195-1.947-6.77-1.188-8.297M106.579 35.696c-.998-1.042-.438-2.283-.022-2.683l3.79.935z"
    })), _path12 || (_path12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeWidth: 1.5,
        d: "M98.423 31.403c-.99 1.257-2.376 4.543 0 7.632"
    })), _path13 || (_path13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M75.626 24.631c.788-.485 6.722-.017 7.875-7.48 1.975.023 3.049-1.595 1.542-2.288-1.606-.828-1.486-2.349-1.195-3.245.463-1.175.491-2.409.391-2.667"
    })), _path14 || (_path14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M81.76 14.456c.224.002.41-.268.413-.604.004-.337-.174-.611-.399-.614-.224-.002-.409.268-.412.604s.174.61.398.614"
    })), _path15 || (_path15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M80.658 11.992c.33-.352 1.182-.867 1.954-.11M78.42 18.85c.606.932 1.27 1.197 2.562.596M73.462 12.318c-.14.309-.257 1.008.395 1.34"
    })), _path16 || (_path16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M66.512 9.155c-.769 4.204 1.635 7.368 3.379 9.801 1.86-1.006 4.912-3.397 3.742-3.655-1.23-.272-2.527-3.626-1.333-4.652 1.401-1.204 2.664.617 2.905 1.999l1.129-1.952c-.32-1.365-.445-3.76 1.608-2.418 2.053 1.343 5.063.991 6.312.648 2.462-1.763 6.288-5.874 1.892-8.218-3.657-1.95-8.415.515-11.32 2.73-1.966-.519-7.267-.015-8.314 5.717"
    })), _path17 || (_path17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M70.028 18.675c.888 1.07 1.33 1.959 1.275 3.8"
    })), _path18 || (_path18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M69.039 24.939c-.312-1.086-.494-3.157 1.266-2.754 2.2.503 6.685 2.679 6.356 3.885M76.661 27.766c1.61 1.49 1.968 2.444 2.206 4.233"
    })), _path19 || (_path19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#6664E3",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M1.241 76.112c2.187-.199 7.34 1.105 10.781 7.812.09.175.344.18.434.004 3.53-6.912 7.864-13.923 21.56-5.481.211.13.487-.106.383-.33-2.222-4.78-3.423-13.894 6.932-18.415.208-.09.198-.4-.02-.463l-2.678-.783c-.245-.072-.218-.409.036-.432 2.76-.248 6.652-.086 5.312 1.542-1.565 1.9-1.95 3.102-1.568 5.087"
    })));
};
_c = SvgCreateTeamMoodTrackerIcon;
const __TURBOPACK__default__export__ = SvgCreateTeamMoodTrackerIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgCreateTeamMoodTrackerIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/Cta/CtaIcons.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "CtaIconsState": (()=>CtaIconsState)
});
var CtaIconsState = /*#__PURE__*/ function(CtaIconsState) {
    CtaIconsState["AI_MEETING_MANAGER"] = "AI_MEETING_MANAGER";
    CtaIconsState["SNS_EVENT_ASSISTANT"] = "SNS_EVENT_ASSISTANT";
    CtaIconsState["TEAM_MOOD_TRACKER"] = "TEAM_MOOD_TRACKER";
    return CtaIconsState;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/Cta/CtaIcons.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$cta$2f$CreateAiManagerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/cta/CreateAiManagerIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$cta$2f$CreateSnsEventAssistantIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/cta/CreateSnsEventAssistantIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$cta$2f$CreateTeamMoodTrackerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/cta/CreateTeamMoodTrackerIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/Cta/CtaIcons.types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const CtaIcons = ({ state, className })=>{
    switch(state){
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtaIconsState"].AI_MEETING_MANAGER:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$cta$2f$CreateAiManagerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[96px] w-[91px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/Cta/CtaIcons.tsx",
                lineNumber: 14,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtaIconsState"].SNS_EVENT_ASSISTANT:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$cta$2f$CreateSnsEventAssistantIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[97px] w-[132px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/Cta/CtaIcons.tsx",
                lineNumber: 16,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtaIconsState"].TEAM_MOOD_TRACKER:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$cta$2f$CreateTeamMoodTrackerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[107px] w-[113px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/Cta/CtaIcons.tsx",
                lineNumber: 18,
                columnNumber: 14
            }, this);
        default:
            return null;
    }
};
_c = CtaIcons;
const __TURBOPACK__default__export__ = CtaIcons;
var _c;
__turbopack_context__.k.register(_c, "CtaIcons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/cta/ImageCta/ImageCta.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/Cta/CtaIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/Cta/CtaIcons.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/PlusIcons/PlusIcons.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/types/file-type.enum.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
const imageCtaConfig = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileType"].AI_MEETING_MANAGER]: {
        title: 'AI 회의 진행 매니저',
        color: 'text-primary',
        ctaIconState: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtaIconsState"].AI_MEETING_MANAGER,
        plusIconState: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_16_PRIMARY,
        marginBottom: 'mb-20pxr'
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileType"].SNS_EVENT_ASSISTANT]: {
        title: 'SNS 이벤트 어시스턴트',
        color: 'text-secondary-green',
        ctaIconState: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtaIconsState"].SNS_EVENT_ASSISTANT,
        plusIconState: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_16_SECONDARY_GREEN,
        marginBottom: 'mb-20pxr'
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileType"].TEAM_MOOD_TRACKER]: {
        title: '팀 분위기 트래커',
        color: 'text-secondary-blue',
        ctaIconState: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CtaIconsState"].TEAM_MOOD_TRACKER,
        plusIconState: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_16_SECONDARY_BLUE,
        marginBottom: 'mb-14pxr'
    }
};
const ImageCta = ({ type, onClick })=>{
    const config = imageCtaConfig[type];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "border-stroke-100 py-28pxr flex h-56 w-82.5 cursor-pointer flex-col items-center justify-center rounded-2xl border-[1.5px] border-dashed bg-white text-center hover:bg-gray-600",
        onClick: onClick,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-t4-bd mb-10pxr text-black",
                children: config.title
            }, void 0, false, {
                fileName: "[project]/src/common/components/cta/ImageCta/ImageCta.client.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `gap-2pxr flex items-center ${config.color} ${config.marginBottom}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        state: config.plusIconState
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/cta/ImageCta/ImageCta.client.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-bt1-sb",
                        children: "Create New"
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/cta/ImageCta/ImageCta.client.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/cta/ImageCta/ImageCta.client.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$Cta$2f$CtaIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                state: config.ctaIconState
            }, void 0, false, {
                fileName: "[project]/src/common/components/cta/ImageCta/ImageCta.client.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/cta/ImageCta/ImageCta.client.tsx",
        lineNumber: 40,
        columnNumber: 5
    }, this);
};
_c = ImageCta;
const __TURBOPACK__default__export__ = ImageCta;
var _c;
__turbopack_context__.k.register(_c, "ImageCta");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/cta/ImageCta/ImageCtaSkeleton.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const ImageCtaSkeleton = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "animate-bg-pulse h-56 w-82.5 animate-pulse rounded-2xl"
    }, void 0, false, {
        fileName: "[project]/src/common/components/cta/ImageCta/ImageCtaSkeleton.tsx",
        lineNumber: 2,
        columnNumber: 10
    }, this);
};
_c = ImageCtaSkeleton;
const __TURBOPACK__default__export__ = ImageCtaSkeleton;
var _c;
__turbopack_context__.k.register(_c, "ImageCtaSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/featured-file/AiManagerFilleIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2, _path3;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgAiManagerFilleIcon = function SvgAiManagerFilleIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 16 16"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#89A4BB",
        fillRule: "evenodd",
        d: "m3.791 10.927.597-1.793h.752l.597 1.793 1.791.598v.751l-1.791.598-.597 1.793h-.751l-.598-1.793L2 12.276v-.751z",
        clipRule: "evenodd"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#89A4BB",
        d: "M8.923 1.334h-.189zM8.722 1.334H7.244c-.531 0-.97 0-1.327.03-.37.03-.711.095-1.032.258a2.64 2.64 0 0 0-1.153 1.154c-.163.32-.228.662-.258 1.033-.03.358-.03.796-.03 1.328v2.801h2.31l.66 1.981 2.308.66v2.642h1.479c.53 0 .97 0 1.326-.029.371-.03.712-.095 1.032-.259a2.64 2.64 0 0 0 1.153-1.154c.164-.32.229-.662.259-1.033C14 10.389 14 9.95 14 9.418v-2.8H9.382a.66.66 0 0 1-.66-.661zM14 6.61v-.195z"
    })), _path3 || (_path3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#89A4BB",
        d: "M13.87 5.296a2.7 2.7 0 0 0-.259-.56c-.164-.267-.388-.491-.684-.787l-1.539-1.54c-.296-.297-.52-.522-.787-.686a2.6 2.6 0 0 0-.56-.258v3.831z"
    })));
};
_c = SvgAiManagerFilleIcon;
const __TURBOPACK__default__export__ = SvgAiManagerFilleIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgAiManagerFilleIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/featured-file/SnsAssistFileIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgSnsAssistFileIcon = function SvgSnsAssistFileIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 24 24"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#89A4BB",
        fillRule: "evenodd",
        d: "M15.241 3H8.76c-.805 0-1.47 0-2.01.044-.563.046-1.08.145-1.565.392a4 4 0 0 0-1.748 1.748c-.247.485-.346 1.002-.392 1.564C3 7.29 3 7.954 3 8.758v6.483c0 .805 0 1.47.044 2.01.046.563.145 1.08.392 1.565a4 4 0 0 0 1.748 1.748c.485.247 1.002.346 1.564.392C7.29 21 7.954 21 8.758 21h6.483c.805 0 1.47 0 2.01-.044.563-.046 1.08-.145 1.565-.392a4 4 0 0 0 1.748-1.748c.247-.485.346-1.002.392-1.564.044-.541.044-1.206.044-2.01V8.758c0-.805 0-1.47-.044-2.01-.046-.563-.145-1.08-.392-1.565a4 4 0 0 0-1.748-1.748c-.485-.247-1.002-.346-1.564-.392C16.71 3 16.046 3 15.242 3m-3.715 3.842-1.171 3.513-3.513 1.17v.95l3.513 1.17 1.17 3.513h.95l1.17-3.513 3.513-1.17v-.95l-3.513-1.17-1.17-3.513z",
        clipRule: "evenodd"
    })));
};
_c = SvgSnsAssistFileIcon;
const __TURBOPACK__default__export__ = SvgSnsAssistFileIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgSnsAssistFileIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/featured-file/TeamMoodFileIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgTeamMoodFileIcon = function SvgTeamMoodFileIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 16 16"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#89A4BB",
        fillRule: "evenodd",
        d: "m4.788 1.334-.697 2.064L2 4.086v.557l2.091.688.697 2.064h.565L6.05 5.33l2.091-.688v-.557l-.939-.31h2.036v1.47l-2.382.88-.893 2.35H4.178l-.88-2.312c-.013.281-.013.611-.013.996v2.046c0 .473 0 .863.026 1.181.027.33.086.634.233.919.229.442.593.802 1.04 1.027.29.145.597.203.932.23.322.026.718.026 1.197.026h.125l1.804 2.078 1.805-2.078h.125c.48 0 .875 0 1.197-.026.334-.027.642-.085.93-.23a2.37 2.37 0 0 0 1.042-1.027c.147-.285.205-.589.233-.919C14 10.07 14 9.68 14 9.206V7.16c0-.473 0-.863-.026-1.181-.028-.33-.086-.634-.233-.919A2.37 2.37 0 0 0 12.7 4.033c-.29-.145-.597-.203-.931-.23-.322-.026-.718-.026-1.197-.026h-3.37l-1.152-.38-.697-2.063zm4.763 5.288-.4 1.182-1.198.394v.558l1.198.394.4 1.182h.564l.4-1.182 1.198-.394v-.558l-1.198-.394-.4-1.182z",
        clipRule: "evenodd"
    })));
};
_c = SvgTeamMoodFileIcon;
const __TURBOPACK__default__export__ = SvgTeamMoodFileIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgTeamMoodFileIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "FeaturedFileIconsState": (()=>FeaturedFileIconsState)
});
var FeaturedFileIconsState = /*#__PURE__*/ function(FeaturedFileIconsState) {
    FeaturedFileIconsState["SIZE_24_AI_MANAGER_FILE"] = "SIZE_24_AI_MANAGER_FILE";
    FeaturedFileIconsState["SIZE_20_AI_MANAGER_FILE"] = "SIZE_20_AI_MANAGER_FILE";
    FeaturedFileIconsState["SIZE_16_AI_MANAGER_FILE"] = "SIZE_16_AI_MANAGER_FILE";
    FeaturedFileIconsState["SIZE_24_SNS_ASSISTANT_FILE"] = "SIZE_24_SNS_ASSISTANT_FILE";
    FeaturedFileIconsState["SIZE_20_SNS_ASSISTANT_FILE"] = "SIZE_20_SNS_ASSISTANT_FILE";
    FeaturedFileIconsState["SIZE_16_SNS_ASSISTANT_FILE"] = "SIZE_16_SNS_ASSISTANT_FILE";
    FeaturedFileIconsState["SIZE_24_TEAM_MOOD_FILE"] = "SIZE_24_TEAM_MOOD_FILE";
    FeaturedFileIconsState["SIZE_20_TEAM_MOOD_FILE"] = "SIZE_20_TEAM_MOOD_FILE";
    FeaturedFileIconsState["SIZE_16_TEAM_MOOD_FILE"] = "SIZE_16_TEAM_MOOD_FILE";
    return FeaturedFileIconsState;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$AiManagerFilleIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/featured-file/AiManagerFilleIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$SnsAssistFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/featured-file/SnsAssistFileIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$TeamMoodFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/featured-file/TeamMoodFileIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const FeaturedFileIcons = ({ state, className })=>{
    switch(state){
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_24_AI_MANAGER_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$AiManagerFilleIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, 'h-24pxr w-24pxr')
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx",
                lineNumber: 14,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_20_AI_MANAGER_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$AiManagerFilleIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, 'h-20pxr w-20pxr')
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx",
                lineNumber: 16,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_16_AI_MANAGER_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$AiManagerFilleIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, 'h-16pxr w-16pxr')
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx",
                lineNumber: 18,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_24_SNS_ASSISTANT_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$SnsAssistFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, 'h-24pxr w-24pxr')
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx",
                lineNumber: 20,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_20_SNS_ASSISTANT_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$SnsAssistFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, 'h-20pxr w-20pxr')
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx",
                lineNumber: 22,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_16_SNS_ASSISTANT_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$SnsAssistFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, 'h-16pxr w-16pxr')
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx",
                lineNumber: 24,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_24_TEAM_MOOD_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$TeamMoodFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, 'h-24pxr w-24pxr')
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx",
                lineNumber: 26,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_20_TEAM_MOOD_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$TeamMoodFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, 'h-20pxr w-20pxr')
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx",
                lineNumber: 28,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_16_TEAM_MOOD_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$featured$2d$file$2f$TeamMoodFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(className, 'h-16pxr w-16pxr')
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx",
                lineNumber: 30,
                columnNumber: 14
            }, this);
        default:
            return null;
    }
};
_c = FeaturedFileIcons;
const __TURBOPACK__default__export__ = FeaturedFileIcons;
var _c;
__turbopack_context__.k.register(_c, "FeaturedFileIcons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/etc/BoxedFile/BoxedFile.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "DocumentType": (()=>DocumentType)
});
var DocumentType = /*#__PURE__*/ function(DocumentType) {
    DocumentType["AI_MEETING_MANAGER"] = "AI_MEETING_MANAGER";
    DocumentType["SNS_EVENT_ASSISTANT"] = "SNS_EVENT_ASSISTANT";
    DocumentType["TEAM_MOOD_TRACKER"] = "TEAM_MOOD_TRACKER";
    return DocumentType;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/FeaturedFileIcons/FeaturedFileIcons.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/etc/BoxedFile/BoxedFile.types.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const BoxedFile = ({ title, lastOpened, thumbnailUrl, documentType, onClick })=>{
    _s();
    const documentIconMap = {
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DocumentType"].AI_MEETING_MANAGER]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_24_AI_MANAGER_FILE,
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DocumentType"].SNS_EVENT_ASSISTANT]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_24_SNS_ASSISTANT_FILE,
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DocumentType"].TEAM_MOOD_TRACKER]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeaturedFileIconsState"].SIZE_24_TEAM_MOOD_FILE
    };
    const iconState = documentIconMap[documentType];
    const iconClass = 'absolute top-13pxr left-14pxr h-6 w-6';
    const [formattedTime, setFormattedTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BoxedFile.useEffect": ()=>{
            const openedDate = new Date(lastOpened ?? '');
            const today = new Date();
            const isSameDate = today.getFullYear() === openedDate.getFullYear() && today.getMonth() === openedDate.getMonth() && today.getDate() === openedDate.getDate();
            const time = isSameDate ? `마지막으로 연 시간 ${openedDate.toLocaleTimeString()}` : openedDate.toLocaleDateString();
            setFormattedTime(time);
        }
    }["BoxedFile.useEffect"], [
        lastOpened
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-244pxr h-191pxr py-17pxr shrink-0 rounded-2xl bg-gray-700 px-5 hover:cursor-pointer",
        onClick: onClick,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-2.5 flex w-full shrink-0 flex-col items-start gap-0.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-t5-sb",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-cap2-rg text-gray-300",
                        children: formattedTime
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-108pxr rounded-10pxr relative w-full shrink-0 bg-white",
                children: [
                    iconState && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$FeaturedFileIcons$2f$FeaturedFileIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        state: iconState,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(iconClass)
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                        lineNumber: 53,
                        columnNumber: 23
                    }, this),
                    thumbnailUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: thumbnailUrl,
                        alt: "파일 이미지",
                        className: "rounded-10pxr h-full w-full object-cover object-top pt-10"
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                        lineNumber: 56,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "pt-47pxr pb-13pxr flex flex-col gap-1 px-3.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-9pxr rounded-3pxr bg-gray-600"
                            }, void 0, false, {
                                fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                                lineNumber: 63,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-9pxr rounded-3pxr bg-gray-600"
                            }, void 0, false, {
                                fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                                lineNumber: 64,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-9pxr rounded-3pxr bg-gray-600"
                            }, void 0, false, {
                                fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                                lineNumber: 65,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-9pxr rounded-3pxr bg-gray-600"
                            }, void 0, false, {
                                fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                        lineNumber: 62,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
};
_s(BoxedFile, "km7kRKYz/0FFj/ftzXSK+2w+5e4=");
_c = BoxedFile;
const __TURBOPACK__default__export__ = BoxedFile;
var _c;
__turbopack_context__.k.register(_c, "BoxedFile");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/etc/BoxedFile/BoxedFileSkelton.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const BoxedFileSkeleton = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-244pxr h-191pxr animate-bg-pulse rounded-2xl"
    }, void 0, false, {
        fileName: "[project]/src/common/components/etc/BoxedFile/BoxedFileSkelton.tsx",
        lineNumber: 2,
        columnNumber: 10
    }, this);
};
_c = BoxedFileSkeleton;
const __TURBOPACK__default__export__ = BoxedFileSkeleton;
var _c;
__turbopack_context__.k.register(_c, "BoxedFileSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/features/on-boarding/mocks/dummy-files.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "dummyFiles": (()=>dummyFiles)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/etc/BoxedFile/BoxedFile.types.ts [app-client] (ecmascript)");
;
const now = new Date();
const docTypes = [
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DocumentType"].AI_MEETING_MANAGER,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DocumentType"].SNS_EVENT_ASSISTANT,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DocumentType"].TEAM_MOOD_TRACKER
];
const dummyFiles = Array.from({
    length: 5
}, (_, index)=>{
    const date = new Date(now);
    date.setHours(date.getHours() - index * 4);
    const title = `${date.getMonth() + 1}월 ${date.getDate()}일 회의록`;
    return {
        title,
        lastOpened: date.toISOString(),
        documentType: docTypes[index % docTypes.length],
        thumbnailUrl: ''
    };
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/workspace/[workspaceId]/(main)/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/types/file-type.enum.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$cta$2f$ImageCta$2f$ImageCta$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/cta/ImageCta/ImageCta.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$cta$2f$ImageCta$2f$ImageCtaSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/cta/ImageCta/ImageCtaSkeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/etc/BoxedFile/BoxedFile.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFileSkelton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/etc/BoxedFile/BoxedFileSkelton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$on$2d$boarding$2f$mocks$2f$dummy$2d$files$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/on-boarding/mocks/dummy-files.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
const MainWithWorkspacePage = ()=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const { workspaceId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    // 임시 로딩 상태 (실제 프로젝트에서는 API fetch 기준으로 변경)
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const ctaItems = [
        {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileType"].AI_MEETING_MANAGER,
            onClick: ()=>router.push(`${pathname}/ai-meeting-manager`)
        },
        {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileType"].SNS_EVENT_ASSISTANT,
            onClick: ()=>router.push(`${pathname}/sns-event-assistant`)
        },
        {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileType"].TEAM_MOOD_TRACKER,
            onClick: ()=>router.push(`${pathname}/team-mood-tracker`)
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-74pxr flex flex-col",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-36pxr mb-16pxr text-t3-bd",
                            children: "새로 시작하기"
                        }, void 0, false, {
                            fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                            lineNumber: 49,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "gap-20pxr md:gap-18pxr flex",
                            children: isLoading ? Array.from({
                                length: ctaItems.length
                            }).map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$cta$2f$ImageCta$2f$ImageCtaSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, index, false, {
                                    fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                                    lineNumber: 53,
                                    columnNumber: 19
                                }, this)) : ctaItems.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$cta$2f$ImageCta$2f$ImageCta$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    type: item.type,
                                    onClick: item.onClick
                                }, index, false, {
                                    fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                                    lineNumber: 56,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                            lineNumber: 50,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                    lineNumber: 48,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-16pxr text-t3-bd",
                            children: "최근 항목"
                        }, void 0, false, {
                            fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "gap-18pxr md:gap-16pxr grid grid-cols-4",
                            children: isLoading ? Array.from({
                                length: 8
                            }).map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFileSkelton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, index, false, {
                                    fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                                    lineNumber: 65,
                                    columnNumber: 61
                                }, this)) : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$on$2d$boarding$2f$mocks$2f$dummy$2d$files$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dummyFiles"].map((file, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$etc$2f$BoxedFile$2f$BoxedFile$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    title: file.title,
                                    lastOpened: file.lastOpened,
                                    documentType: file.documentType,
                                    thumbnailUrl: file.thumbnailUrl,
                                    onClick: ()=>{}
                                }, file.title + idx, false, {
                                    fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                                    lineNumber: 67,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                            lineNumber: 63,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                    lineNumber: 61,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-74pxr mb-92pxr flex flex-col",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-16pxr text-t3-bd",
                            children: "내 캘린더"
                        }, void 0, false, {
                            fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                            lineNumber: 80,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: "수현이 캘린더 구현 후 그대로 대체 예정"
                        }, void 0, false, {
                            fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                            lineNumber: 81,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
                    lineNumber: 79,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
            lineNumber: 47,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/workspace/[workspaceId]/(main)/page.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
};
_s(MainWithWorkspacePage, "OrfC3qFOaYDbhD50RsPwhEQOi+k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = MainWithWorkspacePage;
const __TURBOPACK__default__export__ = MainWithWorkspacePage;
var _c;
__turbopack_context__.k.register(_c, "MainWithWorkspacePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_a1971c5c._.js.map