(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_9ee7d760._.js",
  "static/chunks/node_modules__pnpm_89f0e0f5._.js"
],
    source: "dynamic"
});
