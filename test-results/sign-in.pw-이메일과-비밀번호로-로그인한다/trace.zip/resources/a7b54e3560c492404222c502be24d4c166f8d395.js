(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/common/constants/query-key.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lukemorales$2b$query$2d$key$2d$factory$40$1$2e$3$2e$4_$40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1_$40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1_$2f$node_modules$2f40$lukemorales$2f$query$2d$key$2d$factory$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@lukemorales+query-key-factory@1.3.4_@tanstack+query-core@5.85.1_@tanstack+react-query@5.85.1_react@19.1.1_/node_modules/@lukemorales/query-key-factory/dist/index.mjs [app-client] (ecmascript)");
;
// 도메인(기능)별로 키를 그룹화합니다.
const queryKeys = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$lukemorales$2b$query$2d$key$2d$factory$40$1$2e$3$2e$4_$40$tanstack$2b$query$2d$core$40$5$2e$85$2e$1_$40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1_$2f$node_modules$2f40$lukemorales$2f$query$2d$key$2d$factory$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createQueryKeyStore"])({
    workspaces: {
        // 매개변수가 없는 키는 null로 정의합니다.
        all: null,
        myWorkspaces: null,
        // 매개변수가 있는 키는 함수로 정의합니다.
        detail: (workspaceId)=>[
                workspaceId
            ],
        members: (workspaceId)=>[
                workspaceId,
                'members'
            ],
        recentDocuments: (workspaceId)=>[
                workspaceId,
                'recentDocuments'
            ],
        search: (workspaceId, title)=>[
                workspaceId,
                'search',
                title
            ],
        calendar: (workspaceId, start, end)=>[
                workspaceId,
                'calendar',
                start,
                end
            ]
    },
    meetings: {
        all: null,
        meetingMinutesDetail: (meetingId)=>[
                'meetings',
                'minutes',
                'detail',
                meetingId
            ],
        meetingMinutesList: (workspaceId)=>[
                'meetings',
                'minutes',
                'list',
                workspaceId
            ],
        editMeetingMinutesTitle: (meetingId)=>[
                'meetings',
                'minutes',
                'editTitle',
                meetingId
            ],
        editMeetingMinutesProceeding: (meetingId)=>[
                'meetings',
                'minutes',
                'editProceeding',
                meetingId
            ]
    },
    moodTracker: {
        all: null,
        detail: (moodTrackerHashedId)=>[
                moodTrackerHashedId
            ],
        report: (moodTrackerHashedId)=>[
                moodTrackerHashedId,
                'report'
            ]
    },
    user: {
        // 매개변수가 없는 키는 null로 정의합니다.
        all: null,
        // 매개변수가 있는 키는 함수로 정의합니다.
        detail: ()=>[
                'user',
                'detail'
            ],
        edit: ()=>[
                'user',
                'edit'
            ]
    }
});
const __TURBOPACK__default__export__ = queryKeys;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/hooks/queries/useAfterQuery.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useAfterQuery": (()=>useAfterQuery)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.85.1_react@19.1.1/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function useAfterQuery({ enabled, onSuccess, onError, extra, ...queryOptions }) {
    _s();
    // 이전 데이터와 에러를 저장할 ref
    const prevDataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(undefined);
    const prevErrorRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(undefined);
    // React Query의 useQuery 실행
    // 전달받은 queryOptions와 enabled를 합쳐 실행
    const queryResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        ...queryOptions,
        enabled
    });
    /**
   * 성공 시 콜백 실행
   * - enabled가 true일 때만 작동
   * - 이전 데이터(prevDataRef)와 현재 데이터(queryResult.data)가 다를 때만 실행
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAfterQuery.useEffect": ()=>{
            if (!enabled) return;
            if (queryResult.isSuccess && onSuccess) {
                if (prevDataRef.current !== queryResult.data) {
                    onSuccess(queryResult.data);
                    prevDataRef.current = queryResult.data;
                }
            }
        }
    }["useAfterQuery.useEffect"], [
        enabled,
        queryResult.isSuccess,
        queryResult.data,
        onSuccess
    ]);
    /**
   * 에러 시 콜백 실행
   * - enabled가 true일 때만 작동
   * - 이전 에러(prevErrorRef)와 현재 에러(queryResult.error)가 다를 때만 실행
   */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAfterQuery.useEffect": ()=>{
            if (!enabled) return;
            if (queryResult.isError && onError) {
                if (prevErrorRef.current !== queryResult.error) {
                    onError(queryResult.error);
                    prevErrorRef.current = queryResult.error;
                }
            }
        }
    }["useAfterQuery.useEffect"], [
        enabled,
        queryResult.isError,
        queryResult.error,
        onError
    ]);
    /**
   * queryResult에 extra 필드 추가해서 반환
   * - extra가 함수면 queryResult를 인자로 실행해 결과 반환
   * - 값이면 그대로 반환
   */ return {
        ...queryResult,
        extra: typeof extra === 'function' ? extra(queryResult) : extra
    };
}
_s(useAfterQuery, "3XjQOBfhO6B4xVyrb6TC05wlv68=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/errors/ApiError.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * 공통 에러 객체 클래스
 *
 * 모든 API 호출에서 에러를 통일된 형태로 다룸
 */ __turbopack_context__.s({
    "ApiError": (()=>ApiError)
});
class ApiError extends Error {
    status;
    body;
    code;
    isSuccess;
    rawText;
    url;
    method;
    constructor(opts){
        super(opts.message);
        Object.setPrototypeOf(this, new.target.prototype);
        this.status = opts.status;
        this.code = opts.code;
        this.isSuccess = opts.body?.isSuccess;
        this.body = opts.body;
        this.rawText = opts.rawText;
        this.url = opts.url;
        this.method = opts.method;
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            status: this.status,
            code: this.code,
            isSuccess: this.isSuccess,
            url: this.url,
            method: this.method,
            body: this.body,
            rawText: this.rawText
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/utils/join-url.utils.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "joinURL": (()=>joinURL)
});
const joinURL = (baseURL, path)=>{
    // URL 결합 시 baseURL의 끝, path의 시작 부분에 있는 / 를 제거하여
    // 올바른 URL을 생성하도록 합니다.
    const trimmedBase = baseURL.replace(/\/+$/, '');
    const trimmedPath = path.replace(/^\/+/, '');
    return `${trimmedBase}/${trimmedPath}`;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/sentry.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "captureApiError": (()=>captureApiError),
    "captureRenderError": (()=>captureRenderError)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$core$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$currentScopes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@sentry+core@9.46.0/node_modules/@sentry/core/build/esm/currentScopes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$core$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$exports$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@sentry+core@9.46.0/node_modules/@sentry/core/build/esm/exports.js [app-client] (ecmascript)");
;
const captureApiError = (error, context, type = 'unknown-error')=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$core$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$currentScopes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withScope"])((scope)=>{
        // 사용자 정의 태그를 추가하여 수집 대상을 분류
        scope.setTags({
            is_custom_event: 'true',
            type
        });
        if (context) {
            scope.setContext('요청 정보', {
                url: context.url,
                status: context.status,
                requestBody: context.requestBody
            });
            scope.setContext('응답 정보', {
                status: context.status,
                responseHeaders: context.responseHeaders,
                responseBody: context.responseBody
            });
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$core$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$exports$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureException"])(error); // Sentry로 에러 전송
        console.log('Sentry로 api 에러 전송');
    });
};
const captureRenderError = (error, context)=>{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$core$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$currentScopes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["withScope"])((scope)=>{
        scope.setTags({
            is_custom_event: 'true',
            type: 'rendering-error'
        });
        if (context) {
            scope.setContext('렌더링 컨텍스트', context);
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$core$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2f$core$2f$build$2f$esm$2f$exports$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureException"])(error);
        console.log('Sentry로 렌더링 에러 전송');
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/fetcher.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "createFetcher": (()=>createFetcher),
    "defaultApi": (()=>defaultApi),
    "shouldReportToSentry": (()=>shouldReportToSentry),
    "withCredentialsApi": (()=>withCredentialsApi)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$errors$2f$ApiError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/errors/ApiError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$utils$2f$join$2d$url$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/utils/join-url.utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sentry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sentry.ts [app-client] (ecmascript)");
;
;
;
/**
 * 정상 응답 처리 함수
 */ const handleResponse = async (res)=>{
    return res.json();
};
const shouldReportToSentry = (status)=>{
    // 서버오류/네트워크 오류만 전송, 비즈니스 4xx는 제외
    if (status >= 500 || status === 0) return true;
    // 특정 4xx 코드는 무시
    // const ignoreCodes = new Set(['LASTOPENED4001']);
    // if (ignoreCodes.has(code)) return false;
    return false;
};
// 비정상 응답 처리 함수
const handleResponseError = async (res, url, requestBodyRaw, method)=>{
    const contentType = res.headers.get('content-type');
    const rawText = await res.text();
    // requestBody 직렬화 (로깅용)
    let requestBody = '';
    try {
        requestBody = typeof requestBodyRaw === 'string' ? requestBodyRaw : JSON.stringify(requestBodyRaw);
    } catch  {
        // 직렬화 불가 값 처리
        requestBody = '[Non-serializable body]';
    }
    // JSON만 파싱
    let responseBody = {
        isSuccess: false,
        code: 'UNKNOWN',
        message: `API error ${res.status}`
    };
    if (contentType?.includes('application/json')) {
        try {
            responseBody = JSON.parse(rawText);
        } catch  {
        // 파싱 실패시 문자열 유지
        }
    }
    // 공통 에러 객체 생성
    const error = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$errors$2f$ApiError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"]({
        status: res.status,
        message: responseBody.message,
        code: responseBody.code,
        body: responseBody,
        rawText,
        url,
        method
    });
    if (shouldReportToSentry(res.status)) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sentry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureApiError"])(error, {
            url,
            method,
            status: res.status,
            requestBody,
            responseHeaders: Object.fromEntries(res.headers.entries()),
            responseBody
        }, 'server-error');
    }
    throw error;
};
const createFetcher = ({ baseURL = ("TURBOPACK compile-time value", "https://api.haru.it.kr/api/v1"), headers, fetchOptions } = {})=>/**
   * createFetcher가 최종적으로 반환하는 fetcher 함수
   * @param path - API Request 경로 입니다.
   * @param options - fetch 함수에 전달되는 options
   */ async (path, options)=>{
        if (!baseURL) {
            throw new Error('API baseURL이 누락되었습니다. NEXT_PUBLIC_SERVER_API_BASE_URL 환경 변수를 확인하세요.');
        }
        // 안전한 URL 생성
        const url = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$utils$2f$join$2d$url$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["joinURL"])(baseURL, path);
        // body가 FormData인지 확인합니다.
        const isFormData = options?.body instanceof FormData;
        // 1. Headers 클래스를 사용해 모든 헤더를 일관되고 안전하게 관리합니다.
        //    (as any 같은 타입 단언 없이 타입 안정성을 지킬 수 있습니다.)
        const mergedHeaders = new Headers(headers);
        // 2. API 호출 시점에 전달된 개별 헤더를 병합합니다.
        //    (이전 헤더를 덮어쓰므로 순서에 상관없이 동작합니다.)
        if (options?.headers) {
            new Headers(options.headers).forEach((value, key)=>{
                mergedHeaders.set(key, value);
            });
        }
        // 3. 기본 헤더(Accept, Authorization)를 설정합니다.
        //    (이미 설정된 값이 없다면 기본값을 사용합니다.)
        if (!mergedHeaders.has('Accept')) {
            mergedHeaders.set('Accept', 'application/json');
        }
        const requiresAuth = options?.auth !== false;
        // TODO: PRODUCTION 환경에서는 삭제해야 합니다. by. @kyeoungwoon
        // 1. 인증이 필요하고, 수동으로 설정된 Authorization 헤더가 없으며, 토큰이 존재할 때만 헤더를 추가합니다.
        if (requiresAuth && !mergedHeaders.has('Authorization') && ("TURBOPACK compile-time value", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJ1c2VySWQiOjgsImlhdCI6MTc1NTE0NjAzNiwiZXhwIjoxNzU3NzM4MDM2fQ.1MF5HfXXw1Bvf39sDwdA_SfPFfUUkhCA_fEIBwShzWuV-ZZ3fl-vY3HsugxkjPbvv609NiD4Mk0NBeTMnIjcdQ")) {
            mergedHeaders.set('Authorization', `Bearer ${("TURBOPACK compile-time value", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJ1c2VySWQiOjgsImlhdCI6MTc1NTE0NjAzNiwiZXhwIjoxNzU3NzM4MDM2fQ.1MF5HfXXw1Bvf39sDwdA_SfPFfUUkhCA_fEIBwShzWuV-ZZ3fl-vY3HsugxkjPbvv609NiD4Mk0NBeTMnIjcdQ")}`);
        }
        // TODO: axios 기준, withCredentials 옵션을 사용해야 합니다.
        // localStorage나, cookie에 저장된 credentials를 loading 할 수 있도록 ..
        // 4. FormData 여부에 따라 Content-Type을 최종적으로 제어합니다.
        if (isFormData) {
            // FormData일 경우, 다른 곳에서 실수로 Content-Type을 설정했더라도
            // 여기서 확실하게 제거하여 브라우저가 자동으로 설정하도록 보장합니다.
            mergedHeaders.delete('Content-Type');
        } else {
            // FormData가 아니면서 Content-Type이 설정되지 않은 경우에만
            // 기본값으로 'application/json'을 설정합니다.
            if (!mergedHeaders.has('Content-Type')) {
                mergedHeaders.set('Content-Type', 'application/json');
            }
        }
        /**
     * fetch API를 호출할 때 사용할 최종 옵션 객체를 생성합니다.
     */ const mergedOptions = {
            ...fetchOptions,
            ...options,
            headers: mergedHeaders
        };
        try {
            const res = await fetch(url, mergedOptions);
            // 응답 인터셉터
            // 응답 성공시
            if (res.ok) {
                return handleResponse(res);
            }
            // 응답 에러시
            return handleResponseError(res, url, mergedOptions.body, mergedOptions.method);
        } catch (error) {
            // 네트워크 관련 오류 Sentry에 전송
            // - fetch 자체가 실패한 경우 (인터넷 연결 끊김, DNS 오류, CORS 등)
            // - 연결 지연으로 인한 timeout
            if (error instanceof Error && (error.message.includes('Failed to fetch') || error.message.includes('timeout') || error.message.includes('NetworkError'))) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sentry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureApiError"])(error, undefined, 'network-error');
            // 그 외 예상치 못한 시스템 오류 Sentry에 전송
            // 다음의 사용자가 의도적으로 취소한 요청은 제외:
            // - AbortError: 사용자가 fetch를 중단
            // - canceled: AbortController나 빠른 네비게이션 등으로 요청 취소
            // - Navigation aborted: Next.js 내부 요청 취소
            } else if (error instanceof Error && // 넘어감 목록
            !error.message.includes('AbortError') && !error.message.includes('canceled') && !error.message.includes('Navigation aborted')) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sentry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureApiError"])(error, undefined, 'unknown-error');
            }
            throw error;
        }
    };
const defaultApi = createFetcher({
    fetchOptions: {
        cache: 'no-store'
    }
});
const withCredentialsApi = createFetcher({
    fetchOptions: {
        cache: 'no-store',
        credentials: 'include'
    },
    headers: {
        Authorization: `Bearer ${("TURBOPACK compile-time value", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJ1c2VySWQiOjgsImlhdCI6MTc1NTE0NjAzNiwiZXhwIjoxNzU3NzM4MDM2fQ.1MF5HfXXw1Bvf39sDwdA_SfPFfUUkhCA_fEIBwShzWuV-ZZ3fl-vY3HsugxkjPbvv609NiD4Mk0NBeTMnIjcdQ")}`
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/workspace/api-end-point.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "WORKSPACE_API_END_POINTS": (()=>WORKSPACE_API_END_POINTS)
});
const WORKSPACE_API_END_POINTS = {
    WORKSPACE_DETAIL: (workspaceId)=>`workspaces/${workspaceId}/edit`,
    RECENT_DOCUMENTS: (workspaceId)=>`workspaces/${workspaceId}/sidebar`,
    WORKSPACE_EDIT: (workspaceId)=>`workspaces/${workspaceId}`,
    SEARCH_DOCUMENTS: (workspaceId)=>`workspaces/${workspaceId}`,
    CALENDAR: (workspaceId)=>`workspaces/${workspaceId}/calendar`,
    MY_WORKSPACE: '/workspaces/me'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/workspace/get/apis/fetchMyWorkspaces.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$api$2d$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/api-end-point.constants.ts [app-client] (ecmascript)");
;
;
const fetchMyWorkspaces = async ()=>{
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$api$2d$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_API_END_POINTS"].MY_WORKSPACE, {
        method: 'GET',
        auth: true
    });
    return response;
};
const __TURBOPACK__default__export__ = fetchMyWorkspaces;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/workspace/get/queries/useFetchMyWorkspaces.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$query$2d$key$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/query-key.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/hooks/queries/useAfterQuery.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$apis$2f$fetchMyWorkspaces$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/get/apis/fetchMyWorkspaces.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
/**
 * 내 워크 스페이스 리스트를 가져오는 훅
 */ const useFetchMyWorkspaces = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAfterQuery"])({
        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$query$2d$key$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].workspaces.myWorkspaces.queryKey,
        queryFn: {
            "useFetchMyWorkspaces.useAfterQuery": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$apis$2f$fetchMyWorkspaces$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])()
        }["useFetchMyWorkspaces.useAfterQuery"],
        enabled: true,
        retry: false,
        extra: {
            "useFetchMyWorkspaces.useAfterQuery": (queryResult)=>queryResult.data?.result ?? []
        }["useFetchMyWorkspaces.useAfterQuery"]
    });
};
_s(useFetchMyWorkspaces, "/MY3m4/k0JOoh72XWghwZcmb4/I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAfterQuery"]
    ];
});
const __TURBOPACK__default__export__ = useFetchMyWorkspaces;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/types/file-type.enum.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "FileType": (()=>FileType),
    "SNS_EVENT_ASSISTANT_LINK": (()=>SNS_EVENT_ASSISTANT_LINK)
});
var FileType = /*#__PURE__*/ function(FileType) {
    FileType["AI_MEETING_MANAGER"] = "AI_MEETING_MANAGER";
    FileType["SNS_EVENT_ASSISTANT"] = "SNS_EVENT_ASSISTANT";
    FileType["TEAM_MOOD_TRACKER"] = "TEAM_MOOD_TRACKER";
    return FileType;
}({});
const SNS_EVENT_ASSISTANT_LINK = 'SNS_EVENT_ASSISTANT_LINK';
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ROUTES": (()=>ROUTES)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/types/file-type.enum.ts [app-client] (ecmascript)");
;
const ROUTES = {
    // ===== onboarding 관련 =====
    ONBOARDING: '/onboarding',
    // ===== main 관련 =====
    ROOT: '/',
    LANDING: {
        BASE: '/landing',
        MODAL: {
            PRIVACY_POLICY: '/landing/terms?type=privacyPolicy',
            TERMS_OF_SERVICE: '/landing/terms?type=termsOfService'
        }
    },
    WORKSPACE_MAIN: (workspaceId)=>`/workspace/${workspaceId ?? ''}`,
    MAIN: {
        BASE_WITHOUT_WS: '/workspace',
        BASE_WITH_WS: (workspaceId)=>`/workspace/${workspaceId}`,
        MODAL: {
            PRIVACY_POLICY: (workspaceId)=>workspaceId ? `/workspace/${workspaceId}/terms?type=privacyPolicy` : `/workspace/terms?type=privacPolicy`,
            TERMS_OF_SERVICE: (workspaceId)=>workspaceId ? `/workspace/${workspaceId}/terms?type=termsOfService` : `/workspace/terms?type=termsOfService`
        }
    },
    // ===== ai-meeting-manager 관련 =====
    AI_MEETING_MANAGER: {
        BASE: (workspaceId)=>`/workspace/${workspaceId}/ai-meeting-manager`,
        // 회의 단일 조회
        MEETING: (workspaceId, meetingId)=>`/workspace/${workspaceId}/ai-meeting-manager/${meetingId}/meeting`,
        // 회의록 단일 조회
        MINUTES: (workspaceId, meetingId)=>`/workspace/${workspaceId}/ai-meeting-manager/${meetingId}/minutes`,
        // 모달 관련
        MODAL: {
            // 회의 생성 모달
            CREATE: (workspaceId)=>`/workspace/${workspaceId}/ai-meeting-manager/create`,
            // 단일 회의 삭제 확인 모달
            CONFIRM_DELETE: (workspaceId)=>`/workspace/${workspaceId}/ai-meeting-manager/confirm-delete`
        }
    },
    //  ===== sns event assistant 관련 =====
    SNS_EVENT_ASSISTANT: (workspaceId)=>`/workspace/${workspaceId}/sns-event-assistant`,
    //  ===== team mood tracker 관련 =====
    TEAM_MOOD_TRACKER: (workspaceId)=>`/workspace/${workspaceId}/team-mood-tracker`,
    //  ===== calendar =====
    CALENDAR: (workspaceId)=>`/workspace/${workspaceId}/calendar`,
    // ===== 파일 조회 =====
    BUILD_DOCUMENT_ROUTE: (workspaceId, documentType, documentId)=>{
        const routeMapper = {
            [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileType"].AI_MEETING_MANAGER]: (workspaceId, documentId)=>`/workspace/${workspaceId}/ai-meeting-manager/${documentId}/minutes`,
            // TODO: 파일 조회에 연결되는 path 작성해주세요
            [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileType"].SNS_EVENT_ASSISTANT]: (workspaceId, documentId)=>`/workspace/${workspaceId}/sns-event-assistant/${documentId}`,
            [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$file$2d$type$2e$enum$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileType"].TEAM_MOOD_TRACKER]: (workspaceId, documentId)=>`/workspace/${workspaceId}/team-mood-tracker/${documentId}`
        };
        return `${routeMapper[documentType](workspaceId, documentId)}`;
    },
    AUTH: {
        LOGIN: '/auth/login',
        REGISTER: '/auth/register',
        LOGOUT: '/auth/logout',
        GOOGLE_OAUTH: '/auth/login/google/callback'
    },
    // ===== 기타 컴포넌트에서 호출 =====
    MODAL: {
        SETTING: (workspaceId)=>`/workspace/${workspaceId}/settings`
    },
    // ===== 404 페이지 =====
    NOT_FOUND: '/404'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/images/404/image.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/image.a95a1d3b.png");}}),
"[project]/src/assets/images/404/image.png.mjs { IMAGE => \"[project]/src/assets/images/404/image.png (static in ecmascript)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$404$2f$image$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/images/404/image.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$404$2f$image$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 1188,
    height: 798,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAsElEQVR42gGlAFr/AAICAgIGBgYHRERESuHh4eHo6OjocnJycgMDAwMAAAAAACwjJCtNQkRtTUJEnVNLTFxHR0dLXVxcY0lAQEkOCwsOAH9jZH7Zpanxclth4iocH2NFLTBuNTg6a15OT18fGhseAC8mJi+2k5W3g2lrmiAgI28cHB9SNjc8ppFtcKh4XF53AAcHBwczMjI0YlFSYTYrLT4KCgsRLi0wfJ99gcdaR0haRtMx8kwVopQAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/buttons/38px/CreateWorkspaceButton/CreateWorkSpaceButton.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
'use client';
;
;
/**
 * '워크스페이스 생성하기 38px' 버튼
 */ const CreateWorkSpaceButton = ({ onClick, ...props })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-bt1-sb h-38pxr w-171pxr rounded-7pxr inline-flex items-center justify-center bg-gray-100 text-white'),
        ...props,
        onClick: onClick,
        children: "워크스페이스 생성하기"
    }, void 0, false, {
        fileName: "[project]/src/common/components/buttons/38px/CreateWorkspaceButton/CreateWorkSpaceButton.client.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
};
_c = CreateWorkSpaceButton;
const __TURBOPACK__default__export__ = CreateWorkSpaceButton;
var _c;
__turbopack_context__.k.register(_c, "CreateWorkSpaceButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$404$2f$image$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$404$2f$image$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/src/assets/images/404/image.png.mjs { IMAGE => "[project]/src/assets/images/404/image.png (static in ecmascript)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$buttons$2f$38px$2f$CreateWorkspaceButton$2f$CreateWorkSpaceButton$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/buttons/38px/CreateWorkspaceButton/CreateWorkSpaceButton.client.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const WithoutWorkspaceSection = ()=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mb-292pxr flex flex-col",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-36pxr text-t3-bd mb-16pxr",
                    children: "새로 시작하기"
                }, void 0, false, {
                    fileName: "[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-1030pxr h-534pxr border-stroke-200 rounded-16pxr flex flex-col items-center border border-solid",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-396pxr h-266pxr mt-30pxr mb-36pxr",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$404$2f$image$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$404$2f$image$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                alt: "워크스페이스 없음"
                            }, void 0, false, {
                                fileName: "[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx",
                                lineNumber: 20,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx",
                            lineNumber: 19,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-t3-sb mb-8pxr",
                            children: "아직 소속된 워크스페이스가 없어요!"
                        }, void 0, false, {
                            fileName: "[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx",
                            lineNumber: 22,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-18pxr text-b2-rg text-center whitespace-pre-line text-gray-200",
                            children: `워크스페이스에 참여하고\n회의 진행, 이벤트 운영, 팀 분위기 설문 등\nHaRu의 다양한 기능을 이용해 보세요!`
                        }, void 0, false, {
                            fileName: "[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$buttons$2f$38px$2f$CreateWorkspaceButton$2f$CreateWorkSpaceButton$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            onClick: ()=>{
                                router.push(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].ONBOARDING);
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
};
_s(WithoutWorkspaceSection, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = WithoutWorkspaceSection;
const __TURBOPACK__default__export__ = WithoutWorkspaceSection;
var _c;
__turbopack_context__.k.register(_c, "WithoutWorkspaceSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/MainPageSection/MainPageSection.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchMyWorkspaces$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/get/queries/useFetchMyWorkspaces.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$MainPageSection$2f$WithoutWorkspaceSection$2f$WithoutWorkspaceSection$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/MainPageSection/WithoutWorkspaceSection/WithoutWorkspaceSection.client.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const MainPageSection = ()=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { extra: myWorkspaces, isFetching } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchMyWorkspaces$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MainPageSection.useEffect": ()=>{
            if (!isFetching && myWorkspaces && myWorkspaces?.length > 0) {
                const id = myWorkspaces[0]?.workspaceId;
                router.replace(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].WORKSPACE_MAIN(id));
            }
        }
    }["MainPageSection.useEffect"], [
        isFetching,
        myWorkspaces,
        router
    ]);
    if (isFetching) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        children: "로드 중..."
    }, void 0, false, {
        fileName: "[project]/src/common/components/MainPageSection/MainPageSection.client.tsx",
        lineNumber: 24,
        columnNumber: 26
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$MainPageSection$2f$WithoutWorkspaceSection$2f$WithoutWorkspaceSection$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/common/components/MainPageSection/MainPageSection.client.tsx",
        lineNumber: 26,
        columnNumber: 10
    }, this);
};
_s(MainPageSection, "tDP8bmn+wAAhq584t8hk0JCvIPU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchMyWorkspaces$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = MainPageSection;
const __TURBOPACK__default__export__ = MainPageSection;
var _c;
__turbopack_context__.k.register(_c, "MainPageSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/types/gnbs.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 공통 GNB 섹션 구분
__turbopack_context__.s({
    "GnbSection": (()=>GnbSection),
    "SectionOptionKey": (()=>SectionOptionKey),
    "SnsGnbTabType": (()=>SnsGnbTabType)
});
var GnbSection = /*#__PURE__*/ function(GnbSection) {
    GnbSection["MAIN"] = "MAIN";
    GnbSection["AI_MEETING_MANAGER"] = "AI_MEETING_MANAGER";
    GnbSection["SNS_EVENT_ASSISTANT"] = "SNS_EVENT_ASSISTANT";
    GnbSection["TEAM_MOOD_TRACKER"] = "TEAM_MOOD_TRACKER";
    GnbSection["CALENDAR"] = "CALENDAR";
    GnbSection["CUSTOM"] = "CUSTOM";
    return GnbSection;
}({});
var SectionOptionKey = /*#__PURE__*/ function(SectionOptionKey) {
    SectionOptionKey["SERVICE_HOME"] = "SERVICE_HOME";
    SectionOptionKey["ALL_MEETINGS"] = "ALL_MEETINGS";
    SectionOptionKey["ALL_EVENTS"] = "ALL_EVENTS";
    SectionOptionKey["SNS_LINK_MANAGE"] = "SNS_LINK_MANAGE";
    SectionOptionKey["ALL_REPORTS"] = "ALL_REPORTS";
    SectionOptionKey["CALENDAR"] = "CALENDAR";
    return SectionOptionKey;
}({});
var SnsGnbTabType = /*#__PURE__*/ function(SnsGnbTabType) {
    SnsGnbTabType["ALL_EVENTS"] = "ALL_EVENTS";
    SnsGnbTabType["SNS_LINK_MANAGE"] = "SNS_LINK_MANAGE";
    return SnsGnbTabType;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "LeftGnbIconsState": (()=>LeftGnbIconsState)
});
var LeftGnbIconsState = /*#__PURE__*/ function(LeftGnbIconsState) {
    LeftGnbIconsState["HOME"] = "HOME";
    LeftGnbIconsState["HOME_DISABLED"] = "HOME_DISABLED";
    LeftGnbIconsState["AI_MANAGER"] = "AI_MANAGER";
    LeftGnbIconsState["AI_MANAGER_DISABLED"] = "AI_MANAGER_DISABLED";
    LeftGnbIconsState["MY_CALENDAR"] = "MY_CALENDAR";
    LeftGnbIconsState["MY_CALENDAR_DISABLED"] = "MY_CALENDAR_DISABLED";
    LeftGnbIconsState["SNS_ASSISTANT"] = "SNS_ASSISTANT";
    LeftGnbIconsState["SNS_ASSISTANT_DISABLED"] = "SNS_ASSISTANT_DISABLED";
    LeftGnbIconsState["TEAM_MOOD_TRACKER"] = "TEAM_MOOD_TRACKER";
    LeftGnbIconsState["TEAM_MOOD_TRACKER_DISABLED"] = "TEAM_MOOD_TRACKER_DISABLED";
    LeftGnbIconsState["RECENT_FILE"] = "RECENT_FILE";
    return LeftGnbIconsState;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/constants/gnbs.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "GnbLeftNavItemIconState": (()=>GnbLeftNavItemIconState),
    "GnbLeftNavItems": (()=>GnbLeftNavItems),
    "GnbSectionLabels": (()=>GnbSectionLabels),
    "GnbSectionPaths": (()=>GnbSectionPaths),
    "SectionOptionLabels": (()=>SectionOptionLabels),
    "SnsGnbTabLabels": (()=>SnsGnbTabLabels),
    "sectionConfigs": (()=>sectionConfigs)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/types/gnbs.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
;
;
;
const GnbSectionLabels = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].MAIN]: '메인 홈',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].AI_MEETING_MANAGER]: 'AI 회의 진행 매니저',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].SNS_EVENT_ASSISTANT]: 'SNS 이벤트 어시스턴트',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].TEAM_MOOD_TRACKER]: '팀 분위기 트래커',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CALENDAR]: '내 캘린더',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CUSTOM]: '사용자 정의'
};
const GnbLeftNavItems = [
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].MAIN,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].AI_MEETING_MANAGER,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].SNS_EVENT_ASSISTANT,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].TEAM_MOOD_TRACKER,
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CALENDAR
];
const GnbSectionPaths = (workspaceId)=>({
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].MAIN]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].WORKSPACE_MAIN(workspaceId),
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].AI_MEETING_MANAGER]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].AI_MEETING_MANAGER.BASE(workspaceId),
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].SNS_EVENT_ASSISTANT]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].SNS_EVENT_ASSISTANT(workspaceId),
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].TEAM_MOOD_TRACKER]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].TEAM_MOOD_TRACKER(workspaceId),
        [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CALENDAR]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].CALENDAR(workspaceId)
    });
_c = GnbSectionPaths;
const GnbLeftNavItemIconState = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].MAIN]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].HOME,
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].AI_MEETING_MANAGER]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].AI_MANAGER,
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].SNS_EVENT_ASSISTANT]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].SNS_ASSISTANT,
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].TEAM_MOOD_TRACKER]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].TEAM_MOOD_TRACKER,
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CALENDAR]: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].MY_CALENDAR
};
const SectionOptionLabels = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].SERVICE_HOME]: '서비스 홈',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].ALL_MEETINGS]: '전체 회의록',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].ALL_EVENTS]: '전체 이벤트',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].SNS_LINK_MANAGE]: 'SNS 링크 관리',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].ALL_REPORTS]: '전체 리포트',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].CALENDAR]: '캘린더'
};
const SnsGnbTabLabels = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SnsGnbTabType"].ALL_EVENTS]: '전체 이벤트',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SnsGnbTabType"].SNS_LINK_MANAGE]: 'SNS 링크 관리'
};
const sectionConfigs = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].MAIN]: {
        title: GnbSectionLabels[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].MAIN],
        options: [
            {
                label: SectionOptionLabels[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].SERVICE_HOME],
                key: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].SERVICE_HOME
            }
        ]
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].AI_MEETING_MANAGER]: {
        title: GnbSectionLabels[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].AI_MEETING_MANAGER],
        options: [
            {
                label: SectionOptionLabels[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].ALL_MEETINGS],
                key: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].ALL_MEETINGS
            }
        ]
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].SNS_EVENT_ASSISTANT]: {
        title: GnbSectionLabels[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].SNS_EVENT_ASSISTANT],
        options: []
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].TEAM_MOOD_TRACKER]: {
        title: GnbSectionLabels[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].TEAM_MOOD_TRACKER],
        options: [
            {
                label: SectionOptionLabels[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].ALL_REPORTS],
                key: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].ALL_REPORTS
            }
        ]
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CALENDAR]: {
        title: GnbSectionLabels[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CALENDAR],
        options: [
            {
                label: SectionOptionLabels[__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].CALENDAR],
                key: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionOptionKey"].CALENDAR
            }
        ]
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CUSTOM]: (title)=>({
            title,
            options: []
        })
};
var _c;
__turbopack_context__.k.register(_c, "GnbSectionPaths");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/CategoryOption/CategoryOption.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
'use client';
;
;
const CategoryOption = ({ label, count, active, onClick, className = '', ariaLabel, disabled })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: onClick,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-bt3-sb h-30pxr rounded-7pxr px-9pxr flex items-center justify-center gap-2.5 py-1.5', disabled ? 'cursor-not-allowed' : active ? 'text-bt3-sb cursor-default bg-gray-600 text-black' : 'text-cap1-md cursor-pointer bg-white text-gray-200 hover:bg-gray-600', className),
        "aria-label": ariaLabel ?? `${label} 카테고리`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: label
            }, void 0, false, {
                fileName: "[project]/src/common/components/CategoryOption/CategoryOption.client.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            typeof count === 'number' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-cap1-rg text-gray-400",
                children: count
            }, void 0, false, {
                fileName: "[project]/src/common/components/CategoryOption/CategoryOption.client.tsx",
                lineNumber: 31,
                columnNumber: 37
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/CategoryOption/CategoryOption.client.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
};
_c = CategoryOption;
const __TURBOPACK__default__export__ = CategoryOption;
var _c;
__turbopack_context__.k.register(_c, "CategoryOption");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/individual/CalenderIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgCalenderIcon = function SvgCalenderIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 19 18"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#767676",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.25,
        d: "M6.364 5.25v-3m6 3v-3m-6.75 6h7.5m-9 7.5h10.5a1.5 1.5 0 0 0 1.5-1.5v-9a1.5 1.5 0 0 0-1.5-1.5h-10.5a1.5 1.5 0 0 0-1.5 1.5v9a1.5 1.5 0 0 0 1.5 1.5"
    })));
};
_c = SvgCalenderIcon;
const __TURBOPACK__default__export__ = SvgCalenderIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgCalenderIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/individual/CongratulationIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2, _path3, _path4, _g, _circle, _path5, _path6, _circle2, _circle3, _path7, _path8, _path9, _path0, _path1, _path10, _defs;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgCongratulationIcon = function SvgCongratulationIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 203 175"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#CongratulationIcon_svg__a)",
        d: "M106.996 174.47c41.052 0 74.331-33.28 74.331-74.332s-33.279-74.331-74.331-74.331-74.332 33.279-74.332 74.331 33.28 74.332 74.332 74.332"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#E1DCEB",
        d: "m69.41 109.082 24.01-65.928 65.866 69.644-57.312 26.308c-19.37 8.893-39.857-9.996-32.564-30.024"
    })), _path3 || (_path3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        stroke: "#111",
        d: "M94.46 42.779c.437-.41 1.075-.647 1.954-.666.882-.02 1.972.18 3.255.608 2.566.858 5.802 2.592 9.494 5.079 7.378 4.97 16.49 12.883 25.578 22.566 9.087 9.682 16.409 19.278 20.901 26.956 2.249 3.842 3.774 7.181 4.467 9.796.346 1.307.478 2.408.402 3.288-.076.875-.351 1.497-.789 1.908s-1.076.647-1.955.667c-.882.02-1.973-.181-3.256-.61-2.566-.857-5.801-2.59-9.493-5.077-7.379-4.97-16.491-12.885-25.579-22.567-9.087-9.682-16.408-19.277-20.9-26.955-2.249-3.843-3.775-7.182-4.467-9.797-.347-1.307-.478-2.408-.402-3.287.076-.876.352-1.498.79-1.91Z"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("mask", {
        id: "CongratulationIcon_svg__b",
        width: 93,
        height: 99,
        x: 67,
        y: 43,
        maskUnits: "userSpaceOnUse",
        style: {
            maskType: "alpha"
        }
    }, _path4 || (_path4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#E1DCEB",
        d: "m69.41 109.082 24.01-65.928 65.866 69.644-57.312 26.308c-19.37 8.893-39.857-9.996-32.564-30.024"
    }))), _g || (_g = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("g", {
        fillRule: "evenodd",
        clipRule: "evenodd",
        mask: "url(#CongratulationIcon_svg__b)"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        d: "M91.955 100.185C78.758 82.903 72.08 62.299 69.928 48.467l10.626-1.654c1.939 12.45 8.057 31.272 19.948 46.845 11.779 15.426 29.012 27.455 53.589 27.455v10.754c-28.682 0-48.828-14.254-62.136-31.682"
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#fff",
        d: "M93.372 96.88C80.175 79.598 73.498 58.995 71.345 45.162l10.626-1.654c1.938 12.45 8.057 31.273 19.948 46.845 11.779 15.426 29.012 27.455 53.589 27.455v10.754c-28.682 0-48.828-14.254-62.136-31.682"
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#fff",
        d: "M76.374 121.903C63.177 104.621 56.5 84.018 54.347 70.186l10.626-1.655c1.939 12.451 8.057 31.273 19.948 46.846 11.779 15.425 29.012 27.455 53.589 27.455v10.754c-28.682 0-48.828-14.254-62.136-31.683"
    }))), _circle || (_circle = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("circle", {
        cx: 122.495,
        cy: 135.881,
        r: 18.978,
        fill: "#E65787"
    })), _path5 || (_path5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#fff",
        fillRule: "evenodd",
        d: "M130.174 130.122a1.9 1.9 0 0 1-.023 2.684l-9.01 8.856a1.9 1.9 0 0 1-2.661 0l-3.642-3.58a1.897 1.897 0 1 1 2.661-2.707l2.312 2.273 7.679-7.549a1.9 1.9 0 0 1 2.684.023",
        clipRule: "evenodd"
    })), _path6 || (_path6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        stroke: "#111",
        d: "M159.436 45.204a.765.765 0 0 1-.991.432l-.002-.001a.76.76 0 0 1-.433-.987c1.288-3.273 1.646-6.555 2.189-9.867a.766.766 0 0 1 1.512.246c-.583 3.56-.97 6.862-2.275 10.177ZM166.03 52.727a.77.77 0 0 1-1.066-.192.76.76 0 0 1 .13-1.013l.061-.047c6.386-4.42 12.64-10.372 17.294-16.61a.77.77 0 0 1 1.073-.155.76.76 0 0 1 .157 1.065c-4.744 6.358-11.131 12.436-17.649 16.95zM182.965 58.038c-4.948 1.414-10.36 2.148-15.325.778l-.479-.139a.764.764 0 0 1-.507-.952c.122-.4.55-.628.955-.504 4.594 1.401 9.551.792 14.041-.402l.891-.247a.762.762 0 1 1 .424 1.466Z"
    })), _circle2 || (_circle2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("circle", {
        cx: 167.411,
        cy: 68.19,
        r: 3.796,
        fill: "#417BA4"
    })), _circle3 || (_circle3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("circle", {
        cx: 135.78,
        cy: 28.97,
        r: 3.796,
        fill: "#417BA4"
    })), _path7 || (_path7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#417BA4",
        d: "M143.081 45.709c-.327-1.357-2.256-1.357-2.584 0l-.424 1.756a1.33 1.33 0 0 1-.98.98l-1.757.425c-1.356.327-1.356 2.256 0 2.584l1.757.424c.485.117.863.495.98.98l.424 1.757c.328 1.356 2.257 1.356 2.584 0l.425-1.757c.117-.485.495-.863.98-.98l1.757-.424c1.356-.328 1.356-2.257 0-2.584l-1.757-.424a1.33 1.33 0 0 1-.98-.98z"
    })), _path8 || (_path8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#E3E3E3",
        fillRule: "evenodd",
        d: "M126.902 16.514a1.9 1.9 0 0 1-1.072 2.46c-2.784 1.096-6.352 4.622-8.735 9.012-1.813 3.341-2.694 6.715-2.324 9.477 1.114-1.59 2.448-2.895 3.995-3.733 2.773-1.502 5.937-1.342 9 .745 2.677 1.824 3.768 4.42 3.479 7.005-.276 2.473-1.784 4.708-3.831 6.112-2.076 1.425-4.834 2.082-7.678 1.211-1.613-.493-3.159-1.448-4.574-2.898-1.35 5.256-1.302 11.84.93 17.662a1.899 1.899 0 0 1-3.545 1.358c-2.943-7.679-2.56-16.449-.161-22.836l-.202-.375c-2.525-4.766-1.013-10.77 1.575-15.539 2.609-4.806 6.746-9.185 10.682-10.733a1.9 1.9 0 0 1 2.461 1.072m-10.254 25.248c1.434 2.036 2.921 3.02 4.199 3.412 1.61.493 3.18.14 4.42-.712 1.271-.872 2.069-2.178 2.206-3.404.124-1.111-.264-2.37-1.844-3.447-2.003-1.364-3.647-1.306-5.055-.543-1.404.76-2.795 2.352-3.926 4.694",
        clipRule: "evenodd"
    })), _path9 || (_path9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#CCC6D9",
        fillRule: "evenodd",
        d: "M188.166 90.739c-19.893-7.394-35.117 1.8-40.04 7a3.162 3.162 0 1 1-4.594-4.35c6.252-6.603 24.047-17.05 46.838-8.58a3.163 3.163 0 0 1-2.204 5.93",
        clipRule: "evenodd"
    })), _path0 || (_path0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#417BA4",
        fillRule: "evenodd",
        d: "M167.928 97.386c.444-.163.911-.379 1.271-.692.428-.371.602-.85.719-1.353.15-.647.21-1.337.392-1.985.067-.24.197-.331.252-.372a.6.6 0 0 1 .417-.119.6.6 0 0 1 .519.347c.02.039.047.098.065.18.013.06.021.246.035.324q.05.285.09.57c.09.635.142 1.175.426 1.758.386.793.773 1.277 1.298 1.492.507.208 1.113.169 1.888.006q.111-.028.219-.047a.64.64 0 0 1 .735.519c.067.35-.15.69-.488.767l-.209.045c-1.047.266-2.26 1.217-2.964 2.049-.217.257-.535.974-.859 1.432-.24.338-.508.56-.734.639a.64.64 0 0 1-.384.018.65.65 0 0 1-.378-.259.8.8 0 0 1-.126-.301 2 2 0 0 1-.012-.286c-.066-.234-.147-.462-.206-.698-.141-.562-.416-.918-.744-1.389a2.57 2.57 0 0 0-1.118-.937 9 9 0 0 1-.748-.216.8.8 0 0 1-.431-.384.745.745 0 0 1 .167-.876.83.83 0 0 1 .381-.186c.131-.028.478-.044.527-.046m2.971-.917q.034.081.075.162c.565 1.16 1.197 1.808 1.966 2.123l.025.01a8.7 8.7 0 0 0-1.335 1.251c-.146.173-.34.532-.549.901-.191-.636-.502-1.085-.893-1.647a3.8 3.8 0 0 0-.998-1.016 4.4 4.4 0 0 0 .832-.558 3.25 3.25 0 0 0 .877-1.226",
        clipRule: "evenodd"
    })), _path1 || (_path1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        stroke: "#111",
        d: "M56.317 97.424a1.22 1.22 0 0 1 1.731.097c.453.505.41 1.283-.092 1.736-2.435 2.19-3.816 4.895-4.219 8.151a1.224 1.224 0 0 1-1.367 1.071h-.002a1.23 1.23 0 0 1-1.063-1.373h-.001c.475-3.851 2.124-7.081 5.013-9.682Z"
    })), _path10 || (_path10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#111",
        stroke: "#111",
        d: "M5.148 103.892c5.253-3.516 11.978-2.514 16.033 2.193q.545-.662 1.154-1.263c5.253-5.186 14.114-5.144 21.634-.03l.23.164c1.138.845 2.125 2.115 2.979 3.627.913 1.618 1.691 3.544 2.343 5.6 1.158 3.654 1.954 7.754 2.5 11.213a71 71 0 0 1 1.284-4.269c2.82-8.498 5.504-17.539 11.327-24.703l.001-.002a1.224 1.224 0 0 1 1.726-.172l.093.085c.44.442.48 1.153.082 1.644-5.57 6.853-8.115 15.529-10.901 23.928-.87 2.62-1.609 5.208-2.065 7.909l-.001.002c-.14.816-.282 1.606-.378 2.406l.013.07.028.117.035.152v.004c.047.256.085.545.062.79v.004a1.44 1.44 0 0 1-.56 1.028l-.004.003a1.4 1.4 0 0 1-.882.276h-.005a1.19 1.19 0 0 1-1.02-.586l.001-.001a1 1 0 0 1-.088-.192 3 3 0 0 1-.068-.229 6 6 0 0 1-.134-.709v-.002c-.3-2.268-1.066-9.922-2.952-16.58-.605-2.137-1.31-4.157-2.148-5.833-.789-1.579-1.676-2.812-2.672-3.564l-.2-.144c-6.627-4.507-14.176-4.559-18.541-.252a13.6 13.6 0 0 0-1.461 1.706c.166.478.315 1.071.404 1.681.107.724.138 1.513.002 2.189-.143.708-.472 1.333-1.014 1.723v-.001c-.572.411-1.336.558-2.284.252-.859-.278-1.26-1.011-1.317-1.817-.055-.73.194-1.579.336-1.964.275-.748.614-1.468 1.006-2.154-3.2-4.191-8.838-5.181-13.215-2.251H6.51a1.227 1.227 0 0 1-1.702-.342l-.003-.002a1.234 1.234 0 0 1 .241-1.629z"
    })), _defs || (_defs = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("defs", null, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "CongratulationIcon_svg__a",
        x1: 106.423,
        x2: 107.945,
        y1: 1.602,
        y2: 262.644,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#F2F2F2"
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#EFEFEF"
    })))));
};
_c = SvgCongratulationIcon;
const __TURBOPACK__default__export__ = SvgCongratulationIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgCongratulationIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/individual/EmailIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgEmailIcon = function SvgEmailIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#767676",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M2.864 6.667 9.44 11.05a1.67 1.67 0 0 0 1.85 0l6.575-4.383M4.531 15.834h11.667a1.667 1.667 0 0 0 1.666-1.667V5.834a1.667 1.667 0 0 0-1.666-1.667H4.53a1.667 1.667 0 0 0-1.667 1.667v8.333a1.667 1.667 0 0 0 1.667 1.667"
    })));
};
_c = SvgEmailIcon;
const __TURBOPACK__default__export__ = SvgEmailIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgEmailIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/individual/GroupIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgGroupIcon = function SvgGroupIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 21 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#505050",
        d: "M5.572 6.458h.625c0 1.036.84 1.875 1.875 1.875v1.25a3.125 3.125 0 0 1-3.125-3.125zm2.5 2.5v-.625c1.036 0 1.875-.84 1.875-1.875h1.25c0 1.726-1.399 3.125-3.125 3.125zm2.5-2.5h-.625c0-1.036-.84-1.875-1.875-1.875v-1.25c1.726 0 3.125 1.4 3.125 3.125zm-2.5-2.5v.625c-1.035 0-1.875.84-1.875 1.875h-1.25c0-1.726 1.4-3.125 3.125-3.125zm2.5 7.5v.625h-5v-1.25h5zm-5 5v-.625h5v1.25h-5zm5 0v-.625c1.036 0 1.875-.84 1.875-1.875h1.25c0 1.726-1.399 3.125-3.125 3.125zm-7.5-2.5h.625c0 1.035.84 1.875 1.875 1.875v1.25a3.125 3.125 0 0 1-3.125-3.125zm2.5-2.5v.625c-1.035 0-1.875.84-1.875 1.875h-1.25c0-1.726 1.4-3.125 3.125-3.125zm5 0v-.625c1.726 0 3.125 1.4 3.125 3.125h-1.25c0-1.036-.84-1.875-1.875-1.875zM11.613 8.657a.73.73 0 0 1 .626-.324 1.875 1.875 0 0 0 0-3.75.73.73 0 0 1-.644-.352c-.219-.345-.108-.834.298-.88q.171-.018.346-.018a3.125 3.125 0 1 1-.346 6.231c-.406-.045-.517-.534-.298-.88zM14.149 15.264a.53.53 0 0 1 .446-.264h.144a1.875 1.875 0 0 0 0-3.75h-.144a.53.53 0 0 1-.446-.264c-.23-.386.02-.986.469-.986h.121a3.125 3.125 0 0 1 0 6.25h-.121c-.45 0-.7-.601-.469-.986"
    })));
};
_c = SvgGroupIcon;
const __TURBOPACK__default__export__ = SvgGroupIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgGroupIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/individual/SearchIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgSearchIcon = function SvgSearchIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 19 18"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#999",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.25,
        d: "m16.114 15.75-4.5-4.5m1.5-3.75a5.249 5.249 0 1 1-10.497 0 5.249 5.249 0 0 1 10.497 0"
    })));
};
_c = SvgSearchIcon;
const __TURBOPACK__default__export__ = SvgSearchIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgSearchIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/individual/TrashOutlineIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgTrashOutlineIcon = function SvgTrashOutlineIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: 18,
        height: 18,
        fill: "none"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#C83028",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "m14.25 5.25-.65 9.107a1.5 1.5 0 0 1-1.496 1.393H5.897A1.5 1.5 0 0 1 4.4 14.357L3.75 5.25m3.75 3v4.5m3-4.5v4.5m.75-7.5V3a.75.75 0 0 0-.75-.75h-3a.75.75 0 0 0-.75.75v2.25M3 5.25h12"
    })));
};
_c = SvgTrashOutlineIcon;
const __TURBOPACK__default__export__ = SvgTrashOutlineIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgTrashOutlineIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/individual/UnderArrowIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgUnderArrowIcon = function SvgUnderArrowIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 21 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#505050",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "m13.864 8.5-3.5 3-3.5-3"
    })));
};
_c = SvgUnderArrowIcon;
const __TURBOPACK__default__export__ = SvgUnderArrowIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgUnderArrowIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/individual/UploadIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgUploadIcon = function SvgUploadIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 25 24"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#505050",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M4.364 16.004V17a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-1m-8-.5v-11m0 0 3.5 3.5m-3.5-3.5L8.864 8"
    })));
};
_c = SvgUploadIcon;
const __TURBOPACK__default__export__ = SvgUploadIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgUploadIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/individual/WarningIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgWarningIcon = function SvgWarningIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 37 36"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#303030",
        d: "M18.364 2.25a15.75 15.75 0 1 1 0 31.5 15.75 15.75 0 0 1 0-31.5m0 29.25a13.5 13.5 0 1 0 0-27 13.5 13.5 0 0 0 0 27m1.688-6.187a1.687 1.687 0 1 1-3.374 0 1.687 1.687 0 0 1 3.374 0M18.364 9a1.125 1.125 0 0 1 1.125 1.125V20.25a1.125 1.125 0 0 1-2.25 0V10.125A1.125 1.125 0 0 1 18.364 9"
    })));
};
_c = SvgWarningIcon;
const __TURBOPACK__default__export__ = SvgWarningIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgWarningIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/IndividualIcons/IndividualIcons.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "IndividualIconsState": (()=>IndividualIconsState)
});
var IndividualIconsState = /*#__PURE__*/ function(IndividualIconsState) {
    IndividualIconsState["CONGRATULATE_SIGN_UP"] = "CONGRATULATE_SIGN_UP";
    IndividualIconsState["WARNING"] = "WARNING";
    IndividualIconsState["UNDER_ARROW"] = "UNDER_ARROW";
    IndividualIconsState["SEARCH"] = "SEARCH";
    IndividualIconsState["SEARCH_SIZE_20"] = "SEARCH_SIZE_20";
    IndividualIconsState["CALENDAR_SIZE_18"] = "CALENDAR_SIZE_18";
    IndividualIconsState["CALENDAR_SIZE_16"] = "CALENDAR_SIZE_16";
    IndividualIconsState["UPLOAD"] = "UPLOAD";
    IndividualIconsState["GROUP"] = "GROUP";
    IndividualIconsState["EMAIL"] = "EMAIL";
    IndividualIconsState["TRASH_OUTLINE"] = "TRASH_OUTLINE";
    return IndividualIconsState;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$CalenderIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/individual/CalenderIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$CongratulationIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/individual/CongratulationIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$EmailIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/individual/EmailIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$GroupIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/individual/GroupIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$SearchIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/individual/SearchIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$TrashOutlineIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/individual/TrashOutlineIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$UnderArrowIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/individual/UnderArrowIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$UploadIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/individual/UploadIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$WarningIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/individual/WarningIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/IndividualIcons/IndividualIcons.types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const IndividualIcons = ({ state, className })=>{
    switch(state){
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].CONGRATULATE_SIGN_UP:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$CongratulationIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-174.47pxr w-202.36pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 20,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].WARNING:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$WarningIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-36pxr w-36pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 22,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].UNDER_ARROW:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$UnderArrowIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-20pxr w-20pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 24,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].SEARCH:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$SearchIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-18pxr w-18pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 26,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].SEARCH_SIZE_20:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$SearchIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-20pxr w-20pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 28,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].CALENDAR_SIZE_16:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$CalenderIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-16pxr w-16pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 30,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].CALENDAR_SIZE_18:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$CalenderIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-18pxr w-18pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 32,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].UPLOAD:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$UploadIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-24pxr w-24pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 34,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].GROUP:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$GroupIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-20pxr w-20pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 36,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].EMAIL:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$EmailIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-20pxr w-20pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 38,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].TRASH_OUTLINE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$individual$2f$TrashOutlineIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-18pxr w-18pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx",
                lineNumber: 40,
                columnNumber: 14
            }, this);
        default:
            return null;
    }
};
_c = IndividualIcons;
const __TURBOPACK__default__export__ = IndividualIcons;
var _c;
__turbopack_context__.k.register(_c, "IndividualIcons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/inputs/InputSearchBox/InputSearchBox.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/*
  input으로써 검색 기능을 하지 않고 div 태그로 감싸서 링크로 이동하는 형태로 수정
  검색 페이지로 이동하는 링크를 클릭하면 검색 모달이 열리도록 구현
*/ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/IndividualIcons/IndividualIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/IndividualIcons/IndividualIcons.types.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
const InputSearchBox = ({ searchHref, placeholder = '검색하기' })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: searchHref,
        scroll: false,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "border-stroke-200 hover:border-stroke-100 rounded-10pxr h-34pxr w-264pxr relative flex shrink-0 cursor-pointer items-center border bg-gray-600",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$IndividualIcons$2f$IndividualIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IndividualIconsState"].SEARCH,
                    className: "left-13pxr top-8pxr pointer-events-none absolute"
                }, void 0, false, {
                    fileName: "[project]/src/common/components/inputs/InputSearchBox/InputSearchBox.client.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-b3-rg left-36pxr pointer-events-none absolute text-gray-400",
                    children: placeholder
                }, void 0, false, {
                    fileName: "[project]/src/common/components/inputs/InputSearchBox/InputSearchBox.client.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/common/components/inputs/InputSearchBox/InputSearchBox.client.tsx",
            lineNumber: 17,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/common/components/inputs/InputSearchBox/InputSearchBox.client.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
};
_c = InputSearchBox;
const __TURBOPACK__default__export__ = InputSearchBox;
var _c;
__turbopack_context__.k.register(_c, "InputSearchBox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/types/gnbs.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/gnbs.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$CategoryOption$2f$CategoryOption$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/CategoryOption/CategoryOption.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$inputs$2f$InputSearchBox$2f$InputSearchBox$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/inputs/InputSearchBox/InputSearchBox.client.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const SEARCH_PATH_MAP = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].AI_MEETING_MANAGER]: 'ai-meeting-manager/search',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].SNS_EVENT_ASSISTANT]: 'sns-event-assistant/search',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].TEAM_MOOD_TRACKER]: 'team-mood-tracker/search',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].MAIN]: 'search',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CALENDAR]: 'calendar/search',
    default: 'search'
};
const GnbTop = ({ section, title, current, isSnsEventAssistantWithoutWorkspace, isLoading = false })=>{
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])() ?? '';
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const searchPath = params.workspaceId ? `/workspace/${params.workspaceId}/${SEARCH_PATH_MAP[section] ?? SEARCH_PATH_MAP.default}` : '#';
    const hasWorkspace = !!params.workspaceId;
    const config = section === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CUSTOM ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sectionConfigs"][section](title ?? '') : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sectionConfigs"][section];
    const isSnsEventAssistant = section === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].SNS_EVENT_ASSISTANT;
    const isCustomSection = section === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].CUSTOM;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex w-full flex-col items-start",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-b-stroke-200 py-13pxr flex h-[var(--gnb-top-height)] items-center justify-between self-stretch border-b border-solid bg-white px-6",
                children: [
                    isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-150pxr h-30pxr animate-bg-pulse rounded-4pxr"
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                        lineNumber: 50,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-t3-sb text-black",
                        children: config.title
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                        lineNumber: 52,
                        columnNumber: 11
                    }, this),
                    !isCustomSection && hasWorkspace && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$inputs$2f$InputSearchBox$2f$InputSearchBox$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        searchHref: searchPath
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                        lineNumber: 54,
                        columnNumber: 46
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            !isCustomSection && // 하단 탭 or 단순 옵션
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-b-stroke-200 py-13pxr flex h-14 items-center gap-2.5 self-stretch border-b border-solid bg-white px-6",
                children: isSnsEventAssistant ? Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SnsGnbTabLabels"]).map((tab)=>{
                    const params = new URLSearchParams();
                    params.set('snsGnbTab', tab);
                    const isActive = isSnsEventAssistantWithoutWorkspace ? tab === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SnsGnbTabType"].ALL_EVENTS // workspace 없으면 ALL_EVENTS만 active
                     : current === tab; // 그 외엔 current 비교
                    // workspace 없는 경우 ALL_EVENTS만 활성화
                    const isDisabled = isSnsEventAssistantWithoutWorkspace && tab !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SnsGnbTabType"].ALL_EVENTS;
                    const route = `${pathname}?${params.toString()}`;
                    return isSnsEventAssistantWithoutWorkspace ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$CategoryOption$2f$CategoryOption$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SnsGnbTabLabels"][tab],
                            active: isActive,
                            disabled: isDisabled
                        }, void 0, false, {
                            fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                            lineNumber: 76,
                            columnNumber: 21
                        }, this)
                    }, tab, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                        lineNumber: 75,
                        columnNumber: 19
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: route,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$CategoryOption$2f$CategoryOption$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SnsGnbTabLabels"][tab],
                            active: isActive
                        }, void 0, false, {
                            fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                            lineNumber: 84,
                            columnNumber: 21
                        }, this)
                    }, tab, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                        lineNumber: 83,
                        columnNumber: 19
                    }, this);
                }) : config.options.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$CategoryOption$2f$CategoryOption$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        label: option.label,
                        active: true
                    }, option.key, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                        lineNumber: 89,
                        columnNumber: 17
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
                lineNumber: 58,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/gnbs/GnbTop/GnbTop.client.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
};
_s(GnbTop, "aVY+fbtRm2bkHJ/L3dUgXz4ofWI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = GnbTop;
const __TURBOPACK__default__export__ = GnbTop;
var _c;
__turbopack_context__.k.register(_c, "GnbTop");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/haru-logo/LogoMixed.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2, _path3, _path4, _path5, _path6, _path7, _path8, _path9, _defs;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLogoMixed = function SvgLogoMixed(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 99 24"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoMixed_svg__a)",
        d: "M10.111 20.673c.004.62.248 1.215.679 1.651s1.014.68 1.62.676a2.26 2.26 0 0 0 1.612-.695 2.37 2.37 0 0 0 .66-1.658c-.007-1.305-2.311-4.667-2.311-4.667s-2.267 3.389-2.26 4.693"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoMixed_svg__b)",
        d: "M21.053 14.303a2.26 2.26 0 0 0 1.613-.695 2.37 2.37 0 0 0 .66-1.659 2.37 2.37 0 0 0-.679-1.65 2.26 2.26 0 0 0-1.62-.677c-1.274.008-4.558 2.367-4.558 2.367s3.31 2.32 4.584 2.313"
    })), _path3 || (_path3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoMixed_svg__c)",
        d: "M19.113 8.059c.317-.33.495-.774.492-1.237a1.77 1.77 0 0 0-.506-1.231 1.68 1.68 0 0 0-1.208-.504 1.69 1.69 0 0 0-1.202.518c-.669.692-1.185 3.709-1.185 3.709s2.94-.563 3.609-1.255"
    })), _path4 || (_path4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoMixed_svg__d)",
        d: "M16.495 18.382c.322.326.756.507 1.208.504.452-.002.885-.189 1.203-.518s.495-.774.492-1.237a1.77 1.77 0 0 0-.506-1.23c-.676-.685-3.622-1.213-3.622-1.213s.55 3.01 1.225 3.694"
    })), _path5 || (_path5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoMixed_svg__e)",
        d: "M14.57 3.327a2.37 2.37 0 0 0-.678-1.65A2.26 2.26 0 0 0 12.272 1a2.26 2.26 0 0 0-1.613.695A2.37 2.37 0 0 0 10 3.354c.007 1.304 2.312 4.667 2.312 4.667s2.267-3.39 2.26-4.694"
    })), _path6 || (_path6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoMixed_svg__f)",
        d: "M3.599 9.738a2.26 2.26 0 0 0-1.613.695 2.37 2.37 0 0 0-.66 1.659c.004.62.248 1.214.679 1.65.431.437 1.014.68 1.62.677 1.274-.008 4.558-2.367 4.558-2.367S4.873 9.73 3.6 9.738"
    })), _path7 || (_path7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoMixed_svg__g)",
        d: "M5.836 15.98c-.318.329-.495.774-.492 1.236.002.463.184.906.506 1.232.321.325.756.506 1.208.504a1.69 1.69 0 0 0 1.202-.519c.668-.691 1.185-3.708 1.185-3.708s-2.94.563-3.609 1.255"
    })), _path8 || (_path8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoMixed_svg__h)",
        d: "M8.185 5.655a1.68 1.68 0 0 0-1.208-.504 1.69 1.69 0 0 0-1.202.519c-.318.329-.495.774-.493 1.236.003.463.185.906.506 1.231.676.684 3.623 1.213 3.623 1.213s-.55-3.01-1.226-3.695"
    })), _path9 || (_path9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#E65787",
        d: "m92.836 15.4.03-8.14c0-.199.168-.36.373-.358l3.424.011c.205.001.37.163.37.362l-.052 14.073c-.001.198-.168.359-.374.358l-3.254-.011a.366.366 0 0 1-.37-.361l.008-2.213a.1.1 0 0 0-.1-.098.1.1 0 0 0-.095.061c-.724 1.68-2.35 2.791-4.63 2.783-3.07-.01-5.145-2.116-5.133-5.575l.034-9.066c.001-.199.168-.36.374-.359l3.423.012c.205 0 .371.163.37.361l-.03 8.358c-.007 1.743 1.03 2.864 2.664 2.87 1.52.005 2.96-1.052 2.968-3.068M66.386 21.814a.36.36 0 0 1-.353-.365l.068-19.22c0-.2.16-.363.355-.362l7.254.027c4.42.017 6.929 2.588 6.915 6.528-.01 2.578-1.105 4.487-3.093 5.496a.387.387 0 0 0-.17.52l3.628 6.892c.128.243-.044.538-.312.537l-3.64-.013a.35.35 0 0 1-.31-.193l-3.473-6.71a.35.35 0 0 0-.311-.193l-2.515-.01a.36.36 0 0 0-.355.363l-.023 6.353c0 .2-.16.363-.355.362zm3.702-10.792c0 .2.157.364.353.365l2.485.01c2.385.008 3.54-1.007 3.547-2.99.007-2.012-1.141-3.118-3.525-3.127l-2.486-.01a.36.36 0 0 0-.355.363zM49.033 17.508c.013-3.242 2.847-4.305 5.851-4.455.967-.055 2.655-.126 3.536-.16.204-.009.364-.164.365-.354l.003-.84c-.024-1.206-.916-1.933-2.505-1.938-1.305-.004-2.188.497-2.519 1.325a.43.43 0 0 1-.394.273l-3.344-.011c-.225 0-.402-.182-.361-.387.461-2.331 2.802-4.107 6.745-4.094 3.408.012 6.637 1.443 6.623 4.953l-.037 9.455c0 .195-.172.353-.382.352l-3.28-.01c-.211-.001-.381-.16-.38-.356l.005-1.589c0-.037-.032-.067-.072-.067a.07.07 0 0 0-.064.035c-.79 1.318-2.26 2.235-4.58 2.227-3.003-.01-5.22-1.465-5.21-4.359m4.102-.093c-.005 1.125.975 1.718 2.332 1.723 1.935.006 3.326-1.195 3.303-2.722l.003-.703c0-.201-.18-.362-.397-.353-.812.036-2.19.106-2.808.16-1.474.13-2.43.77-2.433 1.895M30.396 21.809a.364.364 0 0 1-.363-.366l.07-19.213c0-.201.164-.364.365-.363l3.402.013c.2 0 .363.164.362.365l-.027 7.535c-.001.201.161.364.362.365l7.917.029a.364.364 0 0 0 .365-.363l.027-7.535c0-.201.164-.363.365-.363l3.43.013c.2 0 .363.164.362.365l-.07 19.214a.364.364 0 0 1-.364.362l-3.43-.012a.364.364 0 0 1-.362-.365l.027-7.536c0-.2-.161-.364-.363-.365l-7.916-.029c-.201 0-.364.162-.365.363l-.027 7.535c-.001.201-.165.364-.365.363z"
    })), _defs || (_defs = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("defs", null, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoMixed_svg__a",
        x1: 12.371,
        x2: 12.412,
        y1: 15.979,
        y2: 23,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoMixed_svg__b",
        x1: 16.469,
        x2: 23.326,
        y1: 11.989,
        y2: 11.951,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoMixed_svg__c",
        x1: 15.504,
        x2: 19.185,
        y1: 9.314,
        y2: 5.678,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoMixed_svg__d",
        x1: 15.27,
        x2: 18.99,
        y1: 14.688,
        y2: 18.28,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoMixed_svg__e",
        x1: 12.311,
        x2: 12.27,
        y1: 8.021,
        y2: 1,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoMixed_svg__f",
        x1: 8.183,
        x2: 1.326,
        y1: 12.052,
        y2: 12.09,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoMixed_svg__g",
        x1: 9.445,
        x2: 5.764,
        y1: 14.725,
        y2: 18.361,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoMixed_svg__h",
        x1: 9.411,
        x2: 5.69,
        y1: 9.35,
        y2: 5.757,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })))));
};
_c = SvgLogoMixed;
const __TURBOPACK__default__export__ = SvgLogoMixed;
var _c;
__turbopack_context__.k.register(_c, "SvgLogoMixed");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/haru-logo/LogoSymbol.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2, _path3, _path4, _path5, _path6, _path7, _path8, _defs;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLogoSymbol = function SvgLogoSymbol(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 200 200"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoSymbol_svg__a)",
        d: "M79.866 178.847c.032 5.643 2.25 11.041 6.17 15.008s9.217 6.178 14.728 6.146 10.783-2.304 14.658-6.317c3.875-4.012 6.034-9.436 6.003-15.079-.066-11.86-21.016-42.428-21.016-42.428s-20.609 30.81-20.543 42.67"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoSymbol_svg__b)",
        d: "M179.339 120.931c5.511-.032 10.784-2.304 14.658-6.316 3.875-4.013 6.034-9.437 6.003-15.08-.031-5.642-2.25-11.04-6.17-15.007s-9.216-6.178-14.727-6.146c-11.585.067-41.441 21.517-41.441 21.517s30.092 21.1 41.677 21.032"
    })), _path3 || (_path3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoSymbol_svg__c)",
        d: "M161.696 64.171c2.89-2.992 4.5-7.036 4.476-11.244-.023-4.207-1.678-8.233-4.6-11.19-2.923-2.959-6.873-4.608-10.982-4.583-4.11.024-8.042 1.718-10.931 4.71-6.073 6.29-10.769 33.717-10.769 33.717s26.733-5.12 32.806-11.41"
    })), _path4 || (_path4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoSymbol_svg__d)",
        d: "M137.903 158.021c2.922 2.957 6.873 4.606 10.982 4.582 4.11-.024 8.041-1.718 10.931-4.71s4.499-7.037 4.476-11.244c-.024-4.208-1.679-8.233-4.601-11.191-6.143-6.219-32.931-11.026-32.931-11.026s5 27.37 11.143 33.589"
    })), _path5 || (_path5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoSymbol_svg__e)",
        d: "M120.405 21.154c-.031-5.642-2.251-11.04-6.17-15.008S105.018-.032 99.507 0 88.723 2.305 84.85 6.317c-3.875 4.013-6.034 9.437-6.003 15.08.066 11.86 21.016 42.427 21.016 42.427s20.609-30.81 20.543-42.67"
    })), _path6 || (_path6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoSymbol_svg__f)",
        d: "M20.662 79.439c-5.511.032-10.784 2.304-14.66 6.317C2.129 89.768-.03 95.191 0 100.834c.032 5.643 2.251 11.041 6.17 15.009s9.217 6.177 14.728 6.145c11.584-.067 41.44-21.516 41.44-21.516s-30.092-21.1-41.676-21.033"
    })), _path7 || (_path7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoSymbol_svg__g)",
        d: "M41 136.178c-2.89 2.992-4.5 7.036-4.476 11.244.023 4.207 1.678 8.233 4.6 11.191 2.923 2.958 6.873 4.606 10.982 4.582 4.11-.024 8.042-1.718 10.931-4.71 6.074-6.289 10.77-33.716 10.77-33.716S47.073 129.888 41 136.178"
    })), _path8 || (_path8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "url(#LogoSymbol_svg__h)",
        d: "M62.354 42.322c-2.922-2.958-6.873-4.607-10.982-4.583-4.11.024-8.042 1.719-10.931 4.71-2.89 2.993-4.5 7.037-4.476 11.245.023 4.207 1.678 8.233 4.6 11.19 6.144 6.219 32.932 11.027 32.932 11.027s-5-27.37-11.144-33.589"
    })), _defs || (_defs = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("defs", null, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoSymbol_svg__a",
        x1: 100.409,
        x2: 100.781,
        y1: 136.177,
        y2: 200.001,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoSymbol_svg__b",
        x1: 137.662,
        x2: 200,
        y1: 99.899,
        y2: 99.553,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoSymbol_svg__c",
        x1: 128.89,
        x2: 162.351,
        y1: 75.581,
        y2: 42.525,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoSymbol_svg__d",
        x1: 126.76,
        x2: 160.585,
        y1: 124.432,
        y2: 157.096,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoSymbol_svg__e",
        x1: 99.862,
        x2: 99.49,
        y1: 63.825,
        y2: 0,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoSymbol_svg__f",
        x1: 62.338,
        x2: 0,
        y1: 100.472,
        y2: 100.818,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoSymbol_svg__g",
        x1: 73.807,
        x2: 40.346,
        y1: 124.769,
        y2: 157.824,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("linearGradient", {
        id: "LogoSymbol_svg__h",
        x1: 73.497,
        x2: 39.671,
        y1: 75.911,
        y2: 43.247,
        gradientUnits: "userSpaceOnUse"
    }, /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        stopColor: "#E65787",
        stopOpacity: 0.7
    }), /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("stop", {
        offset: 1,
        stopColor: "#E65787"
    })))));
};
_c = SvgLogoSymbol;
const __TURBOPACK__default__export__ = SvgLogoSymbol;
var _c;
__turbopack_context__.k.register(_c, "SvgLogoSymbol");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/haru-logo/LogoText.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLogoText = function SvgLogoText(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 67 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#E65787",
        d: "m62.802 13.533.03-8.14c.002-.199.169-.36.374-.359l3.424.012c.205.001.37.163.37.361l-.052 14.073c-.001.199-.168.36-.374.359l-3.254-.012a.366.366 0 0 1-.37-.36l.008-2.213a.1.1 0 0 0-.1-.098.1.1 0 0 0-.095.061c-.724 1.68-2.35 2.79-4.63 2.783-3.07-.01-5.146-2.116-5.133-5.575l.034-9.066c.001-.2.168-.36.373-.359l3.424.012c.205 0 .371.162.37.361l-.03 8.358c-.007 1.743 1.03 2.864 2.663 2.87 1.521.005 2.961-1.052 2.968-3.068M36.353 19.947a.36.36 0 0 1-.353-.365l.068-19.22c0-.2.16-.363.355-.362l7.254.027c4.42.016 6.928 2.588 6.915 6.528-.01 2.578-1.105 4.487-3.094 5.496a.387.387 0 0 0-.17.52l3.629 6.892c.128.243-.044.538-.313.537l-3.638-.014a.35.35 0 0 1-.311-.192l-3.473-6.71a.35.35 0 0 0-.311-.193l-2.515-.01a.36.36 0 0 0-.356.363l-.022 6.353c0 .2-.16.363-.355.362zm3.702-10.792a.36.36 0 0 0 .353.365l2.485.01c2.384.008 3.54-1.007 3.547-2.99.007-2.012-1.142-3.118-3.525-3.127l-2.486-.01a.36.36 0 0 0-.355.363zM19 15.641c.013-3.242 2.847-4.305 5.851-4.456.967-.054 2.655-.125 3.536-.16.204-.008.364-.164.365-.353l.003-.84c-.024-1.206-.916-1.933-2.505-1.938-1.305-.005-2.188.497-2.519 1.325a.43.43 0 0 1-.394.273l-3.344-.011c-.226-.001-.402-.182-.361-.387.46-2.332 2.801-4.107 6.745-4.094 3.408.012 6.637 1.443 6.623 4.953l-.037 9.454c0 .196-.172.354-.383.353l-3.28-.01c-.21-.002-.38-.16-.38-.356l.006-1.589c0-.037-.032-.067-.072-.067a.07.07 0 0 0-.064.035C28 19.09 26.53 20.008 24.21 20c-3.003-.01-5.221-1.465-5.21-4.359m4.102-.093c-.005 1.125.974 1.718 2.332 1.723 1.935.006 3.326-1.195 3.303-2.723l.002-.702c.001-.201-.179-.363-.396-.353-.813.036-2.19.106-2.808.16-1.474.13-2.43.77-2.433 1.895M.362 19.941A.364.364 0 0 1 0 19.576L.07.362C.07.162.233 0 .433 0l3.403.012c.2.001.363.165.362.365l-.027 7.536c-.001.2.161.364.362.365l7.917.029a.364.364 0 0 0 .365-.363L12.843.41c0-.201.164-.363.365-.363l3.43.013c.2 0 .363.164.362.365l-.07 19.214c0 .2-.164.363-.364.362l-3.43-.012a.364.364 0 0 1-.362-.366l.027-7.535c0-.2-.162-.364-.363-.365l-7.917-.029c-.2 0-.364.162-.364.363l-.028 7.535c0 .201-.164.363-.365.363z"
    })));
};
_c = SvgLogoText;
const __TURBOPACK__default__export__ = SvgLogoText;
var _c;
__turbopack_context__.k.register(_c, "SvgLogoText");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/logos/HaruLogoIcons/HaruLogoIcons.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "HaruLogoIconsState": (()=>HaruLogoIconsState)
});
var HaruLogoIconsState = /*#__PURE__*/ function(HaruLogoIconsState) {
    HaruLogoIconsState["MIXED"] = "MIXED";
    HaruLogoIconsState["SYMBOL"] = "SYMBOL";
    HaruLogoIconsState["TEXT"] = "TEXT";
    return HaruLogoIconsState;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/logos/HaruLogoIcons/HaruLogoIcons.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$haru$2d$logo$2f$LogoMixed$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/haru-logo/LogoMixed.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$haru$2d$logo$2f$LogoSymbol$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/haru-logo/LogoSymbol.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$haru$2d$logo$2f$LogoText$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/haru-logo/LogoText.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$logos$2f$HaruLogoIcons$2f$HaruLogoIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/logos/HaruLogoIcons/HaruLogoIcons.types.ts [app-client] (ecmascript)");
;
;
;
;
;
const HaruLogoIcons = ({ state, className })=>{
    switch(state){
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$logos$2f$HaruLogoIcons$2f$HaruLogoIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HaruLogoIconsState"].MIXED:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$haru$2d$logo$2f$LogoMixed$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: className
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/logos/HaruLogoIcons/HaruLogoIcons.tsx",
                lineNumber: 12,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$logos$2f$HaruLogoIcons$2f$HaruLogoIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HaruLogoIconsState"].SYMBOL:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$haru$2d$logo$2f$LogoSymbol$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: className
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/logos/HaruLogoIcons/HaruLogoIcons.tsx",
                lineNumber: 14,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$logos$2f$HaruLogoIcons$2f$HaruLogoIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HaruLogoIconsState"].TEXT:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$haru$2d$logo$2f$LogoText$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: className
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/logos/HaruLogoIcons/HaruLogoIcons.tsx",
                lineNumber: 16,
                columnNumber: 14
            }, this);
        default:
            return null;
    }
};
_c = HaruLogoIcons;
const __TURBOPACK__default__export__ = HaruLogoIcons;
var _c;
__turbopack_context__.k.register(_c, "HaruLogoIcons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/layouts/Footer/Footer.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$logos$2f$HaruLogoIcons$2f$HaruLogoIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/logos/HaruLogoIcons/HaruLogoIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$logos$2f$HaruLogoIcons$2f$HaruLogoIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/logos/HaruLogoIcons/HaruLogoIcons.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const Footer = ()=>{
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const isLandingPage = pathname.includes(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].LANDING.BASE);
    const { workspaceId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const termsOfServiceModalHref = isLandingPage ? `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].LANDING.MODAL.TERMS_OF_SERVICE}` : `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].MAIN.MODAL.TERMS_OF_SERVICE(workspaceId)}`;
    const privacyPolicyModalHref = isLandingPage ? `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].LANDING.MODAL.PRIVACY_POLICY}` : `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].MAIN.MODAL.PRIVACY_POLICY(workspaceId)}`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-299pxr gap-120pxr px-114pxr w-full items-start bg-gray-100 py-16",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-b3-rg flex flex-col items-start gap-6 text-white",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$logos$2f$HaruLogoIcons$2f$HaruLogoIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$logos$2f$HaruLogoIcons$2f$HaruLogoIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HaruLogoIconsState"].MIXED,
                    className: "h-28px w-115pxr"
                }, void 0, false, {
                    fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-start gap-1.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2.5 self-stretch",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "대표 : 황지원"
                                }, void 0, false, {
                                    fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                                    lineNumber: 31,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "h-[15pxr] w-0.5 bg-gray-300"
                                }, void 0, false, {
                                    fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                                    lineNumber: 32,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "메일 : thejeewon@naver.com"
                                }, void 0, false, {
                                    fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                                    lineNumber: 33,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2.5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    className: "cursor-pointer hover:underline",
                                    href: termsOfServiceModalHref,
                                    children: "서비스이용약관"
                                }, void 0, false, {
                                    fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                                    lineNumber: 37,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    className: "cursor-pointer hover:underline",
                                    href: privacyPolicyModalHref,
                                    children: "개인정보처리방침"
                                }, void 0, false, {
                                    fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                                    lineNumber: 40,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                            lineNumber: 36,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-start gap-0.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "Copyright © HaRu"
                        }, void 0, false, {
                            fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                            lineNumber: 47,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "All rights reserved."
                        }, void 0, false, {
                            fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/common/components/layouts/Footer/Footer.client.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
};
_s(Footer, "FBKditTR5QExM4AmnILIKOlLoKA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = Footer;
const __TURBOPACK__default__export__ = Footer;
var _c;
__turbopack_context__.k.register(_c, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/gnb/left/LeftGnbAiManagerIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLeftGnbAiManagerIcon = function SvgLeftGnbAiManagerIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M13.213 13.654H6.968M13.213 10.033H6.968M9.35 6.42H6.969"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "m13.379 2-6.651.003c-2.387.015-3.866 1.586-3.866 3.982v7.955c0 2.408 1.49 3.985 3.898 3.985l6.651-.003c2.387-.015 3.867-1.586 3.867-3.982V5.985c0-2.408-1.49-3.985-3.899-3.985",
        clipRule: "evenodd"
    })));
};
_c = SvgLeftGnbAiManagerIcon;
const __TURBOPACK__default__export__ = SvgLeftGnbAiManagerIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgLeftGnbAiManagerIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/gnb/left/LeftGnbHomeIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLeftGnbHomeIcon = function SvgLeftGnbHomeIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M7.666 17.212v-2.518c0-.64.522-1.16 1.169-1.165h2.37c.65 0 1.176.522 1.176 1.165v2.526c0 .544.438.988.987 1h1.58c1.575 0 2.852-1.263 2.852-2.822V8.235a2 2 0 0 0-.79-1.564l-5.403-4.309a2.61 2.61 0 0 0-3.238 0L2.989 6.68c-.492.373-.783.95-.79 1.564v7.155c0 1.559 1.277 2.823 2.852 2.823h1.58c.563 0 1.019-.452 1.019-1.009"
    })));
};
_c = SvgLeftGnbHomeIcon;
const __TURBOPACK__default__export__ = SvgLeftGnbHomeIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgLeftGnbHomeIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/gnb/left/LeftGnbMyCalendarIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLeftGnbMyCalendarIcon = function SvgLeftGnbMyCalendarIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "currentColor",
        strokeWidth: 1.5,
        d: "M2.2 9.806c0-2.94 0-4.41.914-5.322.913-.913 2.383-.914 5.322-.914h3.118c2.94 0 4.41 0 5.322.914.913.913.914 2.383.914 5.322v1.56c0 2.939 0 4.409-.914 5.321-.913.913-2.383.914-5.322.914H8.436c-2.94 0-4.41 0-5.322-.914-.913-.913-.914-2.383-.914-5.322z"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeWidth: 1.5,
        d: "M6.098 3.57V2.4m7.794 1.17V2.4M2.59 7.467H17.4"
    })));
};
_c = SvgLeftGnbMyCalendarIcon;
const __TURBOPACK__default__export__ = SvgLeftGnbMyCalendarIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgLeftGnbMyCalendarIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/gnb/left/LeftGnbRecentFileIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLeftGnbRecentFileIcon = function SvgLeftGnbRecentFileIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.25,
        d: "M3.333 5h13.333M3.333 10h13.333M3.333 15h5.833"
    })));
};
_c = SvgLeftGnbRecentFileIcon;
const __TURBOPACK__default__export__ = SvgLeftGnbRecentFileIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgLeftGnbRecentFileIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/gnb/left/LeftGnbSnsAssistantIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLeftGnbSnsAssistantIcon = function SvgLeftGnbSnsAssistantIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "currentColor",
        d: "M8.515 2.563c.563-1.326 2.553-1.285 3.02.134l1.291 3.906q.009.024.03.04a.1.1 0 0 0 .051.017h4.176c1.566 0 2.211 1.97.95 2.873h-.002l-3.378 2.413a.1.1 0 0 0-.03.043.1.1 0 0 0 0 .051l1.29 3.907.038.136c.339 1.4-1.296 2.516-2.522 1.64l-3.379-2.415a.09.09 0 0 0-.077-.012l-.023.012-3.38 2.414c-1.265.905-2.967-.315-2.483-1.776l1.29-3.906a.1.1 0 0 0 0-.051.1.1 0 0 0-.012-.024l-.018-.018-3.379-2.413v-.001c-1.265-.905-.614-2.873.95-2.873h4.176a.1.1 0 0 0 .05-.016.1.1 0 0 0 .03-.04l1.29-3.907zM10 3.104a.1.1 0 0 0-.053.014l-.011.01-.017.034-1.29 3.906a1.6 1.6 0 0 1-.587.794 1.63 1.63 0 0 1-.95.303H2.918a.1.1 0 0 0-.037.004l-.014.007a.1.1 0 0 0-.03.046.1.1 0 0 0-.002.055q0 .008.006.014a.1.1 0 0 0 .027.025l3.378 2.413h.001c.276.198.48.476.586.795.092.279.104.577.035.86l-.035.121-1.29 3.906a.1.1 0 0 0-.007.037q0 .008.003.015c.004.01.014.027.035.042.02.015.04.02.05.02q.008 0 .016-.002a.1.1 0 0 0 .033-.018l3.378-2.414a1.63 1.63 0 0 1 1.898 0h.001l3.38 2.414a.1.1 0 0 0 .032.018l.015.002a.1.1 0 0 0 .052-.02q.03-.023.033-.041l.003-.016q.001-.008-.006-.036v-.001l-1.29-3.906a1.56 1.56 0 0 1 0-.981 1.6 1.6 0 0 1 .586-.794l3.378-2.414.027-.025.007-.014a.1.1 0 0 0-.003-.055.1.1 0 0 0-.03-.046l-.013-.007a.1.1 0 0 0-.038-.004h-4.177c-.34 0-.671-.107-.947-.304a1.6 1.6 0 0 1-.586-.792v-.001L10.08 3.162a.1.1 0 0 0-.017-.033l-.01-.011A.1.1 0 0 0 10 3.104"
    })));
};
_c = SvgLeftGnbSnsAssistantIcon;
const __TURBOPACK__default__export__ = SvgLeftGnbSnsAssistantIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgLeftGnbSnsAssistantIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/gnb/left/LeftGnbTeamMoodTrackerIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLeftGnbTeamMoodTrackerIcon = function SvgLeftGnbTeamMoodTrackerIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.4,
        d: "M14.334 5.667h1.733A1.733 1.733 0 0 1 17.8 7.4v5.2a1.733 1.733 0 0 1-1.733 1.734h-1.733V17.8l-3.467-3.466H7.4a1.73 1.73 0 0 1-1.225-.508m0 0 2.959-2.96H12.6a1.733 1.733 0 0 0 1.734-1.732v-5.2A1.733 1.733 0 0 0 12.6 2.2H3.934A1.733 1.733 0 0 0 2.2 3.934v5.2a1.733 1.733 0 0 0 1.734 1.733h1.733v3.467z"
    })));
};
_c = SvgLeftGnbTeamMoodTrackerIcon;
const __TURBOPACK__default__export__ = SvgLeftGnbTeamMoodTrackerIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgLeftGnbTeamMoodTrackerIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbAiManagerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/gnb/left/LeftGnbAiManagerIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbHomeIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/gnb/left/LeftGnbHomeIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbMyCalendarIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/gnb/left/LeftGnbMyCalendarIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbRecentFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/gnb/left/LeftGnbRecentFileIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbSnsAssistantIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/gnb/left/LeftGnbSnsAssistantIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbTeamMoodTrackerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/gnb/left/LeftGnbTeamMoodTrackerIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
const LeftGnbIcons = ({ state, className })=>{
    switch(state){
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].AI_MANAGER:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbAiManagerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-black', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 17,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].AI_MANAGER_DISABLED:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbAiManagerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-gray-200', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 20,
                columnNumber: 9
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].HOME:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbHomeIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-black', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 23,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].HOME_DISABLED:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbHomeIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-gray-200', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 25,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].MY_CALENDAR:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbMyCalendarIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-black', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 27,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].MY_CALENDAR_DISABLED:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbMyCalendarIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-gray-200', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 30,
                columnNumber: 9
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].SNS_ASSISTANT:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbSnsAssistantIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-black', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 34,
                columnNumber: 9
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].SNS_ASSISTANT_DISABLED:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbSnsAssistantIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-gray-200', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 38,
                columnNumber: 9
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].TEAM_MOOD_TRACKER:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbTeamMoodTrackerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-black', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 42,
                columnNumber: 9
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].TEAM_MOOD_TRACKER_DISABLED:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbTeamMoodTrackerIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-gray-200', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 46,
                columnNumber: 9
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].RECENT_FILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$gnb$2f$left$2f$LeftGnbRecentFileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] shrink-0 text-gray-200', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx",
                lineNumber: 52,
                columnNumber: 9
            }, this);
        default:
            return null;
    }
};
_c = LeftGnbIcons;
const __TURBOPACK__default__export__ = LeftGnbIcons;
var _c;
__turbopack_context__.k.register(_c, "LeftGnbIcons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/gnbs/GnbLeft/NavItem/NavItem.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/types/gnbs.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/gnbs.constants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const NavItem = ({ item, workspaceId })=>{
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const route = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSectionPaths"])(workspaceId)[item];
    const isCurrent = item === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$types$2f$gnbs$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSection"].MAIN ? pathname === route : pathname.startsWith(route);
    const isDisabled = !workspaceId;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: route,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-38pxr rounded-10pxr flex items-center gap-2 self-stretch p-3 transition-colors duration-150', {
            'text-t6-sb bg-gray-600 text-black': isCurrent,
            'hover:bg-gray-600': !isCurrent && !isDisabled,
            'pointer-events-none': isDisabled,
            'cursor-pointer': !isDisabled
        }),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbLeftNavItemIconState"][item]
            }, void 0, false, {
                fileName: "[project]/src/common/components/gnbs/GnbLeft/NavItem/NavItem.client.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-b3-rg text-gray-200",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$gnbs$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GnbSectionLabels"][item]
            }, void 0, false, {
                fileName: "[project]/src/common/components/gnbs/GnbLeft/NavItem/NavItem.client.tsx",
                lineNumber: 42,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/gnbs/GnbLeft/NavItem/NavItem.client.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
};
_s(NavItem, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = NavItem;
const __TURBOPACK__default__export__ = NavItem;
var _c;
__turbopack_context__.k.register(_c, "NavItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/workspace/get/apis/fetchRecentDocuments.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$api$2d$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/api-end-point.constants.ts [app-client] (ecmascript)");
;
;
const fetchRecentDocuments = async ({ workspaceId })=>{
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$api$2d$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_API_END_POINTS"].RECENT_DOCUMENTS(workspaceId), {
        method: 'GET',
        auth: true
    });
    return response;
};
const __TURBOPACK__default__export__ = fetchRecentDocuments;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/workspace/get/queries/useFetchRecentDocuments.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$query$2d$key$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/query-key.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/hooks/queries/useAfterQuery.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$apis$2f$fetchRecentDocuments$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/get/apis/fetchRecentDocuments.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
/**
 * 특정 워크 스페이스의 최근 조회 파일 가져오는 훅
 */ const useFetchRecentDocuments = (workspaceId)=>{
    _s();
    // Hydrate된 데이터가 있어 추가 네트워크 요청 없이 바로 캐시 데이터 사용
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAfterQuery"])({
        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$query$2d$key$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].workspaces.recentDocuments(workspaceId).queryKey,
        queryFn: {
            "useFetchRecentDocuments.useAfterQuery": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$apis$2f$fetchRecentDocuments$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    workspaceId
                })
        }["useFetchRecentDocuments.useAfterQuery"],
        enabled: !!workspaceId,
        retry: false,
        extra: {
            "useFetchRecentDocuments.useAfterQuery": (queryResult)=>queryResult.data?.result?.documents ?? []
        }["useFetchRecentDocuments.useAfterQuery"]
    });
};
_s(useFetchRecentDocuments, "/MY3m4/k0JOoh72XWghwZcmb4/I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAfterQuery"]
    ];
});
const __TURBOPACK__default__export__ = useFetchRecentDocuments;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/gnbs/GnbLeft/RecentDocumentItem/RecentDocumentItem.server.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/LeftGnbIcons/LeftGnbIcons.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
;
;
;
;
;
const RecentDocumentItem = ({ workspaceId, documentType, documentId, title })=>{
    const href = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].BUILD_DOCUMENT_ROUTE(workspaceId, documentType, documentId);
    if (!href) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        "aria-label": `${title} 파일로 이동`,
        href: href,
        className: "h-34pxr rounded-9pxr flex cursor-pointer items-center gap-2 self-stretch px-3 py-1.5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$LeftGnbIcons$2f$LeftGnbIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LeftGnbIconsState"].RECENT_FILE
            }, void 0, false, {
                fileName: "[project]/src/common/components/gnbs/GnbLeft/RecentDocumentItem/RecentDocumentItem.server.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-b3-rg text-gray-200",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/common/components/gnbs/GnbLeft/RecentDocumentItem/RecentDocumentItem.server.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/gnbs/GnbLeft/RecentDocumentItem/RecentDocumentItem.server.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
};
_c = RecentDocumentItem;
const __TURBOPACK__default__export__ = RecentDocumentItem;
var _c;
__turbopack_context__.k.register(_c, "RecentDocumentItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/gnbs/GnbLeft/RecentDocumentItem/RecentDocumentItemSkeleton.server.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const RecentDocumentItemSkeleton = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-210pxr h-27pxr animate-bg-pulse rounded-9pxr"
    }, void 0, false, {
        fileName: "[project]/src/common/components/gnbs/GnbLeft/RecentDocumentItem/RecentDocumentItemSkeleton.server.tsx",
        lineNumber: 2,
        columnNumber: 10
    }, this);
};
_c = RecentDocumentItemSkeleton;
const __TURBOPACK__default__export__ = RecentDocumentItemSkeleton;
var _c;
__turbopack_context__.k.register(_c, "RecentDocumentItemSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/gnbs/GnbLeft/RecentDocumentsSection/RecentDocumentsSection.server.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchRecentDocuments$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/get/queries/useFetchRecentDocuments.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$gnbs$2f$GnbLeft$2f$RecentDocumentItem$2f$RecentDocumentItem$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/gnbs/GnbLeft/RecentDocumentItem/RecentDocumentItem.server.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$gnbs$2f$GnbLeft$2f$RecentDocumentItem$2f$RecentDocumentItemSkeleton$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/gnbs/GnbLeft/RecentDocumentItem/RecentDocumentItemSkeleton.server.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const RecentDocumentsSection = ({ workspaceId })=>{
    _s();
    const { isFetching, extra: recentDocuments } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchRecentDocuments$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(workspaceId);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                className: "text-cap1-md mt-12pxr mb-6pxr ml-12pxr cursor-default text-gray-400",
                children: "recent"
            }, void 0, false, {
                fileName: "[project]/src/common/components/gnbs/GnbLeft/RecentDocumentsSection/RecentDocumentsSection.server.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-210pxr flex flex-col items-start gap-1",
                children: [
                    isFetching && Array.from({
                        length: 5
                    }).map((_, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$gnbs$2f$GnbLeft$2f$RecentDocumentItem$2f$RecentDocumentItemSkeleton$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, idx, false, {
                            fileName: "[project]/src/common/components/gnbs/GnbLeft/RecentDocumentsSection/RecentDocumentsSection.server.tsx",
                            lineNumber: 19,
                            columnNumber: 53
                        }, this)),
                    !isFetching && recentDocuments?.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-b3-rg mt-5pxr ml-12pxr text-gray-400",
                        children: "최근 문서가 없습니다."
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbLeft/RecentDocumentsSection/RecentDocumentsSection.server.tsx",
                        lineNumber: 22,
                        columnNumber: 11
                    }, this),
                    !isFetching && recentDocuments?.map((doc)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$gnbs$2f$GnbLeft$2f$RecentDocumentItem$2f$RecentDocumentItem$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            workspaceId: workspaceId,
                            documentId: doc.documentId,
                            documentType: doc.documentType,
                            title: doc.title
                        }, doc.documentId, false, {
                            fileName: "[project]/src/common/components/gnbs/GnbLeft/RecentDocumentsSection/RecentDocumentsSection.server.tsx",
                            lineNumber: 27,
                            columnNumber: 13
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/gnbs/GnbLeft/RecentDocumentsSection/RecentDocumentsSection.server.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
};
_s(RecentDocumentsSection, "4OdwLfLnqq/W4HcxwbmQTEEmONI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchRecentDocuments$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = RecentDocumentsSection;
const __TURBOPACK__default__export__ = RecentDocumentsSection;
var _c;
__turbopack_context__.k.register(_c, "RecentDocumentsSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/arrow/DownArrowIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgDownArrowIcon = function SvgDownArrowIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#505050",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "m13.5 8.5-3.5 3-3.5-3"
    })));
};
_c = SvgDownArrowIcon;
const __TURBOPACK__default__export__ = SvgDownArrowIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgDownArrowIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/arrow/LeftArrowIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLeftArrowIcon = function SvgLeftArrowIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M16.875 10H3.75m4.375-5-5 5 5 5"
    })));
};
_c = SvgLeftArrowIcon;
const __TURBOPACK__default__export__ = SvgLeftArrowIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgLeftArrowIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/arrow/RightArrowIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgRightArrowIcon = function SvgRightArrowIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 20 20"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#111",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M3.125 10H16.25m-4.375 5 5-5-5-5"
    })));
};
_c = SvgRightArrowIcon;
const __TURBOPACK__default__export__ = SvgRightArrowIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgRightArrowIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/calendar/ChevronLeftMini.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgChevronLeftMini = function SvgChevronLeftMini(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 24 24"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#505050",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.25,
        d: "m14 16.5-4-4 4-4"
    })));
};
_c = SvgChevronLeftMini;
const __TURBOPACK__default__export__ = SvgChevronLeftMini;
var _c;
__turbopack_context__.k.register(_c, "SvgChevronLeftMini");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/calendar/ChevronRightMini.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgChevronRightMini = function SvgChevronRightMini(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 24 24"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#505050",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.25,
        d: "m10 8.5 4 4-4 4"
    })));
};
_c = SvgChevronRightMini;
const __TURBOPACK__default__export__ = SvgChevronRightMini;
var _c;
__turbopack_context__.k.register(_c, "SvgChevronRightMini");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/ArrowIcons/ArrowIcons.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ArrowIconsState": (()=>ArrowIconsState)
});
var ArrowIconsState = /*#__PURE__*/ function(ArrowIconsState) {
    ArrowIconsState["LEFT"] = "LEFT";
    ArrowIconsState["RIGHT"] = "RIGHT";
    ArrowIconsState["DOWN"] = "DOWN";
    ArrowIconsState["CHEVRON_LEFT"] = "CHEVRON_LEFT";
    ArrowIconsState["CHEVRON_RIGHT"] = "CHEVRON_RIGHT";
    return ArrowIconsState;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/ArrowIcons/ArrowIcons.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$arrow$2f$DownArrowIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/arrow/DownArrowIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$arrow$2f$LeftArrowIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/arrow/LeftArrowIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$arrow$2f$RightArrowIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/arrow/RightArrowIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$calendar$2f$ChevronLeftMini$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/calendar/ChevronLeftMini.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$calendar$2f$ChevronRightMini$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/calendar/ChevronRightMini.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/ArrowIcons/ArrowIcons.types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
const ArrowIcons = ({ state, className })=>{
    switch(state){
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowIconsState"].LEFT:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$arrow$2f$LeftArrowIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-20pxr w-20pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/ArrowIcons/ArrowIcons.tsx",
                lineNumber: 16,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowIconsState"].RIGHT:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$arrow$2f$RightArrowIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-20pxr w-20pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/ArrowIcons/ArrowIcons.tsx",
                lineNumber: 18,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowIconsState"].DOWN:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$arrow$2f$DownArrowIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-20pxr w-20pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/ArrowIcons/ArrowIcons.tsx",
                lineNumber: 20,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowIconsState"].CHEVRON_LEFT:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$calendar$2f$ChevronLeftMini$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-24pxr w-24pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/ArrowIcons/ArrowIcons.tsx",
                lineNumber: 22,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowIconsState"].CHEVRON_RIGHT:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$calendar$2f$ChevronRightMini$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-24pxr w-24pxr', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/ArrowIcons/ArrowIcons.tsx",
                lineNumber: 24,
                columnNumber: 14
            }, this);
        default:
            return null;
    }
};
_c = ArrowIcons;
const __TURBOPACK__default__export__ = ArrowIcons;
var _c;
__turbopack_context__.k.register(_c, "ArrowIcons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/workspace/get/apis/fetchWorkspaceDetail.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$api$2d$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/api-end-point.constants.ts [app-client] (ecmascript)");
;
;
const fetchWorkspaceDetail = async ({ workspaceId })=>{
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$api$2d$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WORKSPACE_API_END_POINTS"].WORKSPACE_DETAIL(workspaceId), {
        method: 'GET',
        auth: true
    });
    return response;
};
const __TURBOPACK__default__export__ = fetchWorkspaceDetail;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/workspace/get/queries/useFetchWorkspaceDetail.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$query$2d$key$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/query-key.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/hooks/queries/useAfterQuery.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$apis$2f$fetchWorkspaceDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/get/apis/fetchWorkspaceDetail.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
/**
 * 내 워크 스페이스 리스트를 가져오는 훅
 */ const useFetchWorkspaceDetail = (workspaceId)=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAfterQuery"])({
        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$query$2d$key$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].workspaces.detail(workspaceId).queryKey,
        queryFn: {
            "useFetchWorkspaceDetail.useAfterQuery": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$apis$2f$fetchWorkspaceDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    workspaceId
                })
        }["useFetchWorkspaceDetail.useAfterQuery"],
        enabled: !!workspaceId,
        retry: false,
        extra: {
            "useFetchWorkspaceDetail.useAfterQuery": (queryResult)=>queryResult.data?.result ?? {
                    title: '',
                    imageUrl: null,
                    members: []
                }
        }["useFetchWorkspaceDetail.useAfterQuery"]
    });
};
_s(useFetchWorkspaceDetail, "/MY3m4/k0JOoh72XWghwZcmb4/I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAfterQuery"]
    ];
});
const __TURBOPACK__default__export__ = useFetchWorkspaceDetail;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/stores/workspace-store.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)");
;
;
;
const workspaceStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devtools"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["immer"])((set)=>({
        title: '',
        imageUrl: null,
        members: [],
        actions: {
            setTitle: (title)=>set((state)=>{
                    state.title = title;
                }),
            setImageUrl: (imageUrl)=>set((state)=>{
                    state.imageUrl = imageUrl;
                }),
            setMembers: (members)=>set((state)=>{
                    state.members = members;
                }),
            addMember: (member)=>set((state)=>{
                    state.members.push(member);
                }),
            removeMember: (email)=>set((state)=>{
                    state.members = state.members.filter((m)=>m.email !== email);
                })
        }
    }))));
const __TURBOPACK__default__export__ = workspaceStore;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/hooks/stores/useWorkspcaeStore.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useWorkspaceActions": (()=>useWorkspaceActions),
    "useWorkspaceInfo": (()=>useWorkspaceInfo)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/react/shallow.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$stores$2f$workspace$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/stores/workspace-store.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const useWorkspaceInfo = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$stores$2f$workspace$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallow"])({
        "useWorkspaceInfo.useShallow": (state)=>({
                title: state.title,
                imageUrl: state.imageUrl,
                members: state.members
            })
    }["useWorkspaceInfo.useShallow"]));
};
_s(useWorkspaceInfo, "cfplsmNliQkD/fzzQKqhzRiWrSg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2f$shallow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useShallow"]
    ];
});
const useWorkspaceActions = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$stores$2f$workspace$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((state)=>state.actions);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/images/DefaultWorkspaceProfileImage/DefaultWorkspaceProfileImage.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
'use client';
;
;
const DefaultWorkspaceProfileImage = ({ title, className, border })=>{
    const initial = title.slice(0, 1);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`rounded-8pxr flex shrink-0 items-center justify-center bg-white text-black`, className, border ? 'border-stroke-100 border' : ''),
        role: "img",
        "aria-label": `${title} 워크스페이스의 기본 프로필 이미지`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "cursor-defualt",
            children: initial
        }, void 0, false, {
            fileName: "[project]/src/common/components/images/DefaultWorkspaceProfileImage/DefaultWorkspaceProfileImage.client.tsx",
            lineNumber: 24,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/common/components/images/DefaultWorkspaceProfileImage/DefaultWorkspaceProfileImage.client.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
};
_c = DefaultWorkspaceProfileImage;
const __TURBOPACK__default__export__ = DefaultWorkspaceProfileImage;
var _c;
__turbopack_context__.k.register(_c, "DefaultWorkspaceProfileImage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/images/WorkspaceProfileImage/WorkspaceProfileImage.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$DefaultWorkspaceProfileImage$2f$DefaultWorkspaceProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/DefaultWorkspaceProfileImage/DefaultWorkspaceProfileImage.client.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const WorkspaceProfileImage = ({ src, title, className, border })=>{
    _s();
    const [hasError, setHasError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    if (!src || hasError) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$DefaultWorkspaceProfileImage$2f$DefaultWorkspaceProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: title,
            className: className,
            border: border
        }, void 0, false, {
            fileName: "[project]/src/common/components/images/WorkspaceProfileImage/WorkspaceProfileImage.client.tsx",
            lineNumber: 16,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`rounded-8pxr relative`, className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: src,
            alt: `${title} 워크스페이스 프로필 이미지`,
            fill: true,
            style: {
                objectFit: 'cover',
                borderRadius: '8px'
            },
            onError: ()=>setHasError(true)
        }, void 0, false, {
            fileName: "[project]/src/common/components/images/WorkspaceProfileImage/WorkspaceProfileImage.client.tsx",
            lineNumber: 21,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/common/components/images/WorkspaceProfileImage/WorkspaceProfileImage.client.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
};
_s(WorkspaceProfileImage, "0lWSx5YqYPOl7PiOJe/TIAtHv6A=");
_c = WorkspaceProfileImage;
const __TURBOPACK__default__export__ = WorkspaceProfileImage;
var _c;
__turbopack_context__.k.register(_c, "WorkspaceProfileImage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/constants/api-error-codes.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "API_ERROR_CODES": (()=>API_ERROR_CODES)
});
const API_ERROR_CODES = {
    MEMBER: {
        NOT_FOUND: 'MEMBER4001',
        REFRESH_TOKEN_NOT_EQUAL: 'MEMBER4002',
        NO_AUTHORITY: 'MEMBER4003',
        ALREADY_EXISTS: 'MEMBER4004',
        USERNAME_NOT_FOUND: 'MEMBER4005',
        PASSWORD_NOT_MATCH: 'MEMBER4006'
    },
    WORKSPACE: {
        NOT_FOUND: 'WORKSPACE4001',
        MODIFY_NOT_ALLOWED: 'WORKSPACE4002',
        INVITATION_NOT_FOUND: 'WORKSPACE4003',
        EMAIL_MISMATCH: 'WORKSPACE4004',
        ALREADY_ACCEPTED: 'WORKSPACE4005',
        NOT_BELONG: 'WORKSPACE4006',
        CREATOR_NOT_FOUND: 'WORKSPACE4007'
    },
    USER_WORKSPACE: {
        NOT_FOUND: 'USERWORKSPACE4001'
    },
    MEETING: {
        NOT_FOUND: 'MEETING4001',
        FILE_NOT_FOUND: 'MEETING4002'
    },
    AUTHORIZATION: {
        EXCEPTION: 'AUTHORIZATION4001',
        JWT_ACCESS_EXPIRED: 'AUTHORIZATION4002',
        JWT_REFRESH_EXPIRED: 'AUTHORIZATION4003',
        LOGOUT_USER: 'AUTHORIZATION4004',
        JWT_NOT_RECEIVED: 'AUTHORIZATION4005',
        JWT_OUT_OF_FORM: 'AUTHORIZATION4006'
    },
    MOOD_TRACKER: {
        NOT_FOUND: 'MOODTRACKER4001',
        MODIFY_NOT_ALLOWED: 'MOODTRACKER4002',
        SURVEY_QUESTION_NOT_FOUND: 'MOODTRACKER4003',
        SURVEY_ANSWER_REQUIRED: 'MOODTRACKER4004',
        NOT_FINISHED: 'MOODTRACKER4005',
        ACCESS_DENIED: 'MOODTRACKER4006'
    },
    MAIL: {
        SEND_FAIL: 'MAIL500'
    },
    SNS_EVENT: {
        NOT_FOUND: 'SNSEVENT4001',
        LINK_NOT_FOUND: 'SNS_EVENT4002',
        INSTAGRAM_API_ERROR: 'SNS_EVENT4003',
        INSTAGRAM_API_NO_MEDIA: 'SNS_EVENT4004',
        INSTAGRAM_API_NO_COMMENT: 'SNS_EVENT4005',
        NO_ACCESS_TOKEN: 'SNS_EVENT4006',
        NO_AUTHORITY: 'SNS_EVENT4007'
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/user/end-point.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "USER_API_ENDPOINTS": (()=>USER_API_ENDPOINTS)
});
const USER_API_ENDPOINTS = {
    USER_DETAIL: ()=>`users/info`,
    USER_EDIT: ()=>`users/info`,
    USER_LIST: ()=>`users/search`
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/user/get/apis/fetchUserDetail.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "fetchUserDetail": (()=>fetchUserDetail)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/user/end-point.constants.ts [app-client] (ecmascript)");
;
;
const fetchUserDetail = async ()=>{
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["USER_API_ENDPOINTS"].USER_DETAIL(), {
        method: 'GET',
        auth: true
    });
    return response;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/user/get/queries/useFetchUserDetail.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$api$2d$error$2d$codes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/api-error-codes.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$query$2d$key$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/query-key.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/hooks/queries/useAfterQuery.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$get$2f$apis$2f$fetchUserDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/user/get/apis/fetchUserDetail.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
/**
 * gnb left에서 워크 스페이스의 최근 조회 파일 가져오는 훅
 */ const useFetchUserDetail = ()=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const handleError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useFetchUserDetail.useCallback[handleError]": (error)=>{
            // 워크스페이스 자체가 없거나 권한 없음 → 404로
            if (error.code === __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$api$2d$error$2d$codes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_ERROR_CODES"].MEMBER.NOT_FOUND) {
                router.replace(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].NOT_FOUND); // notFound() 대신 클라 라우팅
            }
        }
    }["useFetchUserDetail.useCallback[handleError]"], [
        router
    ]);
    // Hydrate된 데이터가 있어 추가 네트워크 요청 없이 바로 캐시 데이터 사용
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAfterQuery"])({
        queryKey: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$query$2d$key$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].user.detail().queryKey,
        queryFn: {
            "useFetchUserDetail.useAfterQuery": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$get$2f$apis$2f$fetchUserDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchUserDetail"])()
        }["useFetchUserDetail.useAfterQuery"],
        retry: false,
        enabled: true,
        onError: handleError,
        extra: {
            "useFetchUserDetail.useAfterQuery": (queryResult)=>queryResult.data?.result ?? {}
        }["useFetchUserDetail.useAfterQuery"]
    });
};
_s(useFetchUserDetail, "CSP98A5uM+oL55DCp8qPxv/ffYY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$queries$2f$useAfterQuery$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAfterQuery"]
    ];
});
const __TURBOPACK__default__export__ = useFetchUserDetail;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/ModalPortal/ModalPortal.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const ModalPortal = ({ children })=>{
    _s();
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [el, setEl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ModalPortal.useEffect": ()=>{
            setMounted(true);
            setEl(document.getElementById('modal'));
        }
    }["ModalPortal.useEffect"], []);
    if (!mounted || !el) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(children, el);
};
_s(ModalPortal, "sO51NL8x0ecgSVsMNDgfCUnQWHg=");
_c = ModalPortal;
const __TURBOPACK__default__export__ = ModalPortal;
var _c;
__turbopack_context__.k.register(_c, "ModalPortal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/constants/profile.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "PROFILE_COLORS": (()=>PROFILE_COLORS)
});
const PROFILE_COLORS = [
    '#E683A6',
    '#60B1AA',
    '#8C8CE7',
    '#89A4BB',
    '#459BFA',
    '#D16864',
    '#7D7E80'
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/utils/hash-code.utils.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const hashCode = (value)=>{
    return value.split('').reduce((acc, char)=>{
        return acc * 31 + char.charCodeAt(0) >>> 0;
    }, 0);
};
const __TURBOPACK__default__export__ = hashCode;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/images/types/images.common.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ImageSize": (()=>ImageSize)
});
var ImageSize = /*#__PURE__*/ function(ImageSize) {
    ImageSize["SMALL"] = "SMALL";
    ImageSize["MEDIUM"] = "MEDIUM";
    ImageSize["LARGE"] = "LARGE";
    return ImageSize;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/images/DefaultProfileImage/DefaultProfileImage.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "sizeClassMap": (()=>sizeClassMap)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/types/images.common.types.ts [app-client] (ecmascript)");
;
const sizeClassMap = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].SMALL]: 'text-cap2-rg h-4 w-4',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].MEDIUM]: 'text-cap2-rg h-7 w-7',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].LARGE]: 'text-b2-rg h-10 w-10'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/images/DefaultProfileImage/DefaultProfileImage.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$profile$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/profile.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$utils$2f$hash$2d$code$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/utils/hash-code.utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/types/images.common.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$DefaultProfileImage$2f$DefaultProfileImage$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/DefaultProfileImage/DefaultProfileImage.constants.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
const DefaultProfileImage = ({ name, userId, color, size = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].MEDIUM })=>{
    const sizeClass = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$DefaultProfileImage$2f$DefaultProfileImage$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeClassMap"][size] ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$DefaultProfileImage$2f$DefaultProfileImage$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeClassMap"][__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].MEDIUM];
    // name이 문자열이 아니거나 비어있으면, 에러를 발생시키는 대신 안전한 대체 UI를 렌더링합니다.
    if (typeof name !== 'string' || !name) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`rounded-100pxr flex shrink-0 items-center justify-center bg-gray-300`, sizeClass),
            role: "img",
            "aria-label": "사용자 프로필 이미지 로딩 중"
        }, void 0, false, {
            fileName: "[project]/src/common/components/images/DefaultProfileImage/DefaultProfileImage.client.tsx",
            lineNumber: 24,
            columnNumber: 7
        }, this);
    }
    // TODO: 한 글자만 추출
    // 구글 로그인시 lastName의 한 글자 추출
    // 일반 로그인시 한 글자 추출
    const initial = name.slice(0, 1);
    // userId가 ''인 경우 반영
    const hashKey = userId?.trim() || name?.trim() || 'anonymous';
    // 같은 사용자면 같은 색상을 가지게
    const colorIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$utils$2f$hash$2d$code$2e$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(hashKey) % __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$profile$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFILE_COLORS"].length;
    const backgroundColor = color ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$profile$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFILE_COLORS"][colorIndex];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`rounded-100pxr px-3pxr flex shrink-0 cursor-default items-center justify-center gap-2.5 py-1.5 text-white`, sizeClass),
        style: {
            background: backgroundColor
        },
        role: "img",
        "aria-label": `사용자 ${name}의 기본 프로필 이미지`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            children: initial
        }, void 0, false, {
            fileName: "[project]/src/common/components/images/DefaultProfileImage/DefaultProfileImage.client.tsx",
            lineNumber: 55,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/common/components/images/DefaultProfileImage/DefaultProfileImage.client.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
};
_c = DefaultProfileImage;
const __TURBOPACK__default__export__ = DefaultProfileImage;
var _c;
__turbopack_context__.k.register(_c, "DefaultProfileImage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/images/ProfileImage/ProfileImage.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "sizeClass": (()=>sizeClass)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/types/images.common.types.ts [app-client] (ecmascript)");
;
const sizeClass = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].SMALL]: 'h-4 w-4',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].MEDIUM]: 'h-7 w-7 ',
    [__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].LARGE]: 'h-10 w-10'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/images/ProfileImage/ProfileImage.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$DefaultProfileImage$2f$DefaultProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/DefaultProfileImage/DefaultProfileImage.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/types/images.common.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$ProfileImage$2f$ProfileImage$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/ProfileImage/ProfileImage.constants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const ProfileImage = ({ src, userId, name, size = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].MEDIUM })=>{
    _s();
    const [hasError, setHasError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    if (!src || hasError) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$DefaultProfileImage$2f$DefaultProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            userId: userId,
            name: name,
            size: size
        }, void 0, false, {
            fileName: "[project]/src/common/components/images/ProfileImage/ProfileImage.client.tsx",
            lineNumber: 19,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('relative', __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$ProfileImage$2f$ProfileImage$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeClass"][size]),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: src,
            alt: "프로필 이미지",
            fill: true,
            style: {
                objectFit: 'cover',
                borderRadius: '100px'
            },
            onError: ()=>setHasError(true)
        }, void 0, false, {
            fileName: "[project]/src/common/components/images/ProfileImage/ProfileImage.client.tsx",
            lineNumber: 24,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/common/components/images/ProfileImage/ProfileImage.client.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
};
_s(ProfileImage, "0lWSx5YqYPOl7PiOJe/TIAtHv6A=");
_c = ProfileImage;
const __TURBOPACK__default__export__ = ProfileImage;
var _c;
__turbopack_context__.k.register(_c, "ProfileImage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/profile-dropdown/AddProfileIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgAddProfileIcon = function SvgAddProfileIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 16 16"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#767676",
        d: "M9.334 9.291a.625.625 0 1 0 0-1.25zm0 5.334a.625.625 0 1 0 0-1.25zM10 10.708a.625.625 0 0 0 0 1.25zm4 1.25a.625.625 0 1 0 0-1.25zm-2.625 1.375a.625.625 0 1 0 1.25 0zm1.25-4a.625.625 0 1 0-1.25 0zM10 4h-.625A2.04 2.04 0 0 1 7.334 6.04v1.25A3.29 3.29 0 0 0 10.625 4zM7.334 6.666v-.625A2.04 2.04 0 0 1 5.292 4h-1.25A3.29 3.29 0 0 0 7.334 7.29zM4.667 4h.625c0-1.128.914-2.042 2.042-2.042V.708A3.29 3.29 0 0 0 4.042 4zm2.667-2.667v.625c1.127 0 2.041.914 2.041 2.042h1.25A3.29 3.29 0 0 0 7.334.708zm-2 7.333v.625h4v-1.25h-4zm4 5.334v-.625h-4v1.25h4zm-4 0v-.625a2.04 2.04 0 0 1-2.042-2.042h-1.25a3.29 3.29 0 0 0 3.292 3.292zm0-5.334v-.625a3.29 3.29 0 0 0-3.292 3.292h1.25c0-1.128.914-2.042 2.042-2.042zM10 11.333v.625h4v-1.25h-4zm2 2h.625v-4h-1.25v4z"
    })));
};
_c = SvgAddProfileIcon;
const __TURBOPACK__default__export__ = SvgAddProfileIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgAddProfileIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/profile-dropdown/LogoutIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgLogoutIcon = function SvgLogoutIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 16 16"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#999",
        d: "M9.333 2v.625zM10 2v-.625zm4 4h.625zm0 4h-.625zm-4 4v.625zm-.667 0v-.625zm4.626-2.812.617.098zm-2.77 2.771-.099-.617zm0-11.918.097-.617zm2.77 2.77.617-.097zM6.958 2.168a.625.625 0 0 0 .75 1zm.75 10.667a.625.625 0 0 0-.75 1zM2 7.375a.625.625 0 1 0 0 1.25zM10.667 8v-.625zm-2.389 2.177a.625.625 0 0 0 .777.98zm1.564-.442-.388-.49zm0-3.47-.388.49zm-.787-1.421a.625.625 0 1 0-.777.98zm2.265 3.323.617.098zm0-.334.617-.098zM9.333 2v.625H10v-1.25h-.667zM14 6h-.625v4h1.25V6zm-4 8v-.625h-.667v1.25H10zm4-4h-.625c0 .643-.002.892-.033 1.09l.617.098.617.098c.05-.32.049-.69.049-1.286zm-4 4v.625c.595 0 .966.002 1.286-.049l-.098-.617-.098-.617c-.198.031-.447.033-1.09.033zm3.959-2.812-.617-.098a2.71 2.71 0 0 1-2.252 2.252l.098.617.098.617a3.96 3.96 0 0 0 3.29-3.29zM10 2v.625c.643 0 .892.002 1.09.033l.098-.617.098-.617c-.32-.05-.69-.049-1.286-.049zm4 4h.625c0-.595.002-.966-.049-1.286l-.617.098-.617.098c.031.198.033.447.033 1.09zm-2.812-3.959-.098.617a2.71 2.71 0 0 1 2.252 2.252l.617-.098.617-.098a3.96 3.96 0 0 0-3.29-3.29zM9.333 2v-.625c-.89 0-1.713.295-2.375.792l.375.5.376.5a2.7 2.7 0 0 1 1.624-.542zm0 12v-.625c-.61 0-1.172-.201-1.624-.541l-.376.5-.375.5a3.94 3.94 0 0 0 2.375.791zM2 8v.625h8.667v-1.25H2zm6.667 2.667.388.49 1.175-.932-.388-.49-.388-.49-1.176.932zm1.175-4.402.388-.49-1.175-.931-.388.49-.389.49 1.176.931zm0 3.47.388.49c.457-.363.842-.667 1.117-.94.277-.276.523-.599.59-1.02l-.617-.098-.617-.098c-.005.032-.03.122-.239.33-.212.212-.53.465-1.01.846zm0-3.47-.388.49c.48.381.798.634 1.01.846.21.208.234.298.239.33l.617-.098.617-.098c-.067-.421-.313-.744-.59-1.02-.275-.273-.66-.577-1.117-.94zm1.478 1.902.617.098q.021-.131.021-.265h-1.25a1 1 0 0 1-.005.069zM11.333 8h.625q0-.134-.02-.265l-.618.098-.617.098a1 1 0 0 1 .005.069zm-.666 0v.625h.666v-1.25h-.666z"
    })));
};
_c = SvgLogoutIcon;
const __TURBOPACK__default__export__ = SvgLogoutIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgLogoutIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/profile-dropdown/ProfileIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgProfileIcon = function SvgProfileIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 16 16"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        fill: "#767676",
        d: "M10.666 6h-.625A2.04 2.04 0 0 1 8 8.04v1.25A3.29 3.29 0 0 0 11.29 6zM8 8.666v-.625A2.04 2.04 0 0 1 5.958 6h-1.25A3.29 3.29 0 0 0 8 9.29zM5.333 6h.625c0-1.128.914-2.042 2.042-2.042v-1.25A3.29 3.29 0 0 0 4.708 6zM8 3.333v.625c1.127 0 2.041.914 2.041 2.042h1.25A3.29 3.29 0 0 0 8 2.708zm-2 7.333v.625h4v-1.25H6zM1.333 8h.625A6.04 6.04 0 0 1 8 1.958V.708A7.29 7.29 0 0 0 .708 8zM8 1.333v.625A6.04 6.04 0 0 1 14.04 8h1.25A7.29 7.29 0 0 0 8 .708zM14.666 8h-.625c0 1.713-.712 3.26-1.859 4.36l.433.45.433.451A7.27 7.27 0 0 0 15.29 8zm-2.05 4.81-.434-.45A6.02 6.02 0 0 1 8 14.04v1.25a7.27 7.27 0 0 0 5.048-2.03zM10 10.666v.625c.99 0 1.816.705 2.002 1.641l.613-.122.613-.122A3.29 3.29 0 0 0 10 10.042zm-2 4v-.625a6.02 6.02 0 0 1-4.183-1.682l-.433.451-.433.451A7.27 7.27 0 0 0 8 15.291zM3.384 12.81l.433-.45A6.02 6.02 0 0 1 1.958 8H.708c0 2.067.862 3.935 2.243 5.261zM6 10.666v-.625a3.29 3.29 0 0 0-3.229 2.647l.613.122.613.122A2.04 2.04 0 0 1 6 11.292z"
    })));
};
_c = SvgProfileIcon;
const __TURBOPACK__default__export__ = SvgProfileIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgProfileIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/profile-dropdown/SettingIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path, _path2;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgSettingIcon = function SvgSettingIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 16 16"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#767676",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeMiterlimit: 10,
        strokeWidth: 1.25,
        d: "M8 10a2 2 0 1 0 0-4 2 2 0 0 0 0 4"
    })), _path2 || (_path2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "#767676",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeMiterlimit: 10,
        strokeWidth: 1.25,
        d: "M1.333 8.586V7.413A1.27 1.27 0 0 1 2.6 6.146c1.207 0 1.7-.853 1.093-1.9-.346-.6-.14-1.38.467-1.726l1.153-.66a1.113 1.113 0 0 1 1.52.4l.074.126c.6 1.047 1.586 1.047 2.193 0l.073-.126a1.113 1.113 0 0 1 1.52-.4l1.154.66c.606.346.813 1.126.466 1.726-.606 1.047-.113 1.9 1.094 1.9a1.27 1.27 0 0 1 1.266 1.267v1.173a1.27 1.27 0 0 1-1.266 1.267c-1.207 0-1.7.853-1.094 1.9.347.607.14 1.38-.466 1.727l-1.154.66a1.113 1.113 0 0 1-1.52-.4l-.073-.127c-.6-1.047-1.587-1.047-2.193 0l-.074.127a1.113 1.113 0 0 1-1.52.4l-1.153-.66a1.266 1.266 0 0 1-.467-1.727c.607-1.047.114-1.9-1.093-1.9a1.27 1.27 0 0 1-1.267-1.267"
    })));
};
_c = SvgSettingIcon;
const __TURBOPACK__default__export__ = SvgSettingIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgSettingIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ProfileDropdownIconsState": (()=>ProfileDropdownIconsState)
});
var ProfileDropdownIconsState = /*#__PURE__*/ function(ProfileDropdownIconsState) {
    ProfileDropdownIconsState["LOGOUT"] = "LOGOUT";
    ProfileDropdownIconsState["ADD_PROFILE"] = "ADD_PROFILE";
    ProfileDropdownIconsState["PROFILE"] = "PROFILE";
    ProfileDropdownIconsState["SETTING"] = "SETTING";
    return ProfileDropdownIconsState;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$profile$2d$dropdown$2f$AddProfileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/profile-dropdown/AddProfileIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$profile$2d$dropdown$2f$LogoutIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/profile-dropdown/LogoutIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$profile$2d$dropdown$2f$ProfileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/profile-dropdown/ProfileIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$profile$2d$dropdown$2f$SettingIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/profile-dropdown/SettingIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.types.ts [app-client] (ecmascript)");
;
;
;
;
;
;
;
const ProfileDropdownIcons = ({ state, className })=>{
    switch(state){
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileDropdownIconsState"].LOGOUT:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$profile$2d$dropdown$2f$LogoutIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[16px] w-[16px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.tsx",
                lineNumber: 18,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileDropdownIconsState"].ADD_PROFILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$profile$2d$dropdown$2f$AddProfileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[16px] w-[16px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.tsx",
                lineNumber: 20,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileDropdownIconsState"].PROFILE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$profile$2d$dropdown$2f$ProfileIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[16px] w-[16px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.tsx",
                lineNumber: 22,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileDropdownIconsState"].SETTING:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$profile$2d$dropdown$2f$SettingIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[16px] w-[16px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.tsx",
                lineNumber: 24,
                columnNumber: 14
            }, this);
        default:
            return null;
    }
};
_c = ProfileDropdownIcons;
const __TURBOPACK__default__export__ = ProfileDropdownIcons;
var _c;
__turbopack_context__.k.register(_c, "ProfileDropdownIcons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/user/constants/api-end-point.constants.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "AUTH_API_ENDPOINTS": (()=>AUTH_API_ENDPOINTS)
});
const AUTH_API_ENDPOINTS = {
    SIGN_UP: '/users/signup',
    CHECK_EMAIL_DUPLICATION: '/users/signup/same',
    REFRESH_TOKEN: '/users/refresh',
    LOGIN: '/users/login',
    USER_INFO: '/users/info',
    SEARCH_USER: '/users/search',
    LOGOUT: '/users/logout'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/user/apis/delete/logout.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "logout": (()=>logout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/fetcher.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$constants$2f$api$2d$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/user/constants/api-end-point.constants.ts [app-client] (ecmascript)");
;
;
const logout = async ()=>{
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defaultApi"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$constants$2f$api$2d$end$2d$point$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_API_ENDPOINTS"].LOGOUT, {
        method: 'DELETE',
        // TODO: fetcher 변경에 따라 수정 필요
        headers: {
            Authorization: `Bearer ${("TURBOPACK compile-time value", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJ1c2VySWQiOjgsImlhdCI6MTc1NTE0NjAzNiwiZXhwIjoxNzU3NzM4MDM2fQ.1MF5HfXXw1Bvf39sDwdA_SfPFfUUkhCA_fEIBwShzWuV-ZZ3fl-vY3HsugxkjPbvv609NiD4Mk0NBeTMnIjcdQ")}`
        }
    });
    return response;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/features/auth/stores/auth-store.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.7_@types+react@19.1.10_immer@10.1.1_react@19.1.1/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)");
;
;
;
const useAuthStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devtools"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$7_$40$types$2b$react$40$19$2e$1$2e$10_immer$40$10$2e$1$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["immer"])((set)=>({
        user: null,
        actions: {
            setUser: (user)=>set((state)=>{
                    state.user = user;
                }),
            setAccessToken: (accessToken)=>set((state)=>{
                    if (state.user) {
                        state.user.accessToken = accessToken;
                    } else {
                        state.user = {
                            accessToken
                        };
                    }
                }),
            setRefreshToken: (refreshToken)=>set((state)=>{
                    if (state.user) {
                        state.user.refreshToken = refreshToken;
                    } else {
                        state.user = {
                            refreshToken
                        };
                    }
                }),
            setWorkspaceIdList: (workspaceIdList)=>set((state)=>{
                    if (state.user) {
                        state.user.workspaceIdList = workspaceIdList;
                    } else {
                        // TODO: 오용을 방지하기 위해 추가된 부분, 추후 수정 필요
                        throw new Error('ERROR: USER NOT SET IN AUTH STORE');
                    }
                }),
            clearAuth: ()=>{
                set((state)=>{
                    state.user = null;
                });
                localStorage.removeItem('auth-store');
            }
        }
    })), {
    name: 'auth-store',
    partialize: (state)=>({
            user: state.user
        })
})));
const __TURBOPACK__default__export__ = useAuthStore;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/features/auth/hooks/useAuthStore.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useAccessToken": (()=>useAccessToken),
    "useAuthStoreActions": (()=>useAuthStoreActions),
    "useUser": (()=>useUser)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/auth/stores/auth-store.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
const useAuthStoreActions = ()=>{
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useAuthStoreActions.useAuthStore": (state)=>state.actions
    }["useAuthStoreActions.useAuthStore"]);
};
_s(useAuthStoreActions, "BSK3XewfuZPixDP8tbzcobpulFc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
const useUser = ()=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useUser.useAuthStore": (state)=>state.user
    }["useUser.useAuthStore"]);
};
_s1(useUser, "BSK3XewfuZPixDP8tbzcobpulFc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
const useAccessToken = ()=>{
    _s2();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useAccessToken.useAuthStore": (state)=>state.user?.accessToken
    }["useAccessToken.useAuthStore"]);
};
_s2(useAccessToken, "BSK3XewfuZPixDP8tbzcobpulFc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$stores$2f$auth$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/api/user/hooks/mutations/useLogout.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.85.1_react@19.1.1/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@tanstack+react-query@5.85.1_react@19.1.1/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$apis$2f$delete$2f$logout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/user/apis/delete/logout.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$hooks$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/auth/hooks/useAuthStore.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
const useLogout = ()=>{
    _s();
    const qc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { clearAuth } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$hooks$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStoreActions"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$apis$2f$delete$2f$logout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logout"],
        // 실패하더라도 클라이언트 토큰은 무조건 제거
        onSettled: {
            "useLogout.useMutation": async ()=>{
                // 토큰/유저 정보 삭제 (메모리 + 로컬스토리지)
                clearAuth();
                // 캐시 제거
                try {
                    await qc.cancelQueries();
                    await qc.clear();
                } catch  {}
                // 보호 페이지로 못 돌아가게 replace 사용
                router.replace(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].LANDING.BASE);
            }
        }["useLogout.useMutation"]
    });
};
_s(useLogout, "96bFEqGQpRAr7LZlQ/yO795bWIo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$auth$2f$hooks$2f$useAuthStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStoreActions"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$tanstack$2b$react$2d$query$40$5$2e$85$2e$1_react$40$19$2e$1$2e$1$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
const __TURBOPACK__default__export__ = useLogout;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/select-box/SelectBoxProfile/FooterButtons/FooterButtons.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$hooks$2f$mutations$2f$useLogout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/user/hooks/mutations/useLogout.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
const FooterButtons = ()=>{
    _s();
    const { mutate: logout, isPending } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$hooks$2f$mutations$2f$useLogout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const handleLogout = ()=>{
        logout();
    };
    const { workspaceId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex w-full items-center justify-between",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].MODAL.SETTING(workspaceId),
                className: "border-stroke-200 gap-3pxr rounded-7pxr flex h-7 items-center justify-center border border-solid bg-white px-2 py-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileDropdownIconsState"].PROFILE
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/FooterButtons/FooterButtons.client.tsx",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-cap1-md text-gray-300",
                        children: "프로필 설정"
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/FooterButtons/FooterButtons.client.tsx",
                        lineNumber: 30,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/FooterButtons/FooterButtons.client.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleLogout,
                className: "gap-3pxr flex items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileDropdownIconsState"].LOGOUT
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/FooterButtons/FooterButtons.client.tsx",
                        lineNumber: 33,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-cap2-md text-gray-400 hover:underline', isPending ? 'cursor-default' : 'cursor-pointer hover:decoration-gray-400 hover:decoration-solid hover:decoration-[1px] hover:underline-offset-[1px] hover:[text-decoration-skip-ink:none] hover:[text-underline-position:from-font]'),
                        children: isPending ? '로그아웃 중...' : '로그아웃'
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/FooterButtons/FooterButtons.client.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/FooterButtons/FooterButtons.client.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/FooterButtons/FooterButtons.client.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
};
_s(FooterButtons, "WWoVmKrWYQBvlLiculilrMhBB1Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$hooks$2f$mutations$2f$useLogout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"]
    ];
});
_c = FooterButtons;
const __TURBOPACK__default__export__ = FooterButtons;
var _c;
__turbopack_context__.k.register(_c, "FooterButtons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/select-box/SelectBoxProfile/HeaderButtons/HeaderButtons.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/ProfileDropdownIcons/ProfileDropdownIcons.types.ts [app-client] (ecmascript)");
'use client';
;
;
;
const HeaderButtons = ({ onSettingClick, onAddMemberClick })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "gap-6pxr flex",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: onSettingClick,
                className: "border-stroke-200 gap-3pxr rounded-7pxr flex h-7 cursor-pointer items-center justify-center border border-solid bg-white px-2 py-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileDropdownIconsState"].SETTING
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/HeaderButtons/HeaderButtons.client.tsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-cap1-md text-gray-300",
                        children: "워크스페이스 설정"
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/HeaderButtons/HeaderButtons.client.tsx",
                        lineNumber: 16,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/HeaderButtons/HeaderButtons.client.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: onAddMemberClick,
                className: "border-stroke-200 gap-3pxr rounded-7pxr flex h-7 cursor-pointer items-center justify-center border border-solid bg-white px-2 py-1.5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ProfileDropdownIcons$2f$ProfileDropdownIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileDropdownIconsState"].ADD_PROFILE
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/HeaderButtons/HeaderButtons.client.tsx",
                        lineNumber: 22,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-cap1-md text-gray-300",
                        children: "팀원 추가"
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/HeaderButtons/HeaderButtons.client.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/HeaderButtons/HeaderButtons.client.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/HeaderButtons/HeaderButtons.client.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
_c = HeaderButtons;
const __TURBOPACK__default__export__ = HeaderButtons;
var _c;
__turbopack_context__.k.register(_c, "HeaderButtons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkSpaceItemSkeleton.server.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const WorkSpaceItemSkeleton = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-270pxr h-32pxr rounded-10pxr animate-bg-pulse"
    }, void 0, false, {
        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkSpaceItemSkeleton.server.tsx",
        lineNumber: 2,
        columnNumber: 10
    }, this);
};
_c = WorkSpaceItemSkeleton;
const __TURBOPACK__default__export__ = WorkSpaceItemSkeleton;
var _c;
__turbopack_context__.k.register(_c, "WorkSpaceItemSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkspaceItem.server.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$WorkspaceProfileImage$2f$WorkspaceProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/WorkspaceProfileImage/WorkspaceProfileImage.client.tsx [app-client] (ecmascript)");
;
;
;
;
const WorkspaceItem = ({ workspaceId, imageUrl, title, isOwner })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].WORKSPACE_MAIN(workspaceId),
        className: "h-32pxr rounded-10pxr p-10pxr flex cursor-pointer items-center justify-between bg-white hover:bg-gray-600",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "gap-6pxr flex items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$WorkspaceProfileImage$2f$WorkspaceProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: imageUrl,
                        title: title,
                        className: "w-18pxr h-18pxr text-cap2-rg",
                        border: true
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkspaceItem.server.tsx",
                        lineNumber: 16,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-b3-rg text-black",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkspaceItem.server.tsx",
                        lineNumber: 22,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkspaceItem.server.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            isOwner && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-cap2-rg text-right text-gray-400",
                children: "Owner"
            }, void 0, false, {
                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkspaceItem.server.tsx",
                lineNumber: 24,
                columnNumber: 19
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkspaceItem.server.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
};
_c = WorkspaceItem;
const __TURBOPACK__default__export__ = WorkspaceItem;
var _c;
__turbopack_context__.k.register(_c, "WorkspaceItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/MyWorkspaces.server.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchMyWorkspaces$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/get/queries/useFetchMyWorkspaces.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$MyWorkspaces$2f$WorkspaceItem$2f$WorkSpaceItemSkeleton$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkSpaceItemSkeleton.server.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$MyWorkspaces$2f$WorkspaceItem$2f$WorkspaceItem$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/WorkspaceItem/WorkspaceItem.server.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
const MyWorkspaces = ()=>{
    _s();
    const { isFetching, extra: workspaces } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchMyWorkspaces$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "gap-3pxr max-h-210pxr scrollbar-component flex flex-col overflow-y-auto",
        children: [
            isFetching && Array.from({
                length: 5
            }).map((_, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$MyWorkspaces$2f$WorkspaceItem$2f$WorkSpaceItemSkeleton$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, idx, false, {
                    fileName: "[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/MyWorkspaces.server.tsx",
                    lineNumber: 11,
                    columnNumber: 64
                }, this)),
            !isFetching && workspaces?.map((ws)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$MyWorkspaces$2f$WorkspaceItem$2f$WorkspaceItem$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    workspaceId: ws.workspaceId,
                    imageUrl: ws.imageUrl,
                    title: ws.title,
                    isOwner: ws.isOwner
                }, ws.workspaceId, false, {
                    fileName: "[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/MyWorkspaces.server.tsx",
                    lineNumber: 15,
                    columnNumber: 11
                }, this))
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/MyWorkspaces.server.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
_s(MyWorkspaces, "9LPS6lGd0HnE8TskC2sdS1lNSLw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchMyWorkspaces$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = MyWorkspaces;
const __TURBOPACK__default__export__ = MyWorkspaces;
var _c;
__turbopack_context__.k.register(_c, "MyWorkspaces");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/svgs/plus/PlusIcon.svg.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _path;
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
;
var SvgPlusIcon = function SvgPlusIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("svg", _extends({
        xmlns: "http://www.w3.org/2000/svg",
        width: "current",
        height: "current",
        fill: "none",
        viewBox: "0 0 16 16"
    }, props), _path || (_path = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"])("path", {
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 1.5,
        d: "M8 2.666v10.667m5.334-5.334H2.667"
    })));
};
_c = SvgPlusIcon;
const __TURBOPACK__default__export__ = SvgPlusIcon;
var _c;
__turbopack_context__.k.register(_c, "SvgPlusIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/PlusIcons/PlusIcons.types.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "PlusIconsState": (()=>PlusIconsState)
});
var PlusIconsState = /*#__PURE__*/ function(PlusIconsState) {
    PlusIconsState["SIZE_20_GRAY_400"] = "SIZE_20_GRAY_400";
    PlusIconsState["SIZE_16_GRAY_300"] = "SIZE_16_GRAY_300";
    PlusIconsState["SIZE_20_PRIMARY"] = "SIZE_20_PRIMARY";
    PlusIconsState["SIZE_16_PRIMARY"] = "SIZE_16_PRIMARY";
    PlusIconsState["SIZE_20_SECONDARY_GREEN"] = "SIZE_20_SECONDARY_GREEN";
    PlusIconsState["SIZE_16_SECONDARY_GREEN"] = "SIZE_16_SECONDARY_GREEN";
    PlusIconsState["SIZE_20_SECONDARY_BLUE"] = "SIZE_20_SECONDARY_BLUE";
    PlusIconsState["SIZE_16_SECONDARY_BLUE"] = "SIZE_16_SECONDARY_BLUE";
    PlusIconsState["SIZE_24"] = "SIZE_24";
    return PlusIconsState;
}({});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/clsx@2.1.1/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$plus$2f$PlusIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/assets/svgs/plus/PlusIcon.svg.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/PlusIcons/PlusIcons.types.ts [app-client] (ecmascript)");
;
;
;
;
const PlusIcons = ({ state, className })=>{
    switch(state){
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_20_GRAY_400:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$plus$2f$PlusIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[20px] w-[20px] text-gray-400', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx",
                lineNumber: 12,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_16_GRAY_300:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$plus$2f$PlusIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('h-[16px] w-[16px] text-gray-300', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx",
                lineNumber: 14,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_20_PRIMARY:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$plus$2f$PlusIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-primary h-[20px] w-[20px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx",
                lineNumber: 16,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_16_PRIMARY:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$plus$2f$PlusIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-primary h-[16px] w-[16px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx",
                lineNumber: 18,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_20_SECONDARY_GREEN:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$plus$2f$PlusIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-secondary-green h-[20px] w-[20px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx",
                lineNumber: 20,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_16_SECONDARY_GREEN:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$plus$2f$PlusIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-secondary-green h-[16px] w-[16px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx",
                lineNumber: 22,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_20_SECONDARY_BLUE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$plus$2f$PlusIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-secondary-blue h-[20px] w-[20px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx",
                lineNumber: 24,
                columnNumber: 14
            }, this);
        case __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_16_SECONDARY_BLUE:
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$svgs$2f$plus$2f$PlusIcon$2e$svg$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$clsx$40$2$2e$1$2e$1$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('text-secondary-blue h-[16px] w-[16px]', className)
            }, void 0, false, {
                fileName: "[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx",
                lineNumber: 26,
                columnNumber: 14
            }, this);
        default:
            return null;
    }
};
_c = PlusIcons;
const __TURBOPACK__default__export__ = PlusIcons;
var _c;
__turbopack_context__.k.register(_c, "PlusIcons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/select-box/SelectBoxProfile/NewWorkspaceButton/NewWorkspaceButton.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/PlusIcons/PlusIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/PlusIcons/PlusIcons.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const NewWorkspaceButton = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        className: "gap-6pxr rounded-10pxr p-10pxr flex w-full items-center justify-start self-stretch",
        href: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].ONBOARDING,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$PlusIcons$2f$PlusIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PlusIconsState"].SIZE_20_PRIMARY
            }, void 0, false, {
                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/NewWorkspaceButton/NewWorkspaceButton.client.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-primary text-cap1-md",
                children: "내 워크스페이스 추가"
            }, void 0, false, {
                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/NewWorkspaceButton/NewWorkspaceButton.client.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/NewWorkspaceButton/NewWorkspaceButton.client.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
};
_c = NewWorkspaceButton;
const __TURBOPACK__default__export__ = NewWorkspaceButton;
var _c;
__turbopack_context__.k.register(_c, "NewWorkspaceButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$get$2f$queries$2f$useFetchUserDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/user/get/queries/useFetchUserDetail.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$ModalPortal$2f$ModalPortal$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/ModalPortal/ModalPortal.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$ProfileImage$2f$ProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/ProfileImage/ProfileImage.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/types/images.common.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$FooterButtons$2f$FooterButtons$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/select-box/SelectBoxProfile/FooterButtons/FooterButtons.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$HeaderButtons$2f$HeaderButtons$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/select-box/SelectBoxProfile/HeaderButtons/HeaderButtons.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$MyWorkspaces$2f$MyWorkspaces$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/select-box/SelectBoxProfile/MyWorkspaces/MyWorkspaces.server.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$NewWorkspaceButton$2f$NewWorkspaceButton$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/select-box/SelectBoxProfile/NewWorkspaceButton/NewWorkspaceButton.client.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
const SelectBoxProfile = ({ isOpen, setIsOpen, onSettingClick })=>{
    _s();
    if (!isOpen) return null;
    const { extra: userDetail, isFetching } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$get$2f$queries$2f$useFetchUserDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$ModalPortal$2f$ModalPortal$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-1",
            onClick: ()=>{
                setIsOpen(false);
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-stroke-200 shadow-dropdown-popup w-302pxr top-112pxr left-16pxr fixed z-2 flex flex-col items-start gap-2.5 rounded-2xl border border-solid bg-white p-4",
                onClick: (e)=>e.stopPropagation(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-start gap-2.5 self-stretch",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-4",
                                children: [
                                    isFetching ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-40pxr w-190pxr animate-bg-pulse rounded-6pxr"
                                    }, void 0, false, {
                                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                        lineNumber: 44,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3.5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$ProfileImage$2f$ProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                userId: userDetail?.userId ?? '',
                                                src: userDetail?.imageUrl ?? null,
                                                name: userDetail?.name ?? '',
                                                size: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$types$2f$images$2e$common$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ImageSize"].LARGE
                                            }, void 0, false, {
                                                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                                lineNumber: 47,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-cap1-rg text-black",
                                                        children: userDetail?.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                                        lineNumber: 54,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-cap2-rg text-gray-400",
                                                        children: userDetail?.email
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                                        lineNumber: 55,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                                lineNumber: 53,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                        lineNumber: 46,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$HeaderButtons$2f$HeaderButtons$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        onSettingClick: onSettingClick,
                                        onAddMemberClick: ()=>console.log('멤버 추가 클릭')
                                    }, void 0, false, {
                                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                        lineNumber: 59,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                lineNumber: 42,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-stroke-200 h-px w-full"
                            }, void 0, false, {
                                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                lineNumber: 65,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-cap2-md mb-7pxr px-2.5 text-gray-400",
                                        children: "내 워크스페이스"
                                    }, void 0, false, {
                                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                        lineNumber: 68,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$MyWorkspaces$2f$MyWorkspaces$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                        lineNumber: 70,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$NewWorkspaceButton$2f$NewWorkspaceButton$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                        lineNumber: 72,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                                lineNumber: 67,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                        lineNumber: 41,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-stroke-200 h-1pxr w-full"
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                        lineNumber: 76,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$FooterButtons$2f$FooterButtons$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                        lineNumber: 78,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
                lineNumber: 37,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
            lineNumber: 30,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
};
_s(SelectBoxProfile, "9erHF58MoXEFHb+Pzwx3yghEMFg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2f$get$2f$queries$2f$useFetchUserDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = SelectBoxProfile;
const __TURBOPACK__default__export__ = SelectBoxProfile;
var _c;
__turbopack_context__.k.register(_c, "SelectBoxProfile");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfileSkeleton.server.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const WorkspaceProfileSkeleton = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-46pxr px-7pxr py-5pxr flex w-full",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "animate-bg-pulse rounded-9pxr flex w-full items-center"
        }, void 0, false, {
            fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfileSkeleton.server.tsx",
            lineNumber: 4,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfileSkeleton.server.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
};
_c = WorkspaceProfileSkeleton;
const __TURBOPACK__default__export__ = WorkspaceProfileSkeleton;
var _c;
__turbopack_context__.k.register(_c, "WorkspaceProfileSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/ArrowIcons/ArrowIcons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/icons/ArrowIcons/ArrowIcons.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchWorkspaceDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/workspace/get/queries/useFetchWorkspaceDetail.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/constants/routes.constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useWorkspcaeStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/hooks/stores/useWorkspcaeStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$WorkspaceProfileImage$2f$WorkspaceProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/images/WorkspaceProfileImage/WorkspaceProfileImage.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$SelectBoxProfile$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/select-box/SelectBoxProfile/SelectBoxProfile.client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$gnbs$2f$GnbLeft$2f$WorkspaceProfile$2f$WorkspaceProfileSkeleton$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfileSkeleton.server.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
const WorkSpaceProfile = ({ workspaceId })=>{
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { isFetching, extra: workspaceDetail } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchWorkspaceDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(workspaceId ?? '');
    const { title, imageUrl } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useWorkspcaeStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkspaceInfo"])();
    const { setTitle, setImageUrl, setMembers } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useWorkspcaeStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkspaceActions"])();
    const [isOpenSelectBoxProfile, setIsOpenSelectBoxProfile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // workspaceId 존재 여부 + 데이터 유효성 체크 (제목 있는지로)
    const hasWorkspaceId = !!workspaceId;
    // 쿼리 데이터가 있으면 그걸 우선 표시, 없으면 스토어 표시
    const displayTitle = workspaceDetail?.title ?? title;
    const displayImageUrl = workspaceDetail?.imageUrl ?? imageUrl;
    const hasValidWorkspace = !!displayTitle;
    const handleClick = ()=>{
        setIsOpenSelectBoxProfile((prev)=>!prev);
    };
    // 워크스페이스 있을때만 사용
    const handleSettingClick = ()=>{
        router.push(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$constants$2f$routes$2e$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROUTES"].MODAL.SETTING(workspaceId));
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WorkSpaceProfile.useEffect": ()=>{
            if (workspaceDetail && hasWorkspaceId) {
                setTitle(workspaceDetail.title);
                setImageUrl(workspaceDetail.imageUrl);
                setMembers(workspaceDetail.members);
            }
        }
    }["WorkSpaceProfile.useEffect"], [
        workspaceDetail
    ]);
    if (!hasWorkspaceId) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "h-46pxr px-7pxr py-5pxr mb-4pxr w-full cursor-not-allowed",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between self-stretch",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$WorkspaceProfileImage$2f$WorkspaceProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: null,
                                title: '',
                                className: "w-20pxr h-20pxr text-cap2-rg",
                                border: true
                            }, void 0, false, {
                                fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                                lineNumber: 60,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-cap1-rg text-black",
                                children: "워크스페이스 없음"
                            }, void 0, false, {
                                fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                        lineNumber: 59,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowIconsState"].DOWN
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                lineNumber: 58,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
            lineNumber: 57,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative",
        children: [
            isFetching && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$gnbs$2f$GnbLeft$2f$WorkspaceProfile$2f$WorkspaceProfileSkeleton$2e$server$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                lineNumber: 76,
                columnNumber: 22
            }, this),
            !isFetching && hasValidWorkspace && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "h-46pxr px-7pxr mb-4pxr py-5pxr w-full",
                        onClick: handleClick,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between self-stretch",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$images$2f$WorkspaceProfileImage$2f$WorkspaceProfileImage$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: displayImageUrl || null,
                                            title: displayTitle,
                                            className: "w-20pxr h-20pxr text-cap2-rg",
                                            border: true
                                        }, void 0, false, {
                                            fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                                            lineNumber: 82,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-t6-sb text-black",
                                            children: title
                                        }, void 0, false, {
                                            fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                                            lineNumber: 88,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                                    lineNumber: 81,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    state: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$icons$2f$ArrowIcons$2f$ArrowIcons$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowIconsState"].DOWN
                                }, void 0, false, {
                                    fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                                    lineNumber: 90,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                            lineNumber: 80,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                        lineNumber: 79,
                        columnNumber: 11
                    }, this),
                    isOpenSelectBoxProfile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$components$2f$select$2d$box$2f$SelectBoxProfile$2f$SelectBoxProfile$2e$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        isOpen: isOpenSelectBoxProfile,
                        setIsOpen: setIsOpenSelectBoxProfile,
                        onSettingClick: handleSettingClick
                    }, void 0, false, {
                        fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
                        lineNumber: 94,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/src/common/components/gnbs/GnbLeft/WorkspaceProfile/WorkspaceProfile.client.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
};
_s(WorkSpaceProfile, "IKKbFsN/eVkE8b8vyGyXTkYgvEc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$workspace$2f$get$2f$queries$2f$useFetchWorkspaceDetail$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useWorkspcaeStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkspaceInfo"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$common$2f$hooks$2f$stores$2f$useWorkspcaeStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWorkspaceActions"]
    ];
});
_c = WorkSpaceProfile;
const __TURBOPACK__default__export__ = WorkSpaceProfile;
var _c;
__turbopack_context__.k.register(_c, "WorkSpaceProfile");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_9ee7d760._.js.map