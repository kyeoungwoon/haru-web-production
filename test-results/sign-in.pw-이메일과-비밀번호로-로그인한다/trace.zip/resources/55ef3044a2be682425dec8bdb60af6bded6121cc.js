(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/instrumentation-client.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// 브라우저에서 발생하는 에러를 Sentry가 자동으로 수집할 수 있도록 연결
__turbopack_context__.s({
    "onRouterTransitionStart": (()=>onRouterTransitionStart)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.3.4_@babel+core@7.28.0_@opentelemetry+api@1.9.0_@playwright+test@1.54.2_react-d_61a3b3a2a642369830891a3e5aa830fd/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$nextjs$40$9$2e$46$2e$0_$40$opentelemetry$2b$context$2d$async$2d$hooks$40$1$2e$30$2e$1_$40$opentelemetry$2b$api$40$1$2e$9$2e$_53f7651e20d6a389a79ab3765c5da5e9$2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@sentry+nextjs@9.46.0_@opentelemetry+context-async-hooks@1.30.1_@opentelemetry+api@1.9._53f7651e20d6a389a79ab3765c5da5e9/node_modules/@sentry/nextjs/build/esm/client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2d$internal$2b$replay$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2d$internal$2f$replay$2f$build$2f$npm$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@sentry-internal+replay@9.46.0/node_modules/@sentry-internal/replay/build/npm/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$browser$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2f$browser$2f$build$2f$npm$2f$esm$2f$integrations$2f$httpclient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@sentry+browser@9.46.0/node_modules/@sentry/browser/build/npm/esm/integrations/httpclient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$nextjs$40$9$2e$46$2e$0_$40$opentelemetry$2b$context$2d$async$2d$hooks$40$1$2e$30$2e$1_$40$opentelemetry$2b$api$40$1$2e$9$2e$_53f7651e20d6a389a79ab3765c5da5e9$2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$browserTracingIntegration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@sentry+nextjs@9.46.0_@opentelemetry+context-async-hooks@1.30.1_@opentelemetry+api@1.9._53f7651e20d6a389a79ab3765c5da5e9/node_modules/@sentry/nextjs/build/esm/client/browserTracingIntegration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$nextjs$40$9$2e$46$2e$0_$40$opentelemetry$2b$context$2d$async$2d$hooks$40$1$2e$30$2e$1_$40$opentelemetry$2b$api$40$1$2e$9$2e$_53f7651e20d6a389a79ab3765c5da5e9$2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$routing$2f$appRouterRoutingInstrumentation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@sentry+nextjs@9.46.0_@opentelemetry+context-async-hooks@1.30.1_@opentelemetry+api@1.9._53f7651e20d6a389a79ab3765c5da5e9/node_modules/@sentry/nextjs/build/esm/client/routing/appRouterRoutingInstrumentation.js [app-client] (ecmascript)");
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$nextjs$40$9$2e$46$2e$0_$40$opentelemetry$2b$context$2d$async$2d$hooks$40$1$2e$30$2e$1_$40$opentelemetry$2b$api$40$1$2e$9$2e$_53f7651e20d6a389a79ab3765c5da5e9$2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["init"])({
    dsn: ("TURBOPACK compile-time value", "https://6731a574651bf06e375d82817661b31f@o4509587237240832.ingest.us.sentry.io/4509587238748160"),
    integrations: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2d$internal$2b$replay$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2d$internal$2f$replay$2f$build$2f$npm$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replayIntegration"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$browser$40$9$2e$46$2e$0$2f$node_modules$2f40$sentry$2f$browser$2f$build$2f$npm$2f$esm$2f$integrations$2f$httpclient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["httpClientIntegration"])(),
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$nextjs$40$9$2e$46$2e$0_$40$opentelemetry$2b$context$2d$async$2d$hooks$40$1$2e$30$2e$1_$40$opentelemetry$2b$api$40$1$2e$9$2e$_53f7651e20d6a389a79ab3765c5da5e9$2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$browserTracingIntegration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["browserTracingIntegration"])()
    ],
    sendDefaultPii: true,
    tracesSampleRate: 1.0,
    debug: false,
    replaysSessionSampleRate: 0.1,
    replaysOnErrorSampleRate: 1.0,
    release: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$3$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$opentelemetry$2b$api$40$1$2e$9$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$2_react$2d$d_61a3b3a2a642369830891a3e5aa830fd$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.RELEASE_VERSION,
    enabled: ("TURBOPACK compile-time value", "development") !== 'development',
    beforeSend (event) {
        // is_custom_event 태그가 있는 경우에만 이벤트를 전송
        if (event.tags && event.tags.is_custom_event) {
            return event;
        }
        // is_custom_event 태그가 없으면 이벤트 전송하지 않음
        return null;
    }
});
const onRouterTransitionStart = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$sentry$2b$nextjs$40$9$2e$46$2e$0_$40$opentelemetry$2b$context$2d$async$2d$hooks$40$1$2e$30$2e$1_$40$opentelemetry$2b$api$40$1$2e$9$2e$_53f7651e20d6a389a79ab3765c5da5e9$2f$node_modules$2f40$sentry$2f$nextjs$2f$build$2f$esm$2f$client$2f$routing$2f$appRouterRoutingInstrumentation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["captureRouterTransitionStart"];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_instrumentation-client_ts_4aba9a11._.js.map